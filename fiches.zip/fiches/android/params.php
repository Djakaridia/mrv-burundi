<?php 
require_once 'fonctions/php/Fonctions.php'; 
require_once 'fonctions/php/Session.php';

if($ACCESS=="O")
{
	if(isset($_POST["Params"]))
	{
		$HOST="31.220.56.191";
		$USER="yambee_agrijeunes";
		$PASS="A12&xjn44";
		echo '[';

		echo '{"HOST":"'.$HOST.'","USER":"'.$USER.'","PASSWORD":"'.$PASS.'"}';

		echo ']';
	}
}
 ?>

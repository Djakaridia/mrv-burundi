<?php

function Charger_db()
{
	$host_name = 'host=localhost';
	$user_name = 'root';
	$password = 'ajEeX2Sn@';
	$bd_name = 'c17MR803';    /*** FIche ***/

	try {
		$Connexion = new PDO('mysql:' . $host_name . ';dbname=' . $bd_name, $user_name, $password, array(PDO::ATTR_PERSISTENT => true));
		$Connexion->exec('SET CHARACTER SET utf8');
		return $Connexion;
	} catch (Exception $e) {
		return null;
	}
}

?>
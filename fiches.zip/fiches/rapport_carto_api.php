<?php

// api/report.php
// header('Content-Type: application/json; charset=utf-8');
// header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Methods: GET');

include_once 'api/configuration.php';
$config = new Config;

require_once 'api/Fonctions.php';

try {
    $dataRes = FC_Rechercher_Code("SELECT * FROM t_rapport WHERE Type_Rapport = 'CARTO'");
    $rapports = [];

    if ($dataRes) {
        foreach ($dataRes as $r) {
            $rapports[] = [
                'title' => $r['Nom_Rapport'],
                'code' => $r['Code_Rapport']
            ];
        }
    }

    echo json_encode([
        'count' => count($rapports),
        'rapports' => $rapports
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    exit;

} catch (Throwable $t) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Erreur serveur.',
        'details' => $t->getMessage()
    ]);
    exit;
}

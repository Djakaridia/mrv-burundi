<?php
///////////////////////////////////////////////
/*                 SSE                       */
/*	Conception & Développement: BAMASOFT */
///////////////////////////////////////////////

include_once 'api/configuration.php';
$config = new Config;

require_once 'api/Fonctions.php';
require_once 'theme_components/theme_style.php';

$Code_Rapport = "";
if (isset($_GET['r']) and !empty($_GET['r'])) {
    $Code_Rapport = base64_decode($_GET['r']);
    $Nom_Rapport = "";
    $ii = 0;
    foreach (FC_Rechercher_Code('SELECT * FROM t_rapport WHERE Code_Rapport=\'' . $Code_Rapport . '\'') as $row4) {
        $ii++;
        $uuu = 0;
        $Nom_Rapport = $row4['Nom_Rapport'];

        if ($ii == 0) {
            header('location:mobile_rapports_dynamiques.php');
        }

    }
} else {
    header('location:mobile_rapports_dynamiques.php');
}
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title><?php print $config->sitename; ?></title>
    <link rel="shortcut icon" type="image/ico" href="<?php print $config->icon_folder; ?>/favicon.png" />
    <meta name="keywords" content="<?php print $config->MetaKeys; ?>" />
    <meta name="description" content="<?php print $config->MetaDesc; ?>" />
    <meta name="author" content="<?php print $config->MetaAuthor; ?>" />

    <!-- Vendor styles -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css" />
    <link rel="stylesheet" href="vendor/metisMenu/dist/metisMenu.css" />
    <link rel="stylesheet" href="vendor/animate.css/animate.css" />
    <link rel="stylesheet" href="vendor/bootstrap/dist/css/bootstrap.css" />

    <!-- App styles -->
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/helper.css" />
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/style_fst.css">

    <!-- Vendor scripts -->
    <script src="vendor/jquery/dist/jquery.min.js"></script>
    <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.resize.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.pie.js"></script>
    <script src="vendor/flot.curvedlines/curvedLines.js"></script>
    <script src="vendor/jquery.flot.spline/index.js"></script>
    <script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
    <script src="vendor/iCheck/icheck.min.js"></script>
    <script src="vendor/peity/jquery.peity.min.js"></script>
    <script src="vendor/sparkline/index.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/locales/bootstrap-datepicker.fr.min.js"></script>

    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://code.highcharts.com/modules/export-xlsx.js"></script>

    <script src="https://cdn.sheetjs.com/xlsx-latest/package/dist/xlsx.full.min.js"></script>

    <!-- App scripts -->
    <script src="scripts/homer.js"></script>



    <style type="text/css">
        .change-chart {
            margin: 5px 3px;
            border-radius: 50px !important;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease-in-out;
        }

        .change-chart:hover {
            transform: scale(1.1);
        }
    </style>
    <style>
        #datatable {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fff;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        #datatable thead th {
            background: linear-gradient(to right, #007bff, #0056b3);
            color: white;
            font-weight: 600;
            padding: 12px;
            text-align: center;
        }

        #datatable tbody td {
            padding: 10px;
            /*  text-align: center; */
            border-top: 1px solid #f1f1f1;
        }

        #datatable tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        #datatable tr:hover {
            background-color: #eaf4ff;
            transition: background-color 0.2s ease;
        }
    </style>
</head>

<body class="fixed-navbar fixed fixed-footer sidebar-scroll">
    <!-- Main Wrapper -->
    <div id="">
        <div class="content animate-panel">
            <div class="row">



                <?php echo '<script type="text/javascript" charset="utf-8" > var Code_Rapport="' . base64_encode($Code_Rapport) . '";
                </script>'; ?>

                <form id="form_perso_feuille_donnees">
                </form>
                <script type="text/javascript">
                    var feuille_active = 1;
                </script>
                <div class="content">
                    <div style="background-color: white">
                        <?php require_once 'requires/formulaire_insertion_123.php'; ?>
                        <div class="tab-content">
                            <?php
                            $ind = 0;
                            $resRapport = FC_Rechercher_Code("SELECT * FROM t_rapport WHERE Code_Rapport = " . intval($Code_Rapport));
                            foreach ($resRapport as $row5) {
                                $ind++;
                                echo '<div class="row" style="font-size: 14px" align="left">
                                
                                
                                '; ?>

                                <!--  <div class="mb-3 text-right">

                                    <button class="btn btn-sm btn-success" onclick="exportTableToXLSX('datatable')"> <i
                                            class="fas fa-file-excel"></i>Excel</button>
                                    <button class="btn btn-sm btn-primary"
                                        onclick="exportTableToWord('datatable', 'rapport')"><i class="fas fa-file-word"></i>
                                        Word</button>
                                    <button class="btn btn-sm btn-danger" onclick="exportTableToPDF('datatable')"><i
                                            class="fas fa-file-pdf"></i> PDF</button>
                                    <button class="btn btn-sm btn-info" onclick="exportChart()"><i class="fas fa-image"></i>
                                        Export Graphique</button>
                                </div> -->
                                <script>
                                    var rapportTitle = <?php echo json_encode($row5['Nom_Rapport']); ?>;
                                </script>
                                <?php

                                echo '<div class="text-center">
    <h2 id="rapport-title" class="text-primary mb-4 d-inline-block" style="padding-left: 10px; font-weight: 600;">' .
                                    htmlspecialchars($row5['Nom_Rapport']) .
                                    '</h2>
</div>';

                                // Tableau
                                echo '<div class="row">
                    <div class="col-lg-6">
                        <div class="hpanel">
                          
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table id="datatable" class="table contenu" cellpadding="1" cellspacing="1">
                                        <tr style="background-color:#F1F3F6; text-align:center">';

                                // En-têtes
                                $groupBy = explode('.', $row5["Group_By"]);
                                $valeurs = explode('.', $row5["Valeur"]);

                                foreach (FC_Rechercher_Code("SELECT t_feuille_ligne.Nom_Ligne FROM t_feuille_ligne INNER JOIN t_feuille ON t_feuille_ligne.Code_Feuille = t_feuille.Code_Feuille WHERE t_feuille.Table_Feuille = '" . str_replace("v", "t", $groupBy[0]) . "' AND t_feuille_ligne.Nom_Collone = '" . $groupBy[1] . "'") as $row6) {
                                    echo "<th>" . htmlspecialchars($row6["Nom_Ligne"]) . "</th>";
                                }

                                foreach (FC_Rechercher_Code("SELECT t_feuille_ligne.Nom_Ligne FROM t_feuille_ligne INNER JOIN t_feuille ON t_feuille_ligne.Code_Feuille = t_feuille.Code_Feuille WHERE t_feuille.Table_Feuille = '" . str_replace("v", "t", $valeurs[0]) . "' AND t_feuille_ligne.Nom_Collone = '" . $valeurs[1] . "'") as $row6) {
                                    echo "<th>" . htmlspecialchars($row6["Nom_Ligne"]) . "</th>";
                                }

                                echo '</tr>';

                                // Données
                                $compte = 0;
                                try {
                                    $Res = FC_Rechercher_Code("SELECT * FROM " . $row5['Nom_View']);
                                    if ($Res) {
                                        foreach ($Res as $row8) {
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row8[0]) . "</td>";
                                            echo "<td>" . number_format($row8[1], 0, '', ' ') . "</td>";
                                            echo "</tr>";
                                            $compte++;
                                        }
                                    }
                                } catch (Exception $e) {
                                    echo "<tr><td colspan='2'>Erreur lors de la récupération des données.</td></tr>";
                                }

                                echo '</table>
                    </div>
                </div>
                <div class="panel-footer">' . $compte . ' ligne(s)</div>
                </div>
            </div>';

                                // Graphique
                                echo '<div class="col-lg-6 graph_div">
                    <div class="hpanel">
                        <div class="panel-heading">
                        
                            <div class="col-12 text-center my-3">';


                                ?>
                            </div>
                            <div class="col-12 text-center my-3">
                                <button class="btn btn-sm btn-primary change-chart" data-type="bar"><i
                                        class="fas fa-chart-bar"></i> </button>
                                <button class="btn btn-sm btn-secondary change-chart" data-type="column"><i
                                        class="fas fa-chart-column"></i> </button>
                                <button class="btn btn-sm btn-success change-chart" data-type="line"><i
                                        class="fas fa-chart-line"></i> </button>
                                <button class="btn btn-sm btn-warning change-chart" data-type="spline"><i
                                        class="fas fa-wave-square"></i> </button>
                                <button class="btn btn-sm btn-info change-chart" data-type="area"><i
                                        class="fas fa-chart-area"></i> </button>
                                <button class="btn btn-sm btn-dark change-chart" data-type="areaspline"><i
                                        class="fas fa-water"></i> </button>
                                <button class="btn btn-sm btn-outline-success change-chart" data-type="scatter"><i
                                        class="fas fa-braille"></i> </button>
                                <button class="btn btn-sm btn-outline-primary change-chart" data-type="polygon"><i
                                        class="fas fa-draw-polygon"></i> </button>
                                <button class="btn btn-sm btn-danger change-chart" data-type="pie"><i
                                        class="fas fa-chart-pie"></i> </button>
                                <button class="btn btn-sm btn-outline-danger change-chart" data-type="pie"
                                    data-innerSize="50%"><i class="fas fa-ring"></i> </button>
                            </div>
                        </div>
                        <div class="panel-body">

                            <div class="table-responsive">
                                <div id="container" style="height: 400px"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php }
                            ?>
    </div>
    </div>
    </div>
    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function () {
            let chart = Highcharts.chart('container', {
                data: { table: 'datatable' },
                chart: { type: 'column', height: 400 },
                title: { text: rapportTitle },
                xAxis: { title: { text: null }, gridLineWidth: 1, lineWidth: 0 },
                yAxis: {
                    min: 0,
                    title: { text: 'Nombre', align: 'high' },
                    labels: { overflow: 'justify' },
                    gridLineWidth: 0
                },
                tooltip: {
                    formatter: function () {
                        return `<b>${this.series.name}</b><br>${this.point.y} ${this.point.name.toLowerCase()}`;
                    }
                },
                plotOptions: {
                    series: {
                        dataLabels: {
                            enabled: true,
                            format: '{y}',
                            style: { fontSize: '12px', fontWeight: 'bold', color: '#000' }
                        }
                    },
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        showInLegend: true,
                        dataLabels: {
                            enabled: true,
                            format: '{point.name}: {point.y}',
                            style: { fontSize: '12px', fontWeight: 'bold' }
                        }
                    }
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'top',
                    x: -40,
                    y: 50,
                    floating: true,
                    borderWidth: 1,
                    backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF',
                    shadow: true
                },
                credits: {
                    enabled: true,
                    text: 'SISE MRV-Burundi : ' + new Date().toLocaleString('fr-FR'),
                    href: '#',
                    style: { cursor: 'pointer', color: '#6633FF', fontSize: '10px', margin: '10px' }
                },
                exporting: {
                    filename: rapportTitle,
                    buttons: {
                        contextButton: {
                            menuItems: [
                                "downloadPNG",
                                "downloadJPEG",
                                "downloadPDF",
                                "downloadSVG",
                                "downloadXLSX"
                            ]
                        }
                    }
                }
            });

            // Gestion du changement de type de graphique
            document.querySelectorAll('.change-chart').forEach(button => {
                button.addEventListener('click', function () {
                    let newType = this.getAttribute('data-type');
                    let innerSize = this.getAttribute('data-innerSize') || '0%';

                    chart.update({
                        chart: { type: newType },
                        plotOptions: {
                            series: {
                                dataLabels: { enabled: true, format: '{y}' }
                            },
                            pie: {
                                innerSize: innerSize,
                                dataLabels: {
                                    enabled: true,
                                    format: '{point.name}: {point.y}'
                                }
                            }
                        }
                    });
                });
            });
        });
    </script>


    <!--    <script>
        function getReportTitle() {
            let titleElement = document.getElementById('rapport-title');
            return titleElement ? titleElement.textContent.trim().replace(/[^a-zA-Z0-9_\-]/g, '_') : 'rapport';
        }

        function exportTableToXLSX(tableID) {
            const filename = getReportTitle();
            let workbook = XLSX.utils.book_new();
            let worksheet = XLSX.utils.table_to_sheet(document.getElementById(tableID));
            XLSX.utils.book_append_sheet(workbook, worksheet, "Feuille1");
            XLSX.writeFile(workbook, filename + ".xlsx");
        }

        function exportTableToWord(tableID) {
            const filename = getReportTitle();
            let header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' " +
                "xmlns:w='urn:schemas-microsoft-com:office:word' " +
                "xmlns='http://www.w3.org/TR/REC-html40'>" +
                "<head><meta charset='utf-8'></head><body>";
            let footer = "</body></html>";
            let sourceHTML = header;

            // Ajouter le titre dans le Word
            const titleText = document.getElementById('rapport-title')?.outerHTML || '';
            sourceHTML += titleText;

            // Ajouter le tableau
            sourceHTML += document.getElementById(tableID).outerHTML + footer;

            let source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
            let fileDownload = document.createElement("a");
            document.body.appendChild(fileDownload);
            fileDownload.href = source;
            fileDownload.download = filename + '.doc';
            fileDownload.click();
            document.body.removeChild(fileDownload);
        }

        async function exportTableToPDF(tableID) {
            const filename = getReportTitle();
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('p', 'pt', 'a4');

            // Créer un conteneur temporaire avec le titre + tableau
            const title = document.getElementById('rapport-title')?.cloneNode(true);
            const table = document.getElementById(tableID).cloneNode(true);

            const container = document.createElement('div');
            if (title) container.appendChild(title);
            container.appendChild(table);
            container.style.background = "#fff"; // éviter transparence
            container.style.padding = "20px";

            document.body.appendChild(container); // nécessaire pour html2canvas

            await html2canvas(container).then(canvas => {
                const imgData = canvas.toDataURL('image/png');
                const imgProps = doc.getImageProperties(imgData);
                const pdfWidth = doc.internal.pageSize.getWidth();
                const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                doc.addImage(imgData, 'PNG', 20, 20, pdfWidth - 40, pdfHeight);
                doc.save(filename + ".pdf");
            });

            document.body.removeChild(container); // nettoyage
        }

        function exportChart() {
            Highcharts.charts.forEach(function (chart) {
                if (chart && chart.exportChart) {
                    chart.exportChart({ type: 'application/pdf' }); // ou 'image/png'
                }
            });
        }
    </script> -->


</body>

</html>
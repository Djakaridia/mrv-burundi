-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : jeu. 04 déc. 2025 à 08:21
-- Version du serveur : 10.11.14-MariaDB-0+deb12u2
-- Version de PHP : 8.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `c0fc7sise1`
--

-- --------------------------------------------------------

--
-- Structure de la table `t_feuille_etrangere`
--

CREATE TABLE `t_feuille_etrangere` (
  `Nom_Table` varchar(255) NOT NULL,
  `Nom_Colonne` varchar(255) NOT NULL,
  `Valeur` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `t_feuille_etrangere`
--

INSERT INTO `t_feuille_etrangere` (`Nom_Table`, `Nom_Colonne`, `Valeur`) VALUES
('t_1611516933', 'col3', 'Homme;Femme'),
('t_1761166063', 'col10', 'Oui;Non'),
('t_1761166063', 'col13', 'Oui;Non'),
('t_1761166063', 'col16', 'Date_Cloture;DatePlainte'),
('t_1761166063', 'col17', 'En cours;Résolue;Non résolue;Abandonnée'),
('t_1761166063', 'col5', 'Oui;Non'),
('t_1761166063', 'col6', 'Comité Départemental de Conciliation;Comité National d’Arbitrage;Comité de Gestion des Plaintes au sein du ProCaR (CGP ProCaR)'),
('t_1761334017', 'col16', 'Oral;Ecrit'),
('t_1761334017', 'col21', 'Oui;Non'),
('t_1761334017', 'col23', 'Non;Oui'),
('t_1761334017', 'col3', 'Oui;Non'),
('t_1761334017', 'col7', 'Institution;Particulier'),
('t_1761495347', 'col10', 'Comité Communal de Médiation;Comité Régional de Conciliation;Comité National d’Arbitrage;Comité de Gestion des Plaintes au sein du FC-PSFE'),
('t_1761495347', 'col11', '859;17468'),
('t_1761495347', 'col12', '858;17464'),
('t_1761495347', 'col13', 'PADMAR;PADMAR-E;PAPSFRA;PADAAM;PRIMA;PACER'),
('t_1761495347', 'col3', '854;17375'),
('t_1761495347', 'col5', '4 – Institutionnelle ;2 - Particulier'),
('t_1761495347', 'col9', 'Oui;Non'),
('t_1763815290', 'col1', 'H;F'),
('t_1763815398', 'col2', '858;17464'),
('t_1763817779', 'col1', 'Oui; Non'),
('t_1763817780', 'col1', 'Oui; Non'),
('t_1763818284', 'col1', 'Oui; Non'),
('t_1763818284', 'col3', 'Gouverneur;DGPAT;DATZF'),
('t_1763819067', 'col1', 'Oui;Non'),
('t_1763819067', 'col2', 'Gouverneur;DGPAT;DATZF'),
('t_1763819457', 'col2', 'Homme;femme');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `t_feuille_etrangere`
--
ALTER TABLE `t_feuille_etrangere`
  ADD PRIMARY KEY (`Nom_Table`,`Nom_Colonne`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php require_once '../../api/Fonctions.php'; ?>

<?php if(isset($_GET) AND !empty($_GET["Code"])) :
$Res = FC_Rechercher_Code("SELECT * FROM `t_1619452726` WHERE `Id` = '".trim($_GET["Code"])."'");
if($Res != null AND ($Res -> rowCount())>0){}
else {echo '<center><h1 style="color:red">Aucune correspondance!</h1></center>'; exit();}
foreach ($Res as $key) {
file_get_contents("http://".$_SERVER["HTTP_HOST"]."/fiches/libs/qrcode/index.php?data=".("http://".$_SERVER["HTTP_HOST"]."/carte.php?Code=").urlencode($key["Id"])."&level=H&size=10&complete_name=code_".str_replace(" ", "", $key["Id"]).".png");

?>

<!DOCTYPE html>
<html>
<head>
  <title>Carte</title>
  <link rel="stylesheet" href="../../vendor/bootstrap/dist/css/bootstrap.css" />
</head>
<body style="width: 100%; height: 100vh">

          <div style="height: auto; max-width:380px; margin: 0 auto;">
           <div class="carte">
            <table width="100%" style="border:1px solid #CCC;">
             <tr>
                
                <td align="left" style="vertical-align: top;"><strong><?php echo $key["col1"]; ?></strong><br>
                  <strong>Date de naissance :</strong> <?php echo $key["col2"]; ?>
                  <br>
                  <strong>Sexe : </strong><?php echo $key["col3"]; ?>&nbsp;&nbsp;<strong>Statut : </strong><?php echo $key["col10"]; ?><br>
                  <strong>Contact :</strong>
                   <?php echo $key["col5"]; ?>
                   <br>
                  <strong>Localit&eacute; :</strong>
                   <?php echo $key["col4"]." / ".$key["col9"]; ?>
                   <br>
                  <strong>Niveau d'instruction: </strong><?php echo $key["col6"]; ?></td>
                <td width="1px"></td>
                <td style="text-align: left; width: 95px; padding-right: 5px;padding-top: 5px;" >
              <div class="photo">
                <?php if (file_exists('../../pieces/'.$key["col11"]) AND is_file('../../pieces/'.$key["col11"])){
                  echo '<img src="../../pieces/'.$key["col11"].'" width="90px" alt="Photo" height="95px" style="padding-top: 5px">';
                } ?>
              </div>              </td>
             </tr>
             <tr style="background-color: #F5F5DC;">
               <td colspan="3" style="height: 30px!important">
                <p style="width: 100%; height: 25px; padding-left: 5px;padding-top: 2px; color: maroon;padding: 0; margin: 0; padding-top: 5px;" > <font style="font-size: 14px;"> Code :</font><span style=" font-size: 12px;"><?php echo $key["col0"]; ?></span></p>              </td>
             </tr>
             <tr>
                <td colspan="2" style="padding-left: 5px;margin-top: -10px"><font style="font-weight:bold;font-size: 14px;">Groupement  </font><br>
                <i style="font-weight:bold;font-size: 12px;color: #D76230; font-family: tahoma; text-align: left;margin-top: -10px"><?php echo $key["col7"]; ?></i></td> 
              <td style="text-align: right; width: 65px; padding-right: 10px;" >
              <?php if (file_exists('../../pieces/code_'.str_replace(" ", "", $key["Id"]).'.png') AND is_file('../../pieces/code_'.str_replace(" ", "", $key["Id"]).'.png')){
                  echo '<img src="../../pieces/code_'.str_replace(" ", "", $key["Id"]).'.png" width="60px" alt="Code" height="60px" style="padding-top: 5px">';
                } ?>             </tr>
             <tr>
                <td colspan="2" align="center"><i>&copy; 2021</i></td>
                <td style="text-align: right; width: 65px; padding-right: 10px;" >                
             </tr>
            </table>
</body>
</html>
<?php } endif; ?>
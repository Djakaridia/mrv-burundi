<?php require_once '../../api/Fonctions.php'; ?>

<?php if(isset($_GET) AND !empty($_GET["Code"])) :
$Res = FC_Rechercher_Code("SELECT * FROM `t_1619452726` WHERE `Id` = '".trim($_GET["Code"])."'");
if($Res != null AND ($Res -> rowCount())>0){}
else {echo '<center><h1 style="color:red">Aucune correspondance!</h1></center>'; exit();}
foreach ($Res as $key) {
file_get_contents("http://".$_SERVER["HTTP_HOST"]."/fiches/libs/qrcode/index.php?data=".("http://".$_SERVER["HTTP_HOST"]."/carte.php?Code=").urlencode($key["Id"])."&level=H&size=10&complete_name=code_".str_replace(" ", "", $key["Id"]).".png");

$codebb="P".$key["Id"];

  $query_liste_view_indicateur = $db ->prepare('SELECT Nom_View, Valeur, Feuille_Jointure, Group_By FROM t_rapport_indicateur C WHERE Affichage="QRCODE"');
$query_liste_view_indicateur->execute();
$row_liste_view_indicateur = $query_liste_view_indicateur ->fetchAll();
$totalRows_liste_view_indicateur = $query_liste_view_indicateur->rowCount();

?>

<!DOCTYPE html>
<html>
<head>
  <title>Carte</title>
  <link rel="stylesheet" href="../../vendor/bootstrap/dist/css/bootstrap.css" />
</head>
<body style="width: 100%; height: 100vh">

          <div style="height: auto; max-width:380px; margin: 0 auto;">
           <div class="carte">
            <table width="100%" style="border:1px solid #CCC;">
             <tr>
                
                <td align="left" style="vertical-align: top;"><strong><?php echo $key["col1"]; ?></strong><br>
                  <strong>Date de naissance :</strong> <?php echo $key["col2"]; ?>
                  <br>
                  <strong>Sexe : </strong><?php echo $key["col3"]; ?>&nbsp;&nbsp;<strong>Statut : </strong><?php echo $key["col10"]; ?><br>
                  <strong>Contact :</strong>
                   <?php echo $key["col5"]; ?>
                   <br>
                  <strong>Localit&eacute; :</strong>
                   <?php echo $key["col4"]." / ".$key["col9"]; ?>
                   <br>
                  <strong>Niveau d'instruction: </strong><?php echo $key["col6"]; ?></td>
                <td width="1"></td>
                <td style="text-align: left; width: 95px; padding-right: 5px;padding-top: 5px;" >
              <div class="photo">
                <?php if (file_exists('../../pieces/'.$key["col11"]) AND is_file('../../pieces/'.$key["col11"])){
                  echo '<img src="../../pieces/'.$key["col11"].'" width="90px" alt="Photo" height="95px" style="padding-top: 5px">';
                } ?>
              </div>              </td>
             </tr>
             <tr style="background-color: #F5F5DC;">
               <td colspan="3" style="height: 30px!important">
                <p style="width: 100%; height: 25px; padding-left: 5px;padding-top: 2px; color: maroon;padding: 0; margin: 0; padding-top: 5px;" > <font style="font-size: 14px;"> Code :</font><span style=" font-size: 12px;"><?php echo $key["col0"]; ?></span></p>              </td>
             </tr>
             <tr>
                <td colspan="2" style="padding-left: 5px;margin-top: -10px"><font style="font-weight:bold;font-size: 14px;">Groupement  </font><br>
                <i style="font-weight:bold;font-size: 12px;color: #D76230; font-family: tahoma; text-align: left;margin-top: -10px"><?php echo $key["col7"]; ?></i></td> 
              <td rowspan="2" style="text-align: right; width: 65px; padding-right: 10px;" >
              <?php if (file_exists('../../pieces/code_'.str_replace(" ", "", $key["Id"]).'.png') AND is_file('../../pieces/code_'.str_replace(" ", "", $key["Id"]).'.png')){
                  echo '<img src="../../pieces/code_'.str_replace(" ", "", $key["Id"]).'.png" width="60px" alt="Code" height="60px" style="padding-top: 5px">';
                } ?>                          </tr>
             <tr>
                <td colspan="2" align="center"><i>&copy; 2021</i></td>
              </tr>
             <tr>
               <td colspan="3" align="center">
			   <?php 
	if($totalRows_liste_view_indicateur>0){  foreach($row_liste_view_indicateur as $row_liste_view_indicateur0){
//$liste_ind_view_array[$row_liste_view_indicateur0["Valeur"]] = $row_liste_view_indicateur0["Nom_View"];
	   
$feuillej=$row_liste_view_indicateur0["Feuille_Jointure"];
$colvar=$row_liste_view_indicateur0["Valeur"];



$entete_array = $libelle = array();

$query_liste_nom_table = $db ->prepare('SELECT Table_Feuille, Libelle_Feuille FROM t_feuille C WHERE Code_feuille=:Code_feuille');

$query_liste_nom_table->execute(array(':Code_feuille' => isset($row_liste_view_indicateur0["Feuille_Jointure"])?$row_liste_view_indicateur0["Feuille_Jointure"]:0));
$row_liste_nom_table = $query_liste_nom_table ->fetch();
$totalRows_liste_view_indicateur = $query_liste_nom_table->rowCount();

$cp=$feuille=$row_liste_nom_table["Table_Feuille"];
$entete_appui=$row_liste_nom_table["Libelle_Feuille"];

$colvar = str_replace("v_", "t_", $row_liste_view_indicateur0["Valeur"]);
$colvar = str_replace($cp.".", "", $colvar);

//echo $codebb;

$row_liste_view_indicateur0["Group_By"] = str_replace("v_", "t_", $row_liste_view_indicateur0["Group_By"]);
$row_liste_view_indicateur0["Group_By"] = str_replace($cp.".", "", $row_liste_view_indicateur0["Group_By"]);

$libelle_colonne=explode(";",$row_liste_view_indicateur0["Group_By"]);
 //print_r($libelle_colonne);
 
$query_act = $db ->prepare('SELECT * FROM '.$cp.' where '.$colvar.'=:codebb');
//echo $query_act." -";
$query_act->execute(array(':codebb' => isset($codebb)?$codebb:0));
$row_act = $query_act ->fetchAll();
$totalRows_act = $query_act->rowCount();



$query_entete = $db ->prepare('SELECT * FROM t_feuille_ligne  WHERE Code_feuille=:Code_feuille');
$query_entete->execute(array(':Code_feuille' => isset($row_liste_view_indicateur0["Feuille_Jointure"])?$row_liste_view_indicateur0["Feuille_Jointure"]:0));
$row_entete = $query_entete ->fetchAll();
$totalRows_entete = $query_entete->rowCount();

//echo $totalRows_entete; exit;


if($totalRows_entete>0){ $choix_array = array(); $libelle_array = array();
foreach($row_entete as $row_entete1){ 
 $nomT=$row_entete1["Libelle_Ligne"]; $note="Tapade"; 
 $entete_array[$row_entete1["Nom_Collone"]]=$row_entete1["Nom_Collone"]; 
 $libelle[]=$row_entete1["Libelle_Ligne"];
$intitule[]=$row_entete1["Libelle_Feuille"]; 
$colonne[]=$row_entete1["Nom_Collone"]; 
$libelle_array[$row_entete1["Nom_Collone"]]=$row_entete1["Libelle_Ligne"];
$lignetotal=20000; $colnum=20;
}
}
 $lib_nom_fich = $cp;


$query_entete = $db ->prepare('DESCRIBE '.$cp);
$query_entete->execute();
$row_entete = $query_entete ->fetchAll();
$totalRows_entete = $query_entete->rowCount();

//echo $totalRows_entete; exit;

$num=0;
if($totalRows_entete>0){ foreach($row_entete as $row_entete1){  /*if(in_array($row_entete["Field"],$entete_array))*/ $num++; }  }
		   
			   
			   
			   if($num>0){ ?>
<table class="table table-striped table-bordered table-hover table-responsive datatable dataTable " id="mtable<?php echo $feuillej; ?>" aria-describedby="DataTables_Table_0_info" border="1">


<thead>
<tr role="row" bgcolor="#FF9900" align="center"><td colspan="<?php if($totalRows_entete>0) echo $totalRows_entete; ?>"> <?php if($entete_appui) echo $entete_appui; ?> </td></tr>
<tr role="row" bgcolor="#BED694">
<?php 
if($totalRows_entete>0){ $i=0; foreach($row_entete as $row_entete1){

if($row_entete1["Field"]!="LKEY" && in_array($row_entete1["Field"],$entete_array) && in_array($row_entete1["Field"],$libelle_colonne)){ ?> 
<th class="" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" aria-label="Trier" ><div class="firstcapitalize" align="center"><?php echo (isset($libelle_array[$row_entete1["Field"]]))?$libelle_array[$row_entete1["Field"]]:str_replace("_"," ",$row_entete1["Field"]); ?></div></th>
<?php $i++; }  } ?>
</tr></thead>
<?php } ?>

<?php
// si ligne total on cr�e les variables
if($lignetotal==1){ $Ltotal = array();
if($totalRows_entete>0){ foreach($row_entete as $row_entete1){  if($row_entete1["Field"]!="LKEY" && in_array($row_entete1["Field"],$entete_array)  && in_array($row_entete1["Field"],$libelle_colonne) && $i>0){
 ?>
<?php $Ltotal[$row_entete1["Field"]]=0;  ?>
<?php  }  }
/*$rows = mysql_num_rows($entete);
  if($rows > 0) {
  mysql_data_seek($entete, 0);
  $row_entete = mysql_fetch_assoc($entete);
  }*/
    }
}  $i = isset($k)?$k:$i;
?>
<tbody role="alert" aria-live="polite" aria-relevant="all" class="">
<?php if($totalRows_act>0) { $i=0;  foreach($row_act as $row_act){ $id_data = $row_act['Id'];
foreach($choix_array as $Col=>$Val)
{
  $somme[$Col]=$produit[$Col]=$moyenne[$Col]=$rapport[$Col]=$difference[$Col]=0;
  $tem[$Col]=0;
}
?>
<tr class="<?php echo ($i%2==0)?"odd":"even"; ?>">
<?php if($totalRows_entete>0){
if($colnum==1){ ?>
<td><div align="center"><?php echo $i+1; ?></div></td>
<?php }  foreach($row_entete as $row_entete1){ if($row_entete1["Field"]!="LKEY" && in_array($row_entete1["Field"],$entete_array) && in_array($row_entete1["Field"],$libelle_colonne)){

 ?>
<td class=" "><?php echo  $row_act[$row_entete1["Field"]];  ?></td>
<?php } }
} ?>
</tr>
<?php $i++; } 
//total
  ?>

<?php 
 } else { $colspan = ($colnum==1)?$i+1:$i; echo "<td colspan='".($colspan+1)."' class='' align='center'><h3 align='center'>Aucune donn&eacute;es &agrave; afficher dans cette feuille !</h3></td>"; } ?>
</tbody></table>
<?php }else echo "<h3 align='center'>Aucune colonne &agrave; afficher dans la fiche ".$lib_nom_fich."!</h3>"; ?>
			   
			   
	<?php } }	 ?>		   
			   
			              </td>
              </tr>
            </table>
</body>
</html>
<?php } endif; ?>
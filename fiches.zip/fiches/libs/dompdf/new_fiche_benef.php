<?php



///////////////////////////////////////////////



/*                 SSE                       */



/*	Conception & D�veloppement: SEYA SERVICES */



///////////////////////////////////////////////



session_start();



include_once 'system/configuration.php';



$config = new Config;



/*

function strrevpos($instr, $needle)

{

    $rev_pos = strpos (strrev($instr), strrev($needle));

    if ($rev_pos===false) return false;

    else return strlen($instr) - $rev_pos - strlen($needle);

};



function after_last ($this, $inthat)

    {

        if (!is_bool(strrevpos($inthat, $this)))

        return substr($inthat, strrevpos($inthat, $this)+strlen($this));

    };*/



if (!isset ($_SESSION["clp_id"])) {



  //header(sprintf("Location: %s", "./"));



  exit;



}



include_once $config->sys_folder . "/database/db_connexion.php";



//header('Content-Type: text/html; charset=ISO-8859-15');







$dir = './attachment/mission_atelier/';



if(isset($_GET['annee'])) $annee=intval($_GET['annee']); else $annee = date("Y");







if(isset($_GET["id"]) && !empty($_GET["id"]))

{

  $id=($_GET["id"]);
  $query_liste_activite = "SELECT * FROM t_1619452726 WHERE Id='$id'";
   try{
    $liste_activite = $pdar_connexion->prepare($query_liste_activite);
    $liste_activite->execute();
    $row_liste_activite = $liste_activite ->fetch();
    $totalRows_liste_activite = $liste_activite->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }

}


 /*if($_SESSION['clp_id']=='admin') $query_liste_act = "SELECT * FROM ugl order by code_ugl";

else*/ $query_liste_act = "SELECT * FROM commune /*where code_ugl='".$_SESSION["clp_structure"]."'*/ order by nom_commune";
   try{
    $liste_act = $pdar_connexion->prepare($query_liste_act);
    $liste_act->execute();
    $row_liste_act = $liste_act ->fetchAll();
    $totalRows_liste_act = $liste_act->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }

$activite_array = array();



/*mysql_select_db($database_pdar_connexion, $pdar_connexion);
$query_liste_respo = "SELECT id_personnel, nom, prenom FROM personnel where structure='".$_SESSION["clp_structure"]."' and projet like '%".$_SESSION["clp_structure"]."|%' ";
$liste_respo  = mysql_query_ruche($query_liste_respo , $pdar_connexion) or die(mysql_error_show_message(mysql_error()));
$row_liste_respo  = mysql_fetch_assoc($liste_respo);
$totalRows_liste_respo  = mysql_num_rows($liste_respo);*/



/*
$query_liste_do = "SELECT distinct fonction FROM personnel where fonction!='Administrateur' ";
   try{
    $liste_do = $pdar_connexion->prepare($query_liste_do);
    $liste_do->execute();
    $row_liste_do = $liste_do ->fetchAll();
    $totalRows_liste_do = $liste_do->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }*/


/*
$query_liste_responsable = "SELECT * FROM ugl order by abrege_ugl asc";
   try{
    $liste_responsable = $pdar_connexion->prepare($query_liste_responsable);
    $liste_responsable->execute();
    $row_liste_responsable = $liste_responsable ->fetchAll();
    $totalRows_liste_responsable = $liste_responsable->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }*/



//liste village
/*
$query_liste_village = "SELECT code_village,nom_village FROM village  order by code_village asc";
   try{
    $liste_village = $pdar_connexion->prepare($query_liste_village);
    $liste_village->execute();
    $row_liste_village = $liste_village ->fetchAll();
    $totalRows_liste_village = $liste_village->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }*/
 if($_SESSION['clp_id']=='admin') $query_liste_cercle = "SELECT code_departement,nom_departement FROM departement   order by code_departement asc";
else 
{
 $query_liste_region = "SELECT * FROM ugl where code_ugl='".$_SESSION["clp_structure"]."'";
   try{
    $liste_region = $pdar_connexion->prepare($query_liste_region);
    $liste_region->execute();
    $row_liste_region = $liste_region ->fetch();
    $totalRows_liste_region = $liste_region->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }
 $cercle_projet = str_replace("|",",",$row_liste_region["region_concerne"]);//implode(",",(explode("|", $_SESSION["clp_projet_ugl"]));
//liste village
$query_liste_cercle = "SELECT code_departement,nom_departement FROM departement where FIND_IN_SET(code_departement, '".$cercle_projet."' )  order by code_departement asc";
}
   try{
    $liste_cercle = $pdar_connexion->prepare($query_liste_cercle);
    $liste_cercle->execute();
    $row_liste_cercle = $liste_cercle ->fetchAll();
    $totalRows_liste_cercle = $liste_cercle->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }

//sp�culation
$query_liste_speculation = "SELECT id_sp_maillon, speculation.libelle as speculation, maillon.libelle as maillon  FROM ".$database_connect_prefix."speculation, speculation_maillon, maillon where id_speculation=speculation and id_maillon=maillon order by   maillon.libelle,  speculation.libelle";
     try{
    $liste_speculation = $pdar_connexion->prepare($query_liste_speculation);
    $liste_speculation->execute();
    $row_liste_speculation = $liste_speculation ->fetchAll();
    $totalRows_liste_speculation = $liste_speculation->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }
?>





<script>

	$().ready(function() {

		// validate the comment form when it is submitted
		 $(".modal-dialog", window.parent.document).width(800);

		$("#form1").validate();

        $(".select2-select-00").select2({allowClear:true});

        $("#ui-datepicker-div").remove();

        $(".datepicker").datepicker({defaultDate:+7,showOtherMonths:true,autoSize:true,appendText:'<span class="help-block">(jj/mm/aaaa)</span>',dateFormat:"dd/mm/yy"});$(".inlinepicker").datepicker({inline:true,showOtherMonths:true,dateFormat:"dd/mm/yy"});

});

</script>

<style>

#mtable2 .dataTables_length, #mtable2 .dataTables_info { float: left; font-size: 10px;}

#mtable2 .dataTables_length, #mtable2 .dataTables_paginate, .DTTT, .ColVis { display: none;}

@media(min-width:558px){.col-md-12 {width: 100%;}.col-md-9 {width: 75%;}.col-md-3 {width: 25%;}.col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12 {float: left;}}

.ui-datepicker-append {display: none;}

textarea#message, textarea#observation { height: 400px; }

</style>
<style type="text/css"> 
#madiv{height:400px;overflow:auto} 
</style> 

<?php if(isset($_SESSION['clp_niveau']) && $_SESSION['clp_niveau']<4) { ?>



<?php if(!isset($_GET['rapport'])) { ?>





<div class="widget box">



<div class="widget-header"> <h4><i class="icon-reorder"></i>
  <?php if(isset($_GET['id'])) echo "Modifier Beneficiaire <u>".$row_liste_activite['col1']."</u>"; else echo "Ajouter un Beneficiaire"; ?>
</h4>
</div>



<div  class="widget-content scroller">



<form action="" class="row-border" method="post" enctype="multipart/form-data" name="form1" id="form1" novalidate="novalidate">

<div id="madiv">

  <table border="0" align="center" cellspacing="1" cellpadding="0" width="100%" style="font-size:10px;">


   <tr>
      <td valign="top" width="50%"><div class="form-group">
 <label for="col4" class="col-md-12 control-label">Commune<span class="required">*</span></label>
 <div class="col-md-12">
   <select name="col4" id="col4" class="full-width-fix select2-select-00 required" data-placeholder="Escolha a commune">
     <option value="">Choisissez</option>
     <?php if($totalRows_liste_act>0){ foreach($row_liste_act as $row_liste_act){  ?>
     <option value="<?php echo $row_liste_act['nom_commune']; ?>" <?php if (isset($row_liste_activite["col4"]) && $row_liste_act['nom_commune']==$row_liste_activite["col4"]) {echo "SELECTED";} ?>><?php echo $row_liste_act['nom_commune']; ?></option>
     <?php  }  } ?>
   </select>
 </div>
      </div></td>
      <td valign="top"><div class="form-group">  <label for="col9" class="col-md-12 control-label">Nom du village  <span class="required">*</span></label>
       <div class="col-md-12">
         <textarea name="col9" rows="1" class="form-control required" id="col9"><?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col9'];?></textarea>
       </div>
      </div></td>
   </tr>

   <tr>
     <td valign="top"><div class="form-group">  <label for="col1" class="col-md-12 control-label">Nom et pr&eacute;noms/label>
       <div class="col-md-12">
         <textarea name="col1" rows="1" class="form-control" id="col1"><?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col1'];?></textarea>
       </div>
      </div></td>
     <td valign="top"><div class="form-group">
      <label for="col2" class="col-md-12 control-label">Date de naissance </label>
          <div class="col-md-12">
            <input type="text" class="form-control datepicker" name="col2" id="col2" value="<?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo implode('/',array_reverse(explode('-',date("d/m/Y",strtotime($row_liste_activite['col2']))))); else echo date("d/m/Y"); ?>" />
          </div> 
      </div></td>
   </tr>
   <tr>
     <td valign="top"><div class="form-group">
         <label for="col6" class="col-md-12 control-label">Niveau instruction<span class="required">*</span></label>
         <div class="col-md-12">
           <textarea name="col6" rows="1" class="form-control required" id="col6"><?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col6'];?></textarea>
         </div>
     </div></td>
     <td valign="top">&nbsp;</td>
   </tr>
   <tr>
     <td valign="top"><div class="form-group">
         <label for="col3" class="col-md-12 control-label">Sexe <span class="required">*</span></label>
         <div class="col-md-12">
           <textarea name="col3" rows="1" class="form-control required" id="col3"><?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col3'];?></textarea>
         </div>
     </div></td>
     <td valign="top"><div class="form-group">
         <label for="col5" class="col-md-12 control-label">Contact<span class="required">*</span></label>
         <div class="col-md-12">
           <textarea name="col5" rows="1" class="form-control required" id="col5"><?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col5'];?></textarea>
         </div>
     </div></td>
   </tr>
   <tr style="background-color:#CCCCCC">
     <td colspan="2" valign="top">&nbsp;</td>
     </tr>
   <tr>
     <td valign="top"><div class="form-group">
         <label for="col10" class="col-md-12 control-label">Situation matrimoniale<span class="required">*</span></label>
         <div class="col-md-12">
           <input name="col10" type="text" class="form-control required" id="col10" value="<?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col10'];?>" />
         </div>
     </div></td>
     <td valign="top"><div class="form-group">
         <label for="login" class="col-md-12 control-label">Collecteur<span class="required">*</span></label>
         <div class="col-md-12">
           <input name="login" type="text" class="form-control required" id="login" value="<?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['Login'];?>" />
         </div>
     </div></td>
     </tr>
	    <tr>
     <td valign="top"><div class="form-group">
         <label for="col7" class="col-md-12 control-label">Groupement<span class="required">*</span></label>
         <div class="col-md-12">
           <textarea name="col7" rows="1" class="form-control required" id="col7"><?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col7'];?>
           </textarea>
         </div>
     </div></td>
     <td valign="top"><div class="form-group">
         <label for="col8" class="col-md-12 control-label">Handicap&eacute;<span class="required">*</span></label>
         <div class="col-md-12">
           <input name="col8" type="text" class="form-control required" id="col8" value="<?php if(isset($_GET["id"]) && !empty($_GET["id"])) echo $row_liste_activite['col8'];?>" />
         </div>
     </div></td>
     </tr>
  </table>

 </div>

<div class="form-actions">



<input name="annee" id="annee" type="hidden" value="<?php if(isset($_GET["annee"])) echo $_GET["annee"];?>" size="32" alt="">

<input name="code_mission" id="code_mission" type="hidden" value="<?php  echo $max; ?>" size="32" alt="" />



  <input name="submit" type="submit" class="btn btn-success pull-right" value="<?php if (isset ($_GET["id"]) && !empty($_GET["id"])) echo "Modifier";else echo "Enregistrer";?>" />
  <input name="<?php if (isset ($_GET["id"]) && !empty($_GET["id"])) echo "MM_update";else echo "MM_insert";?>" type="text" value="<?php if (isset ($_GET["id"]) && !empty($_GET["id"])) echo ($_GET["id"]); else echo "MM_insert";?>" size="32" alt="" />
  <?php if (isset ($_GET["id"]) && !empty($_GET["id"])) {?>



<input name="MM_delete" id="MM_delete" type="hidden" value="" size="32" alt="">



<input name="del" type="submit" onclick="return delete_data('MM_delete','Supprimer ce PMEA ?','<?php echo ($_GET["id"]);?>');" class="btn btn-danger pull-left" value="Supprimer" />



<?php }?>







  <input name="MM_form" id="MM_form" type="hidden" value="form1" size="32" alt="">



</div>



</form>







</div> </div>


<?php } } ?>
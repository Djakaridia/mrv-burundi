<?php

?>
<!--Classeur -->
<div id="add_classeur_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div id="reponse"></div>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="height:auto; margin: 0; padding: 0">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><img
                        src="./images/close.png" alt="Fermer"></button>
                <center>
                    <h4 class="modal-title">Ajouter un classeur </h4>
                </center>
            </div>
            <div class="modal-body">

                <?php

                if (isset($_SESSION['clp_projet']) and !empty($_SESSION['clp_projet'])) { ?>
                    <form method="POST" action="" id="form_classeur">
                        <div class="row">
                            <input type="hidden" name="Code_Classeur">
                            <div class="col-sm-4 col-md-4 mb-3"><label>Libellé</label></div>
                            <div class="col-sm-8 col-md-8 mb-3">
                                <input type="hidden" name="id_projet" <?php echo 'value="' . $_SESSION['clp_projet'] . '"'; ?>>
                                <textarea class="form-control" required placeholder="Libellé" name="libelle_classeur"
                                    id="libelle_classeur"></textarea>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-sm-4 col-md-4 mb-3"><label>Note</label></div>
                            <div class="col-sm-8 col-md-8 mb-3"><textarea class="form-control" required placeholder="Note"
                                    name="note_classeur" id="note_classeur"></textarea></div>
                        </div><br>
                        <div class="row">
                            <div class="col-sm-4 col-md-4 mb-3"><label>Couleur</label></div>
                            <div class="col-sm-8 col-md-8 mb-3"><input type="color" value="#F1F3F6" class="form-control"
                                    placeholder="Couleur" name="couleur" id="couleur"> </div>
                        </div><br>
                        <div class="row">
                            <div class="col-sm-4 col-md-4 mb-3"></div>
                            <div class="col-sm-8 col-md-8 mb-3">
                                <br><button style="width: 150px" <?php echo 'class="btn ' . $Boutton_Style . '"'; ?> id="submit"
                                    type="submit">Inserer</button>
                            </div>
                        </div><br>
                    </form>

                <?php } else { ?>
                    <div class="row ">
                        <div align="center">
                            <h2 align="center"><span style="color:red;">Veuillez s&eacute;lectionner un Projet</span></h2>
                            <img src="./images/dialog-warning.png" width="auto" height="auto" style="margin-top: 27px;">
                        </div>
                    </div>
                <?php }
                ?>

            </div>
            <div class="modal-footer"> <button type="button" class="btn btn-default"
                    data-dismiss="modal">Fermer</button></div>
        </div>
    </div>
</div>



<?php

require_once 'popup.php'; ?>
<div id="add_form_perso_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
      <div class="modal-dialog "  role="document" >
        <div class="modal-content" id="add_form_perso_modal_body">
          <div class="modal-header" style="height:auto; margin: 0; padding: 0">
               <button id="fermer" type="button" class="close" data-dismiss="modal" aria-hidden="true"><img src="./images/close.png" alt="Fermer"></button>
               <center><h4 class="modal-title" id="add_form_perso_modal_titre">Insertion des données </h4></center>
          </div>
       <div id="Form_Contenu_Perso">
       
       </div>
       <div class="modal-footer"> <button id="fermer" type="button" class="btn btn-default" data-dismiss="modal">Fermer</button></div>
</div>
</div>
</div>

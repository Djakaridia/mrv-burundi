﻿<?php
///////////////////////////////////////////////
/*                 SSE                       */
/*	Conception & Développement: BAMASOFT */
///////////////////////////////////////////////
session_start();
if (!isset($_SESSION["clp_id"])) {
  header(sprintf("Location: %s", "./login.php"));
  exit();
}
include_once 'api/configuration.php';
$config = new Config;

require_once 'api/Fonctions.php';
require_once 'api/essentiel.php';
require_once 'theme_components/theme_style.php';
function like_match($pattern, $subject)
{
  $pattern = str_replace('%', '.*', preg_quote($pattern, '/'));
  return (bool) preg_match("/^{$pattern}$/i", $subject);
}
?>
<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <!-- Page title -->
  <title><?php print $config->sitename; ?></title>
  <link rel="shortcut icon" type="image/ico" href="<?php print $config->icon_folder; ?>/favicon.png" />
  <meta name="keywords" content="<?php print $config->MetaKeys; ?>" />
  <meta name="description" content="<?php print $config->MetaDesc; ?>" />
  <meta name="author" content="<?php print $config->MetaAuthor; ?>" />

  <!-- Vendor styles -->
  <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css" />
  <link rel="stylesheet" href="vendor/metisMenu/dist/metisMenu.css" />
  <link rel="stylesheet" href="vendor/animate.css/animate.css" />
  <link rel="stylesheet" href="vendor/bootstrap/dist/css/bootstrap.css" />
  <link rel="stylesheet" href="vendor/select2-3.5.2/select2.css" />
  <link rel="stylesheet" href="vendor/select2-bootstrap/select2-bootstrap.css" />

  <!-- App styles -->
  <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" />
  <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/helper.css" />
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/style_fst.css">

  <!-- Vendor scripts -->
  <script src="vendor/jquery/dist/jquery.min.js"></script>
  <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
  <script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
  <script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="vendor/jquery-flot/jquery.flot.js"></script>
  <script src="vendor/jquery-flot/jquery.flot.resize.js"></script>
  <script src="vendor/jquery-flot/jquery.flot.pie.js"></script>
  <script src="vendor/flot.curvedlines/curvedLines.js"></script>
  <script src="vendor/jquery.flot.spline/index.js"></script>
  <script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
  <script src="vendor/iCheck/icheck.min.js"></script>
  <script src="vendor/peity/jquery.peity.min.js"></script>
  <script src="vendor/sparkline/index.js"></script>
  <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
  <script src="vendor/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>
  <script src="vendor/bootstrap-datepicker-master/dist/locales/bootstrap-datepicker.fr.min.js"></script>
  <script src="vendor/select2-3.5.2/select2.min.js"></script>

  <!-- DataTables -->
  <script src="vendor/datatables/media/js/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <!-- DataTables buttons scripts -->
  <script src="vendor/pdfmake/build/pdfmake.min.js"></script>
  <script src="vendor/pdfmake/build/vfs_fonts.js"></script>
  <script src="vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
  <script src="vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
  <script src="vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
  <script src="vendor/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>

  <!-- App scripts -->
  <script src="scripts/homer.js"></script>

  <!-- Select -->
  <link rel="stylesheet" href="styles/bootstrap-select.css" />
  <script src="scripts/bootstrap-select.js"></script>

</head>

<body class="fixed-navbar fixed fixed-footer sidebar-scroll">
  <?php require_once "./theme_components/header.php"; ?>
  <?php //require_once "./theme_components/main-menu.php"; ?>
  <!-- Main Wrapper -->
  <div id="">
    <?php require_once "./theme_components/sub-header.php"; ?>
    <div class="content animate-panel">
      <div class="row">
        <style>
          .select2-container .select2-choice {
            width: 100%;
            margin-bottom: 5px;
          }

          .row {
            margin-bottom: 10px;
          }
        </style>
        <script>
          $("#search").hide();
          $("#mbreadcrumb").html(<?php $link = "";
          $link .= '<div class="btn-circle-zone">' . do_link("", "./rapports_dynamiques.php", "Annuler", "<span title='Annuler' class='glyphicon glyphicon-arrow-left'></span>", "simple", "./", "btn btn-danger btn-circle mgr-5", "", 1, "", $nfile);
          if (isset($_SESSION['clp_niveau']) && $_SESSION['clp_niveau'] < 2) {
            if (isset($_SESSION['clp_niveau']) && $_SESSION['clp_niveau'] < 2)
              $link .= do_link("btn_rapport", "#myModal", "Enregistrer ce rapport", "<span title='Enregistrer ce rapport' class='glyphicon glyphicon-ok'></span>", "simple", "./", "btn btn-success btn-circle mgr-5", "", 1, "", $nfile);
            //$link .= do_link("","./rapports_dynamiques.php","Annuler","<span title='Annuler' class='glyphicon glyphicon-arrow-left'></span>","simple","./","btn btn-danger btn-circle mgr-5","",1,"",$nfile);
            echo GetSQLValueString($link, "text");
          }
          $link .= '</div>'; ?>);
        </script>
        <?php $db_name = "c0sise0711"; ?>
        <div style0="border:1px solid silver;background: #FFF;padding: 10px;">
          <form id="form_rapport_dynamique" action="traitement_jquery\inserer_rapport_view.php" method="POST">

            <div class="row" style="">
              <div align="center">
                <div class="col-md-12">
                  <label style="float: left;">Nom du rapport</label>
                  <input type="text" name="nom_rapport" id="nom_rapport" class="form-control"
                    placeholder="Nom du rapport">
                </div>
              </div>
            </div>

            <div class="row" style="">
              <div class="col-md-6 col-lg-6 hide">
                <label style="float: left;">Classeur 1</label>
                <select class="form-control selectpicker bts_select" data-live-search="true" name="select_classeur"
                  id="select_classeur" disabled>
                  <option value=""></option>
                  <?php foreach (FC_Rechercher_Code("SELECT * FROM `t_kobo_cols`", $db_name) as $row3)
                    echo '<option value="t_' . $row3["form"] . '">' . $row3["form_label"] . '</option>'; ?>
                </select>
                <label style="float: left;">Classeur 2</label>
                <select class="form-control selectpicker bts_select" data-live-search="true" name="select_classeur2"
                  id="select_classeur2" disabled>
                  <option value=""></option>
                  <?php foreach (FC_Rechercher_Code("SELECT * FROM `t_kobo_cols`", $db_name) as $row3)
                    echo '<option value="t_' . $row3["form"] . '">' . $row3["form_label"] . '</option>'; ?>
                </select>
              </div>
            </div>
            <div class="row">&nbsp;</div>
            <div class="row">
              <div class="col-md-6 col-lg-6">
                <label style="float: left;">Feuille 1</label>
                <select class="form-control selectpicker bts_select" data-live-search="true" name="select_feuille"
                  id="select_feuille">
                  <option value=""></option>
                  <?php foreach (FC_Rechercher_Code("SELECT * FROM `t_kobo_cols`", $db_name) as $row3)
                    echo '<option value="t_' . $row3["form"] . '">' . $row3["form_label"] . '</option>'; ?>
                </select>
              </div>
              <div class="col-md-6 col-lg-6">
                <label style="float: left;">Colonne à lier</label>
                <select name="attribut_jointure_fp" id="attribut_jointure_fp"
                  class="form-control selectpicker bts_select" data-live-search="true" required disabled></select>
              </div>
            </div>
            <div class="row">&nbsp;</div>
            <div class="row">
              <div class="col-md-6 col-lg-6">
                <label style="float: left;">Feuille 2</label>
                <select id="feuille_jointure" name="feuille_jointure" class="form-control selectpicker bts_select"
                  data-live-search="true">
                  <option value=""></option>
                  <?php foreach (FC_Rechercher_Code("SELECT * FROM `t_kobo_cols`", $db_name) as $row3)
                    echo '<option value="t_' . $row3["form"] . '">' . $row3["form_label"] . '</option>'; ?>
                </select>
              </div>
              <div class="col-md-6 col-lg-6">
                <label style="float: left;">Colonne à lier</label>
                <select name="attribut_jointure_fs" id="attribut_jointure_fs"
                  class="form-control selectpicker bts_select" data-live-search="true" required disabled></select>
              </div>
            </div>
            <div class="row">&nbsp;</div>
            <div class="row">
              <div class="col-md-3 col-lg-3">
                <label style="text-align: left;">Element en Colonne</label>
                <select name="colonne_x" id="colonne_x" class="form-control selectpicker bts_select"
                  data-live-search="true"></select>
              </div>
              <div class="col-md-3 col-lg-3">
                <label style="float: left;">Element en Ligne</label>
                <select name="colonne_y" id="colonne_y" class="form-control selectpicker bts_select"
                  data-live-search="true"></select>
              </div>
              <div class="col-md-3 col-lg-3">
                <label style="float: left;"> Colonne de valeur</label>
                <select name="input_valeur" id="input_valeur" class="form-control selectpicker bts_select"
                  data-live-search="true"></select>
              </div>
              <div class="col-md-3 col-lg-3">
                <label style="float: left;">Opération</label>
                <select id="operation" name="operation" class="form-control">
                  <option value=""></option>
                  <option value="COUNT">COMPTER</option>
                  <option value="SUM">SOMME</option>
                  <option value="AVG">MOYENNE</option>
                </select>
              </div>
            </div>
            <div class="row">&nbsp;</div>
            <div class="row">
              <div class="col-md-4 col-lg-4">
                <label style="float: left;">Mode d'affichage</label>
                <select id="mode_affichage" name="mode_affichage" class="form-control">
                  <option value="1">Vertical (Tableau à coté du Graphique)</option>
                  <option value="2">Vertical (Graphique à coté du Tableau)</option>
                  <option value="3">Horizontal (Tableau à coté du Graphique)</option>
                  <option value="4">Horizontal (Graphique à coté du Tableau)</option>
                  <option value="5">Séparé (Tableau puis le Graphique séparément)</option>
                </select>
              </div>
              <div class="col-md-4 col-lg-4">
                <label style="float: left;">Type de graphique d'affichage</label>
                <select id="type_graphique" name="type_graphique" class="form-control">
                  <option value="column">Histogramme</option>
                  <option value="pie">Camembert</option>
                  <option value="area">Courbe</option>
                </select>
              </div>
              <div class="col-md-4 col-lg-4">
                <label style="float: left;">Afficher sur écran</label>
                <select id="affichage" name="affichage" class="form-control">
                  <option value="0">Non</option>
                  <option value="1">Oui</option>
                </select>
              </div>
            </div>
        </div>
        <div class="row">&nbsp;</div>
        <div align="center">
          <button style="width: 150px;" type="button" id="Boutton_Ajouter_Critere" disabled <?php echo 'class="btn ' . $Boutton_Style . '"'; ?>>Ajouter un critère</button>
        </div>
        <div class="row">&nbsp;</div>
        <div id="div_criteres" style="background-color:beige; margin:5px; border-radius: 5px; border:1px solid red">
          <div class="row">
            <div class="col-lg-11" align="center">
              <h2>Critères</h2>
            </div>
          </div>
        </div>

        <br><br>
        <section id="Champs"></section>
        </form>
      </div>

      <script type="text/javascript">
        var CHAMPS_FP_FS = "";
        var COLS_FP = "";
        var COLS_FS = "";

        document.getElementById("select_classeur").addEventListener("change", function (e) {

          document.getElementById("operation").value = "";

          VIDER_DIV_CRITERE();

          $("#colonne_x").html("");
          $("#colonne_y").html("");
          $("#input_valeur").html("");
          $('.selectpicker').selectpicker('refresh');
          document.getElementById("select_classeur2").value = "";
          document.getElementById("feuille_jointure").disabled = true; document.getElementById("feuille_jointure").value = "";
          document.getElementById("attribut_jointure_fp").disabled = true; document.getElementById("attribut_jointure_fp").value = "";
          document.getElementById("attribut_jointure_fs").disabled = true; document.getElementById("attribut_jointure_fs").value = "";

          if (document.getElementById("select_classeur").value != "") {
            $.ajax({
              url: "traitement_jquery/liste_feuille_par_view.php", method: "POST", data: $('#form_rapport_dynamique').serialize(), success: function (data) {
                if (data != '') { $("#select_feuille").html(data); $('.selectpicker').selectpicker('refresh'); }
                else { }
              }
            });
          }
          else { $("#select_feuille").html(""); $('.selectpicker').selectpicker('refresh'); }

        });


        document.getElementById("select_classeur2").addEventListener("change", function (e) {

          COLS_FS = "";
          $("#colonne_x").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
          $("#colonne_y").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
          $("#input_valeur").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
          $('.selectpicker').selectpicker('refresh');
          document.getElementById("feuille_jointure").value = "";
          document.getElementById("attribut_jointure_fp").value = "";
          document.getElementById("attribut_jointure_fs").value = "";

          if (document.getElementById("select_classeur2").value != "") {
            $.ajax({
              url: "traitement_jquery/liste_feuille_par_view_2.php", method: "POST", data: $('#form_rapport_dynamique').serialize(), success: function (data) {

                if (data != '') { $("#feuille_jointure").html(data); $('.selectpicker').selectpicker('refresh'); }
                else { }
              }
            });
          }
          else { $("#feuille_jointure").html(""); $('.selectpicker').selectpicker('refresh'); }

        });


        document.getElementById("select_feuille").addEventListener("change", function (e) {
          VIDER_DIV_CRITERE();
          document.getElementById("colonne_x").value = "";
          document.getElementById("colonne_y").value = "";
          document.getElementById("input_valeur").value = "";
          document.getElementById("operation").value = "";
          document.getElementById("attribut_jointure_fs").value = "";
          document.getElementById("attribut_jointure_fp").value = "";
          document.getElementById("feuille_jointure").value = "";
          $('.selectpicker').selectpicker('refresh');
          if (document.getElementById("select_feuille").value != "") {
            $.ajax({
              url: "traitement_jquery/liste_colonnes_par_view.php", method: "POST", data: $('#form_rapport_dynamique').serialize(), success: function (data) {
                if (data != '') {
                  COLS_FP = data;
                  $("#colonne_x").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
                  $("#colonne_y").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
                  $("#input_valeur").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
                  $("#attribut_jointure_fp").html(COLS_FP);
                  $('.selectpicker').selectpicker('refresh');
                  document.getElementById("feuille_jointure").disabled = false;

                  $.ajax({
                    url: "traitement_jquery/liste_champ_critere_par_view.php", method: "POST", data: $('#form_rapport_dynamique').serialize(), success: function (data) {
                      if (data != '') { CHAMPS_FP_FS = '<optgroup label="Feuille 1 / Feuille 2">' + data + '</optgroup><optgroup label="Feuille 2">'; } else { }
                    }
                  });
                  $('.selectpicker').selectpicker('refresh');
                }
                else { }
              }
            });
            document.getElementById("Boutton_Ajouter_Critere").disabled = false;
          }
          else {
            $("#colonne_x").html(""); $("#colonne_y").html(""); $("#input_valeur").html(""); $("#attribut_jointure_fp").html();
            document.getElementById("feuille_jointure").disabled = true; document.getElementById("feuille_jointure").value = "";
            document.getElementById("Boutton_Ajouter_Critere").disabled = true;
          }
        });


        document.getElementById("feuille_jointure").addEventListener("change", function (e) {
          VIDER_DIV_CRITERE();
          $('.selectpicker').selectpicker('refresh');
          if (document.getElementById("feuille_jointure").value != "") {
            document.getElementById("attribut_jointure_fp").disabled = false; document.getElementById("attribut_jointure_fs").disabled = false;
            $.ajax({
              url: "traitement_jquery/liste_colonnes_par_view_jointure.php", method: "POST", data: $('#form_rapport_dynamique').serialize(), success: function (data) {
                if (data != '') {
                  COLS_FS = data;

                  $("#colonne_x").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
                  $("#colonne_y").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));
                  $("#input_valeur").html(COLS_FP + COLS_FS.replace('<option value=""></option>', ''));

                  $("#attribut_jointure_fs").html(COLS_FS);

                  $.ajax({
                    url: "traitement_jquery/liste_champ_critere_par_view.php", method: "POST", data: $('#form_rapport_dynamique').serialize(), success: function (data) {
                      if (data != '') { CHAMPS_FP_FS =/*'<optgroup label="Feuille 2">'+*/data/*+'</optgroup>'*/; } else { }
                    }
                  });
                  $('.selectpicker').selectpicker('refresh');
                }
                else { }
              }
            });

          }
          else {
            document.getElementById("attribut_jointure_fp").disabled = true; document.getElementById("attribut_jointure_fp").value = "";
            document.getElementById("attribut_jointure_fs").disabled = true; document.getElementById("attribut_jointure_fs").value = "";
          }
        });

      </script>



      <script type="text/javascript">
        var class_select_champ = document.getElementsByName("class_select_champ[]");
        var champ_input = document.getElementsByName("champ_input[]");
        var class_group_by = document.getElementsByClassName("class_group_by");
        var class_colonne_valeur = document.getElementsByClassName("class_colonne_valeur");


      </script>

      <!-- Vendor scripts -->

      <script type="text/javascript">
        $(document).ready(function () {
          //$(".select2-select-00").select2({allowClear:true});
          $(document).on('click', '#btn_rapport', function () {

            if (document.getElementById("nom_rapport").value == "" || document.getElementById("select_feuille").value == "" || (document.getElementById("colonne_x").value == "" && document.getElementById("colonne_y").value == "") || document.getElementById("input_valeur").value == "" || document.getElementById("operation").value == "") { alert("Veuillez renseigner tous les champs"); }
            else if (document.getElementById("feuille_jointure").value != "" && (document.getElementById("attribut_jointure_fp").value == "" || document.getElementById("attribut_jointure_fs").value == "")) { alert("Veuillez renseigner tous les champs"); }
            else {
              var champ_criteres = document.getElementById('champ_criteres[]');
              var condition_criteres = document.getElementById('condition_criteres[]');
              var valeur_criteres = document.getElementById('valeur_criteres[]');
              /*for(i=0; i<champ_criteres.length; i++)
                {if(champ_criteres[i].value!="" && valeur_criteres[i].value==""){alert("Veuillez remplir le champ Valeur"); return ;}}*/

              $.ajax({
                url: "traitement_jquery/inserer_rapport_view.php", method: "POST", data: $('#form_rapport_dynamique').serialize(), success: function (data) {
                  if (!data) window.location.href = "rapports_dynamiques.php";
                  else alert(data);
                }
              });
              //$('#form_rapport_dynamique').submit();

            }
          });

        });

        var INDEX = 0;

        function Ajouter_Critere() {
          INDEX++;
          $("#div_criteres").append('<div id="criteres_' + INDEX + '">' + '<div class="row"><div class="col-lg-2" align="center"><label></label></div><div class="col-lg-2" align="center"><label>ET / OU</label></div><div class="col-lg-2" align="center"><label>Champ</label></div><div class="col-lg-2" align="center"><label>Condition</label></div><div class="col-lg-2" align="center"><label>Valeur</label></div><div class="col-lg-2" align="center"><label></label></div></div><div class="row"><div class="col-lg-2" align="center"></div><div class="col-lg-2" align="center"><select  id="et_ou_criteres[]" name="et_ou_criteres[]" class="form-control"><option>ET</option><option>OU</option></select></div><div class="col-lg-2" align="center"><select  id="champ_criteres[]" name="champ_criteres[]" class="form-control selectpicker bts_select" data-live-search="true">' + CHAMPS_FP_FS + '</select></div><div class="col-lg-2" align="center"><select  id="condition_criteres[]" name="condition_criteres[]" class="form-control"><option value="=">Egal (=)</option><option value=">">Supérieur (&gt;)</option><option value="<">Inférieur (&lt;)</option><option value=">=">Supérieur ou égal (&gt;=)</option><option value="<=">Inférieur ou égal (&lt;=)</option><option value="<>">Différent (!= / &lt;&gt;)</option><option value="%x%">Contenant (%x%)</option><option value="x%">Commençant par (x%)</option><option value="%x">Terminant par (%x)</option></select></div><div class="col-lg-2" align="center"><input type="text" name="valeur_criteres[]" id="valeur_criteres[]" placeholder="Valeur" class="form-control"></div><div class="col-lg-2" align="center"><a onclick="document.getElementById(\'criteres_' + INDEX + '\').innerHTML=\'\'"><span class="glyphicon glyphicon-remove text-danger"></span></a></div></div></div>');
          $('.selectpicker').selectpicker('refresh');
        }

        document.getElementById("Boutton_Ajouter_Critere").addEventListener("click", Ajouter_Critere);

        function VIDER_DIV_CRITERE() { $("#div_criteres").html('<div class="row"><div class="col-lg-11" align="center"><h2>Critères</h2></div></div>'); CHAMPS_FP_FS = ""; $('.selectpicker').selectpicker('refresh'); }
      </script>


    </div>
  </div>
  <?php require_once "./theme_components/footer.php"; ?>
  </div>

</body>

</html>
<?php
///////////////////////////////////////////////
/*                 SSE                       */
/*  Conception & Développement: BAMASOFT */
///////////////////////////////////////////////

include_once 'api/configuration.php';
$config = new Config;

require_once 'api/Fonctions.php';
require_once 'theme_components/theme_style.php';

$Res5 = null;
$Code_Rapport = "";
if (isset($_GET['r']) and !empty($_GET['r'])) {
    $Code_Rapport = base64_decode($_GET['r']);
    $Nom_Rapport = "";
    $ii = 0;
    foreach (FC_Rechercher_Code('SELECT * FROM t_rapport WHERE Code_Rapport=\'' . $Code_Rapport . '\'') as $row4) {
        $ii++;
        $uuu = 0;
        $Nom_Rapport = $row4['Nom_Rapport'];

        if ($ii == 0) {
            header('location:mobile_rapports_dynamiques.php');
        }

    }
} else {
    header('location:mobile_rapports_dynamiques.php');
}
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title><?php print $config->sitename; ?></title>
    <link rel="shortcut icon" type="image/ico" href="<?php print $config->icon_folder; ?>/favicon.png" />
    <meta name="keywords" content="<?php print $config->MetaKeys; ?>" />
    <meta name="description" content="<?php print $config->MetaDesc; ?>" />
    <meta name="author" content="<?php print $config->MetaAuthor; ?>" />

    <!-- Vendor styles -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css" />
    <link rel="stylesheet" href="vendor/metisMenu/dist/metisMenu.css" />
    <link rel="stylesheet" href="vendor/animate.css/animate.css" />
    <link rel="stylesheet" href="vendor/bootstrap/dist/css/bootstrap.css" />

    <!-- App styles -->
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/helper.css" />
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/style_fst.css">

    <!-- Vendor scripts -->
    <script src="vendor/jquery/dist/jquery.min.js"></script>
    <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
    <script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.resize.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.pie.js"></script>
    <script src="vendor/flot.curvedlines/curvedLines.js"></script>
    <script src="vendor/jquery.flot.spline/index.js"></script>
    <script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
    <script src="vendor/iCheck/icheck.min.js"></script>
    <script src="vendor/peity/jquery.peity.min.js"></script>
    <script src="vendor/sparkline/index.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/locales/bootstrap-datepicker.fr.min.js"></script>

    <!-- DataTables -->
    <script src="vendor/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <!-- DataTables buttons scripts -->
    <script src="vendor/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendor/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendor/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>

    < <script src="https://code.highcharts.com/highcharts.js">
        </script>
        <script src="https://code.highcharts.com/modules/data.js"></script>
        <script src="https://code.highcharts.com/modules/exporting.js"></script>
        <script src="https://code.highcharts.com/modules/export-data.js"></script>
        <script src="https://code.highcharts.com/modules/accessibility.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
        <script src="https://code.highcharts.com/modules/export-xlsx.js"></script>

        <script src="https://cdn.sheetjs.com/xlsx-latest/package/dist/xlsx.full.min.js"></script>
        <!-- App scripts -->
        <script src="scripts/homer.js"></script>

        <style type="text/css">
            .change-chart {
                margin: 5px 3px;
                border-radius: 50px !important;
                box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease-in-out;
            }

            .change-chart:hover {
                transform: scale(1.1);
            }
        </style>
        <style>
            #datatable {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #fff;
                overflow: hidden;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            }

            #datatable thead th {
                background: linear-gradient(to right, #007bff, #0056b3);
                color: white;
                font-weight: 600;
                padding: 12px;
                text-align: center;
            }

            #datatable tbody td {
                padding: 10px;
                text-align: center;
                border-top: 1px solid #f1f1f1;
            }

            #datatable tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            #datatable tr:hover {
                background-color: #eaf4ff;
                transition: background-color 0.2s ease;
            }
        </style>
</head>

<body class="fixed-navbar fixed fixed-footer sidebar-scroll">
    <?php //require_once "./theme_components/main-menu.php"; ?>
    <!-- Main Wrapper -->
    <div id="">
        <div class="content animate-panel">
            <div class="row">


                <style type="text/css">
                    @media print {

                        #header,
                        #menu,
                        .bar_header,
                        .showhide,
                        .small-header,
                        .footer {
                            display: none
                        }

                        #wrapper {
                            margin: 0px;
                            padding: 0px;
                            width: 100%
                        }

                        body {
                            margin: 0;
                            padding: 0
                        }

                        .contenu {
                            display: table;
                            width: 20cm;
                            margin: 0px;
                            padding: 0px
                        }

                        .graph_div {
                            break-before: always;
                        }
                    }

                    .flot-chart-pie-content {
                        width: 100%;
                        height: 100%;
                        margin: auto;
                    }

                    .flot-pie-chart {
                        display: block;
                        padding-top: 0px;
                        height: 500px;
                    }
                </style>

                <?php echo '<script type="text/javascript" charset="utf-8" > var Code_Rapport="' . base64_encode($Code_Rapport) . '";</script>'; ?>

                <form id="form_perso_feuille_donnees">
                </form>

                <div class="content" style="background: #FFF;padding: 0 10px;">

                    <div style="background-color: white">
                        <?php require_once 'requires/formulaire_insertion_123.php'; ?>
                        <div class="tab-content">
                            <?php
                            $ind = 0;
                            foreach (FC_Rechercher_Code('SELECT * FROM t_rapport WHERE Code_Rapport=' . $Code_Rapport) as $row5) {
                                $ind++;
                                ?>

                                <div class="row" style="font-size: 14px" align="left">
                                    <br>
                                    <div class="col-lg-2" style="cursor: pointer; display: none"><span
                                            class="glyphicon glyphicon-asterisk <?php echo $Text_Style; ?>">
                                        </span><span class="dropdown label ">
                                            <a class="dropdown-toggle label-menu-corner <?php echo $Text_Style; ?>" href="#"
                                                data-toggle="dropdown">Imprimer</a>
                                        </span>
                                    </div>

                                    <div class="col-lg-2" style="cursor: pointer; display: none"><span
                                            class="glyphicon glyphicon-asterisk <?php echo $Text_Style; ?>"></span>
                                        <span class="dropdown label ">
                                            <a class="dropdown-toggle label-menu-corner <?php echo $Text_Style; ?>" href="#"
                                                data-toggle="dropdown">Affichage sur mobile</a>

                                        </span>
                                    </div>

                                    <div class="col-lg-2"></div>

                                    <div class="col-lg-2" style="cursor: pointer; display: none"><span
                                            class="glyphicon glyphicon-asterisk <?php echo $Text_Style; ?>"></span><span
                                            class=" label <?php echo $Text_Style; ?>" <?php echo 'onclick="Importer_Donnes(\'\')"'; ?>>Importer</span></div>

                                    <div class="col-lg-2" style="cursor: pointer; display: none"><span
                                            class="glyphicon glyphicon-asterisk <?php echo $Text_Style; ?>"></span><span
                                            class=" label <?php echo $Text_Style; ?>" <?php echo 'onclick="Telecharger_Fichier_Excel(\'\',\'\')"'; ?>>Exporter</span></div>
                                    <script type="text/javascript">

                                    </script>
                                    <div class="col-lg-2" style="cursor: pointer; display: none" <?php echo 'onclick="Afficher_Formulaire_Insertion(\'\')"'; ?>><span
                                            class="glyphicon glyphicon-asterisk <?php echo $Text_Style; ?>"></span><span
                                            class=" label <?php echo $Text_Style; ?>">Nouvelle donnée</span></div>
                                </div>

                                <!--   <div class="mb-3 text-right">

                                    <button class="btn btn-sm btn-success" onclick="exportTableToXLSX('datatable')"> <i
                                            class="fas fa-file-excel"></i>Excel</button>
                                    <button class="btn btn-sm btn-primary"
                                        onclick="exportTableToWord('datatable', 'rapport')"><i class="fas fa-file-word"></i>
                                        Word</button>
                                    <button class="btn btn-sm btn-danger" onclick="exportTableToPDF('datatable')"><i
                                            class="fas fa-file-pdf"></i> PDF</button>
                                    <button class="btn btn-sm btn-info" onclick="exportChart()"><i class="fas fa-image"></i>
                                        Export Graphique</button>
                                </div> -->
                                <script>
                                    var rapportTitle = <?php echo json_encode($row5['Nom_Rapport']); ?>;
                                </script>
                                <?php
                                echo '<div class="text-center">
     <h2 id="rapport-title" class="text-primary mb-4 d-inline-block" style="padding-left: 10px; font-weight: 600;">' .
                                    htmlspecialchars($row5['Nom_Rapport']) .
                                    '</h2>
</div>';
                                echo '<div class="row">
    <div class="col-lg-6">
        <div class="hpanel">
           
            <div class="panel-body">
                <div class="table-responsive">
                <table id="datatable" cellpadding="1" cellspacing="1" class="table contenu">
<tr style=" background-color:#F1F3F6; text-align: center">';

                                $COLONNE_X = "";
                                $COLONNE_Y = "";
                                $VALEUR = "valeur";

                                $Exp_COLONNE_Y = explode(".", $row5["Colonne_Y"]);
                                $Exp_COLONNE_X = explode(".", $row5["Colonne_X"]);

                                foreach (FC_Rechercher_Code("SELECT `t_feuille_ligne`.`Nom_Ligne` FROM `t_feuille_ligne` INNER JOIN `t_feuille` ON (t_feuille_ligne.Code_Feuille = t_feuille.Code_Feuille) WHERE (t_feuille.Table_Feuille = '" . str_replace("v", "t", $Exp_COLONNE_Y[0]) . "' AND t_feuille_ligne.Nom_Collone = '" . $Exp_COLONNE_Y[1] . "')") as $row6) {
                                    echo "<th><sub>" . $row6["Nom_Ligne"] . "</sub> | ";
                                }

                                $COLONNE_Y = $row5["Colonne_Y"];
                                foreach (FC_Rechercher_Code("SELECT `t_feuille_ligne`.`Nom_Ligne` FROM `t_feuille_ligne` INNER JOIN `t_feuille` ON (t_feuille_ligne.Code_Feuille = t_feuille.Code_Feuille) WHERE (t_feuille.Table_Feuille = '" . str_replace("v", "t", $Exp_COLONNE_X[0]) . "' AND t_feuille_ligne.Nom_Collone = '" . $Exp_COLONNE_X[1] . "')") as $row6) {
                                    echo "<sup>" . $row6["Nom_Ligne"] . "</sup></th>";
                                }

                                $COLONNE_X = $row5["Colonne_X"];
                                /*foreach (FC_Rechercher_Code("SELECT * FROM t_feuille_ligne WHERE(Code_Feuille=".$row5["Code_Feuille"]." AND Nom_Ligne='".$row5["Valeur"]."')") as $row12) 
                                {$VALEUR=$row12["Nom_Collone"];}*/

                                try {
                                    $COLONNE_X_TAB = null;
                                    $COLONNE_Y_TAB = null;
                                    $indd = 0;
                                    $indu = 0;
                                    $i = 0;
                                    $compte = 0;

                                    $Col_Y = "";
                                    $Col_X = "";

                                    $Res1 = FC_Rechercher_Code("SELECT DISTINCT(`$COLONNE_X`) FROM " . $row5['Nom_View']);
                                    if ($Res1 != null) {
                                        foreach ($Res1 as $row10) {
                                            echo "<th>" . $row10[0] . "</th>";
                                            $COLONNE_X_TAB[] = $row10[0];
                                            $Col_X .= " SUM(CASE WHEN `$COLONNE_X` LIKE '" . addslashes($row10[0]) . "' THEN $VALEUR ELSE NULL END) AS " . str_replace(" ", "", addslashes($row10[0])) . "_c,";
                                        }
                                    }
                                    $Col_X = substr($Col_X, 0, strlen($Col_X) - 1);

                                    $Res2 = FC_Rechercher_Code("SELECT DISTINCT(`$COLONNE_Y`) FROM " . $row5['Nom_View']);
                                    if ($Res2 != null) {
                                        foreach ($Res2 as $row11) {
                                            $COLONNE_Y_TAB[] = $row11[0];
                                        }
                                    }



                                    echo '</tr>';

                                    $SQL_Code = "
SELECT `$COLONNE_Y`,
$Col_X
FROM " . $row5['Nom_View'] . " GROUP BY `$COLONNE_Y`";
                                    //echo $SQL_Code;
                                    $Res5 = FC_Rechercher_Code($SQL_Code);
                                    if ($Res5 != null) {

                                        foreach ($Res5 as $key5) {
                                            echo "<tr>";
                                            echo "<td>" . $key5["$COLONNE_Y"] . "</td>";
                                            for ($i = 0; $i < count($COLONNE_X_TAB); $i++) {

                                                if ($key5[str_replace(" ", "", $COLONNE_X_TAB[$i]) . "_c"] == "") {
                                                    echo "<td>-</td>";
                                                } else {
                                                    echo "<td>" . number_format($key5[str_replace(" ", "", $COLONNE_X_TAB[$i]) . "_c"], 0, '', ' ') . "</td>";
                                                }


                                            }
                                            echo "</tr>";
                                        }
                                    }

                                } catch (Exception $e) {
                                }
                                echo '</table></div>

            </div>
            <div class="panel-footer">
              ';
                                if ($COLONNE_Y_TAB != null) {
                                    echo count($COLONNE_Y_TAB);
                                } else {
                                    echo "0";
                                }


                                echo ' ligne(s)  
            </div>
        </div>
    </div>';
                                ?>


                                <div class="col-lg-6 graph_div">
                                    <div class="hpanel">
                                        <div class="col-12 text-center my-3">
                                            <button class="btn btn-sm btn-primary change-chart" data-type="column"><i
                                                    class="fas fa-chart-bar"></i></button>
                                            <button class="btn btn-sm btn-success change-chart" data-type="line"><i
                                                    class="fas fa-chart-line"></i></button>
                                            <button class="btn btn-sm btn-warning change-chart" data-type="spline"><i
                                                    class="fas fa-wave-square"></i></button>
                                            <button class="btn btn-sm btn-info change-chart" data-type="area"><i
                                                    class="fas fa-chart-area"></i></button>
                                            <button class="btn btn-sm btn-dark change-chart" data-type="column-3d"><i
                                                    class="fas fa-cube"></i> 3D Column</button>
                                            <button class="btn btn-sm btn-outline-warning change-chart"
                                                data-type="pie-3d"><i class="fas fa-circle-notch"></i> 3D Pie</button>
                                        </div>
                                        <div class="panel-body">
                                            <div class="table-responsive">
                                                <!--  <div id="color-picker-container">
                                                    <form id="color-form">
                                                        <?php foreach (FC_Rechercher_Code('SELECT libelle, code FROM couleurs') as $row) { ?>
                                                            <label>
                                                                <?= htmlspecialchars($row['libelle']) ?> :
                                                                <input type="color" class="color-input" name="colors[]"
                                                                    value="<?= htmlspecialchars($row['code']) ?>">
                                                            </label><br>
                                                        <?php }
                                                        ; ?>
                                                    </form>
                                                    <button type="button" onclick="applyColorsAndDrawChart()">Appliquer les
                                                        couleurs</button>
                                                </div> -->
                                                <div id="container" style="height: 400px"></div>
                                                <?php




                                                try {
                                                    $Script_Js = "";
                                                    substr($Script_Js, 0, strlen($Script_Js) - 1);

                                                    echo '<script type="text/javascript"> var data3 = [ ' . $Script_Js . ']; </script>';
                                                } catch (Exception $e) {
                                                }
                                                echo '</div>

            </div>
            <div class="panel-footer"> 
            </div>
        </div>
    </div></div>
  </div>';

                                                ?>


                                                <?php
                            }
                            ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php //require_once "./theme_components/footer.php"; ?>
                    </div>

                    <script type="text/javascript">
                        let chart;

                        document.addEventListener("DOMContentLoaded", function () {
                            drawDefaultChart('column'); // initialisation avec un type standard

                            document.querySelectorAll('.change-chart').forEach(button => {
                                button.addEventListener('click', function () {
                                    const type = this.getAttribute('data-type');
                                    const innerSize = this.getAttribute('data-innerSize') || '0%';

                                    if (type === 'column-3d') {
                                        draw3DColumnChart();
                                    } else if (type === 'pie-3d') {
                                        draw3DPieChart();
                                    } else {
                                        drawDefaultChart(type, innerSize);
                                    }
                                });
                            });
                        });

                        function drawDefaultChart(type = 'column', innerSize = '0%') {
                            chart = Highcharts.chart('container', {
                                data: { table: 'datatable' },
                                chart: { type: type, height: 400 },
                                title: { text: rapportTitle },
                                xAxis: { title: { text: null }, gridLineWidth: 1, lineWidth: 0 },
                                yAxis: {
                                    min: 0,
                                    title: { text: 'Nombre', align: 'high' },
                                    labels: { overflow: 'justify' },
                                    gridLineWidth: 0
                                },
                                tooltip: {
                                    formatter: function () {
                                        return `<b>${this.series.name}</b><br>${this.point.y} ${this.point.name?.toLowerCase() || ''}`;
                                    }
                                },
                                plotOptions: {
                                    series: {
                                        dataLabels: {
                                            enabled: true,
                                            format: '{y}',
                                            style: { fontSize: '12px', fontWeight: 'bold', color: '#000' }
                                        }
                                    },
                                    pie: {
                                        innerSize: innerSize,
                                        allowPointSelect: true,
                                        cursor: 'pointer',
                                        showInLegend: true,
                                        dataLabels: {
                                            enabled: true,
                                            format: '{point.name}: {point.y}',
                                            style: { fontSize: '12px', fontWeight: 'bold' }
                                        }
                                    }
                                },
                                legend: {
                                    layout: 'vertical',
                                    align: 'right',
                                    verticalAlign: 'top',
                                    x: -40,
                                    y: 50,
                                    floating: true,
                                    borderWidth: 1,
                                    backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || '#FFFFFF',
                                    shadow: true
                                },
                                credits: {
                                    enabled: true,
                                    text: 'SISE RESI-2P : ' + new Date().toLocaleString('fr-FR'),
                                    href: '#',
                                    style: { cursor: 'pointer', color: '#6633FF', fontSize: '10px' }
                                },
                                exporting: {
                                    filename: rapportTitle,
                                    buttons: {
                                        contextButton: {
                                            menuItems: [
                                                "downloadPNG",
                                                "downloadJPEG",
                                                "downloadPDF",
                                                "downloadSVG",
                                                "downloadXLSX"
                                            ]
                                        }
                                    }
                                }
                            });
                        }

                        function draw3DColumnChart() {
                            chart = Highcharts.chart('container', {
                                chart: {
                                    type: 'column',
                                    options3d: {
                                        enabled: true,
                                        alpha: 15,
                                        beta: 15,
                                        viewDistance: 25,
                                        depth: 40
                                    }
                                },
                                title: { text: '' },
                                xAxis: {
                                    categories: [
                                        <?php for ($i = 0; $i < count($COLONNE_X_TAB); $i++) {
                                            echo "'" . $COLONNE_X_TAB[$i] . "'";
                                            if ($i < count($COLONNE_X_TAB) - 1)
                                                echo ",";
                                        } ?>
                                    ],
                                    labels: {
                                        skew3d: true,
                                        style: { fontSize: '16px' }
                                    }
                                },
                                yAxis: {
                                    allowDecimals: false,
                                    min: 0,
                                    title: { text: '', skew3d: true }
                                },
                                tooltip: {
                                    headerFormat: '<b>{point.key}</b><br>',
                                    pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y} / {point.stackTotal}'
                                },
                                plotOptions: {
                                    column: {
                                        stacking: 'normal',
                                        depth: 40,
                                        dataLabels: {
                                            enabled: true,
                                            color: '#000',
                                            style: {
                                                textOutline: 'none',
                                                fontWeight: 'normal',
                                                fontSize: '13px'
                                            }
                                        }
                                    }
                                },
                                series: [
                                    <?php
                                    $Res5 = FC_Rechercher_Code($SQL_Code);
                                    if ($Res5 != null) {
                                        foreach ($Res5 as $key5) {
                                            echo "{name:'" . addslashes($key5["$COLONNE_Y"]) . "', data: [";
                                            for ($i = 0; $i < count($COLONNE_X_TAB); $i++) {
                                                $val = $key5[$COLONNE_X_TAB[$i] . "_c"];
                                                echo ($val === "" ? "0" : $val);
                                                if ($i < count($COLONNE_X_TAB) - 1)
                                                    echo ",";
                                            }
                                            echo "], stack: 'male'},";
                                        }
                                    }
                                    ?>
                                ]
                            });
                        }

                        function draw3DPieChart() {
                            chart = Highcharts.chart('container', {
                                chart: {
                                    type: 'pie',
                                    options3d: {
                                        enabled: true,
                                        alpha: 45,
                                        beta: 0
                                    }
                                },
                                title: { text: '' },
                                tooltip: {
                                    pointFormat: '<b>{point.name}</b>: {point.y} ({point.percentage:.1f}%)'
                                },
                                plotOptions: {
                                    pie: {
                                        allowPointSelect: true,
                                        depth: 45,
                                        dataLabels: {
                                            enabled: true,
                                            format: '{point.name}: {point.y}'
                                        }
                                    }
                                },
                                series: [{
                                    name: 'Valeur',
                                    data: [
                                        <?php
                                        $ResPie = FC_Rechercher_Code($SQL_Code);
                                        if ($ResPie != null) {
                                            foreach ($ResPie as $key5) {
                                                $label = addslashes($key5["$COLONNE_Y"]);
                                                $value = 0;
                                                for ($i = 0; $i < count($COLONNE_X_TAB); $i++) {
                                                    $value += (int) ($key5[$COLONNE_X_TAB[$i] . "_c"] ?: 0);
                                                }
                                                echo "['$label', $value],";
                                            }
                                        }
                                        ?>
                                    ]
                                }]
                            });
                        }
                    </script>
                    <!--  <script>
                        function getReportTitle() {
                            let titleElement = document.getElementById('rapport-title');
                            return titleElement ? titleElement.textContent.trim().replace(/[^a-zA-Z0-9_\-]/g, '_') : 'rapport';
                        }

                        function exportTableToXLSX(tableID) {
                            const filename = getReportTitle();
                            let workbook = XLSX.utils.book_new();
                            let worksheet = XLSX.utils.table_to_sheet(document.getElementById(tableID));
                            XLSX.utils.book_append_sheet(workbook, worksheet, "Feuille1");
                            XLSX.writeFile(workbook, filename + ".xlsx");
                        }

                        function exportTableToWord(tableID) {
                            const filename = getReportTitle();
                            let header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' " +
                                "xmlns:w='urn:schemas-microsoft-com:office:word' " +
                                "xmlns='http://www.w3.org/TR/REC-html40'>" +
                                "<head><meta charset='utf-8'></head><body>";
                            let footer = "</body></html>";
                            let sourceHTML = header;

                            // Ajouter le titre dans le Word
                            const titleText = document.getElementById('rapport-title')?.outerHTML || '';
                            sourceHTML += titleText;

                            // Ajouter le tableau
                            sourceHTML += document.getElementById(tableID).outerHTML + footer;

                            let source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
                            let fileDownload = document.createElement("a");
                            document.body.appendChild(fileDownload);
                            fileDownload.href = source;
                            fileDownload.download = filename + '.doc';
                            fileDownload.click();
                            document.body.removeChild(fileDownload);
                        }

                        async function exportTableToPDF(tableID) {
                            const filename = getReportTitle();
                            const { jsPDF } = window.jspdf;
                            const doc = new jsPDF('p', 'pt', 'a4');

                            // Créer un conteneur temporaire avec le titre + tableau
                            const title = document.getElementById('rapport-title')?.cloneNode(true);
                            const table = document.getElementById(tableID).cloneNode(true);

                            const container = document.createElement('div');
                            if (title) container.appendChild(title);
                            container.appendChild(table);
                            container.style.background = "#fff"; // éviter transparence
                            container.style.padding = "20px";

                            document.body.appendChild(container); // nécessaire pour html2canvas

                            await html2canvas(container).then(canvas => {
                                const imgData = canvas.toDataURL('image/png');
                                const imgProps = doc.getImageProperties(imgData);
                                const pdfWidth = doc.internal.pageSize.getWidth();
                                const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                                doc.addImage(imgData, 'PNG', 20, 20, pdfWidth - 40, pdfHeight);
                                doc.save(filename + ".pdf");
                            });

                            document.body.removeChild(container); // nettoyage
                        }

                        function exportChart() {
                            Highcharts.charts.forEach(function (chart) {
                                if (chart && chart.exportChart) {
                                    chart.exportChart({ type: 'application/pdf' }); // ou 'image/png'
                                }
                            });
                        }
                    </script> -->

</body>

</html>
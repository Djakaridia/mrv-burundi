<?php
///////////////////////////////////////////////
/*                 SSE                       */
/*	Conception & Développement: BAMASOFT */
///////////////////////////////////////////////
session_start();

if (isset($_SESSION["id"])) {
    header(sprintf("Location: %s", "./"));
    exit;
}
include_once 'api/configuration.php';

$page = isset($_GET['page']) ? $_GET['page'] : 'fiches';
$page_info= array(
    'fiches' => array('page' => 'fiches_dynamiques', 'title' => 'Fiches dynamiques des projets', 'sub_title' => 'Gestion des fiches dynamiques des projets'),
    'rapports' => array('page' => 'rapports_dynamiques', 'title' => 'Rapports dynamiques des projets', 'sub_title' => 'Gestion des rapports sur les fiches des projets'),
    'indicateurs' => array('page' => 'rapports_indicateur', 'title' => 'Rapports des indicateurs des projets', 'sub_title' => 'Gestion des rapports sur les indicateurs des projets'),
);

$config = new Config;
$Connexion = Charger_db();
$row_projets = $Connexion->query('SELECT * FROM t_projets')->fetchAll();

$projet_id = $_GET['projet_id'] ?? null;
if ($projet_id) {
    $target_page = $page_info[$page]['page'];
    $sql = "SELECT p.id AS projet_id, p.code AS projet_code, p.name AS projet_name, u.id, u.nom, u.prenom, u.username, u.email, u.fonction, u.role_id, u.structure_id AS user_structure
        FROM t_projets p LEFT JOIN t_users u ON u.id = p.add_by WHERE p.id = :projet_id LIMIT 1";

    try {
        $stmt = $Connexion->prepare($sql);
        $stmt->bindParam(':projet_id', $projet_id, PDO::PARAM_INT);
        $stmt->execute();
        $row_clp = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row_clp) {
            /* ======================
               SESSIONS CLP UTILISATEUR
               ====================== */
            $_SESSION["clp_n"]          = htmlentities($row_clp['id']);
            $_SESSION["clp_id"]         = htmlentities($row_clp['username']);
            $_SESSION["clp_nom"]        = htmlentities($row_clp['nom']);
            $_SESSION["clp_prenom"]     = htmlentities($row_clp['prenom']);
            $_SESSION["clp_departement"] = '';
            $_SESSION["clp_fonction"]   = htmlentities($row_clp['fonction']);
            $_SESSION["clp_niveau"]     = htmlentities($row_clp['role_id']);
            $_SESSION["clp_structure"]  = htmlentities($row_clp['user_structure']);

            /* ======================
               SESSION PROJET
               ====================== */
            $_SESSION["clp_projet"]     = htmlentities($row_clp['projet_id']);
            $_SESSION["clp_projet_code"] = htmlentities($row_clp['projet_code']);
            $_SESSION["clp_projet_name"] = htmlentities($row_clp['projet_name']);

            /* ====================== */
            header(sprintf("Location: %s", "./$target_page.php?page=$page"));
            exit;
        } else {
            unset($_SESSION["clp_projet"]);
        }
    } catch (PDOException $e) {
        error_log($e->getMessage());
    }
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title><?php print $config->sitename; ?></title>
    <link rel="shortcut icon" type="image/ico" href="<?php print $config->icon_folder; ?>/favicon.png" />
    <meta name="keywords" content="<?php print $config->MetaKeys; ?>" />
    <meta name="description" content="<?php print $config->MetaDesc; ?>" />
    <meta name="author" content="<?php print $config->MetaAuthor; ?>" />

    <!-- Vendor styles -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css" />
    <link rel="stylesheet" href="vendor/metisMenu/dist/metisMenu.css" />
    <link rel="stylesheet" href="vendor/animate.css/animate.css" />
    <link rel="stylesheet" href="vendor/bootstrap/dist/css/bootstrap.css" />

    <!-- App styles -->
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/helper.css" />
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/style_fst.css">

    <!-- Vendor scripts -->
    <script src="vendor/jquery/dist/jquery.min.js"></script>
    <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
    <script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.resize.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.pie.js"></script>
    <script src="vendor/flot.curvedlines/curvedLines.js"></script>
    <script src="vendor/jquery.flot.spline/index.js"></script>
    <script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
    <script src="vendor/iCheck/icheck.min.js"></script>
    <script src="vendor/peity/jquery.peity.min.js"></script>
    <script src="vendor/sparkline/index.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/locales/bootstrap-datepicker.fr.min.js"></script>

    <!-- App scripts -->
    <script src="scripts/homer.js"></script>

    <style>
        .wrapper-container {
            background-color: #fff;
            height: 100vh;
            margin-top: 65px;
            padding: 15px;
        }

        .project-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        .project-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        /* IMAGE */
        .project-image {
            position: relative;
            height: 180px;
            overflow: hidden;
        }

        .project-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* BADGES */
        .badge-code {
            position: absolute;
            top: 12px;
            left: 12px;
            background: orange;
            font-size: 10px;
            padding: 5px 10px;
            border-radius: 3px;
        }

        .badge-status {
            position: absolute;
            top: 12px;
            right: 12px;
            background: green;
            font-size: 10px;
            padding: 5px 10px;
            border-radius: 3px;
        }

        /* BODY */
        .project-body {
            padding: 10px;
        }

        .project-title {
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 10px;
        }


        /* INFOS */
        .project-infos {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            margin-bottom: 15px;
            color: #495057;
        }

        .project-infos i {
            color: #0d6efd;
            margin-right: 6px;
        }

        /* BUTTON */
        .project-btn {
            border-radius: 5px;
            font-weight: 600;
        }
    </style>
</head>

<body class="blank">
    <div class="small-header" style="position: fixed; top: 0; width: 100%; z-index: 1000;">
        <div class="hpanel">
            <div class="panel-body" style="border-bottom: 1px solid #ccc;">
                <div class="pull-left">
                    <div style="display: flex; flex-direction: column;">
                        <h2 class="font-light m-b-xs text-nowrap" id="sub-title"><?= $page_info[$page]['title'] ?></h2>
                        <small id="sub-desc" class="text-nowrap"><?= $page_info[$page]['sub_title'] ?></small>
                    </div>
                </div>

                <div class="pull-right">
                    <h2 class="font-light center" id="sub-title">
                        <a href="yambee/Yambee.apk" class="btn btn-warning text-nowrap" download>
                            <i class="fa fa-download"></i> Télécharger YAMBEE
                        </a>

                        <a href="sync_kobo.php?page=<?= $page ?>" class="btn btn-primary text-nowrap">
                            <i class="fa fa-cog"></i> Synchroniser KOBO
                        </a>
                    </h2>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper-container row">
        <?php if (!empty($row_projets)): ?>
            <?php foreach ($row_projets as $projet): ?>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12">
                    <div class="project-card">
                        <div class="project-image">
                            <?php if (!empty($projet['logo'])): ?>
                                <img src="<?= htmlspecialchars($projet['logo']) ?>" alt="Projet" class="object-cover">
                            <?php else: ?>
                                <img src="images/projet/none.png" alt="Projet">
                            <?php endif; ?>

                            <span class="badge badge-code">
                                <?= htmlspecialchars($projet['code']) ?>
                            </span>

                            <span class="badge badge-status">
                                <?= htmlspecialchars($projet['status']) ?>
                            </span>
                        </div>

                        <!-- Body -->
                        <div class="project-body">
                            <h6 class="project-title">
                                <?= htmlspecialchars($projet['name']) ?>
                            </h6>

                            <!-- Button -->
                            <a href="dashboard.php?page=<?= $page ?>&projet_id=<?= $projet['id'] ?>" class="btn btn-success btn-sm w-100 project-btn">
                                Ouvrir classeurs
                                <i class="bi bi-box-arrow-up-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center text-muted">
                Aucun projet disponible
            </div>
        <?php endif; ?>

    </div>
</body>

</html>
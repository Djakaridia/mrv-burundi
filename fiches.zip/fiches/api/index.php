<?php
header(sprintf("Location: %s", "../"));
?>
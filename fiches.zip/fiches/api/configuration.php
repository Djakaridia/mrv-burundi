<?php
class Config
{
    /* Site Settings */
    var $sitename = "Système MRV Burundi";
    var $shortname = "MRV";
    var $sitetititle = "Système de Suivi-Evaluation du projet MRV Burundi";
    var $siteshortname = "MRV";
    var $siteshortdescription = "Projet MRV Burundi";
    var $siteurl = "www.admin.mrv-burundi.org";
    var $lien = "https://admin.mrv-burundi.org/";
    /* dev env */
    var $db = null;
    /* Folders Settings */
    var $class_folder = "classes";
    var $config_folder = "api";
    var $img_folder = "images";
    var $icon_folder = "../assets/favicon/";
    var $script_folder = "scripts";
    /* Meta Settings */
    var $MetaDesc = "Système MRV Burundi";
    var $MetaKeys = "Système MRV, MRV Burundi, Suivi, Burundi";
    var $MetaTitle = "Système MRV Burundi";
    var $MetaAuthor = "BASE - BAMASOFT";
    var $FaveIcone = "../assets/favicon/favicon.png";
    var $LogoEntete = "../assets/images/logo-full.png";
    var $LogoPied = "../assets/images/logo-full.png";
    /* Session Setting */
    var $session_handler = "";
    var $maxtime = 1000; //minutes
}
$nfile = basename($_SERVER["PHP_SELF"]);
$QUERY_STRING = $_SERVER["QUERY_STRING"];
$getfile = explode("&", $_SERVER["QUERY_STRING"]);
$config = new Config;
$path = (isset($path)) ? $path : "./";
include_once $path . $config->config_folder . "/db.php";
$config->db = $db;
$MENU = array(
    4 => array("fiches_dynamiques.php" => array("fiches_dynamiques.php" => "Classeurs dynamiques | Les Classeurs des fiches dynamiques", "classeur_details.php" => "Fiches dynamiques | Les Fiches dynamiques", "disposition_mobile_formulaire.php" => "Fiches dynamiques | Disposition Mobile"), ),
    5 => array("rapports_dynamiques.php" => array("rapports_dynamiques.php" => "Rapports dynamiques | Création de rapport à partir des fiches dynamiques", "rapports_dynamiques_simple_creation.php" => "Rapports dynamiques simples | Création de rapport simple à partir des fiches dynamiques", "rapports_dynamiques_simple_modification.php" => "Rapports dynamiques simple | Modification de rapport dynamique simple", "rapport_details_simple.php" => "Rapports dynamiques | Rapport simple", "rapports_dynamiques_croise_creation.php" => "Rapports dynamiques croisés | Création de rapport croisé à partir des fiches dynamiques", "rapports_dynamiques_croise_modification.php" => "Rapports dynamiques croisé | Modification de rapport dynamique croisé", "rapport_details_croise.php" => "Rapports dynamiques | Rapport croisé"), "rapports_indicateur.php" => "Rapports indicateurs | Rapports des Indicateurs"),
);
$MENU_TITLE = array(
    4 => array("Suivi des résultats", "cubes", "suivi_resultats.php"),
    5 => array("Etats & Rapports", "tasks", "rapport.php"),
);

include_once 'api/essentiel.php';
?>
-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  Dim 08 déc. 2019 à 10:11
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `db_ruche_pasag`
--

-- --------------------------------------------------------

--
-- Structure de la table `t_classeur`
--

DROP TABLE IF EXISTS `t_classeur`;
CREATE TABLE IF NOT EXISTS `t_classeur` (
  `Code_Classeur` int(11) NOT NULL AUTO_INCREMENT,
  `Libelle_Classeur` text,
  `Note_Classeur` text,
  `Couleur_Classeur` text,
  `Id_Projet` int(11) NOT NULL,
  `Date_Insertion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Code_Classeur`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déclencheurs `t_classeur`
--
DROP TRIGGER IF EXISTS `TRG_BEFORE_DELETE_CLASSEUR`;
DELIMITER $$
CREATE TRIGGER `TRG_BEFORE_DELETE_CLASSEUR` AFTER DELETE ON `t_classeur` FOR EACH ROW BEGIN

DELETE FROM t_feuille WHERE t_feuille.Code_Classeur = OLD.
Code_Classeur;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `t_connecter`
--

DROP TABLE IF EXISTS `t_connecter`;
CREATE TABLE IF NOT EXISTS `t_connecter` (
  `id_connexion` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `date_connexion` datetime NOT NULL,
  `date_deconnexion` datetime DEFAULT NULL,
  `date_c` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_connexion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_connecter`
--

INSERT INTO `t_connecter` (`id_connexion`, `user_id`, `session_id`, `date_connexion`, `date_deconnexion`, `date_c`) VALUES
(1, 5, '8gsnqpsghh6vo4eudtbfgmtt96', '2019-11-30 14:29:18', NULL, '2019-11-30 14:29:18');

-- --------------------------------------------------------

--
-- Structure de la table `t_feuille`
--

DROP TABLE IF EXISTS `t_feuille`;
CREATE TABLE IF NOT EXISTS `t_feuille` (
  `Code_Feuille` bigint(20) NOT NULL AUTO_INCREMENT,
  `Code_Classeur` int(11) DEFAULT NULL,
  `Nom_Feuille` text,
  `Libelle_Feuille` text,
  `Nb_Ligne_Impr` int(11) DEFAULT NULL,
  `Icone` text,
  `Note` text,
  `Table_Feuille` varchar(255) NOT NULL,
  `Structure_Table` text,
  `Structure_View` text NOT NULL,
  `Source_Donnees` enum('Oui','Non') DEFAULT 'Non',
  PRIMARY KEY (`Code_Feuille`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déclencheurs `t_feuille`
--
DROP TRIGGER IF EXISTS `TRG_BEFORE_DELETE_FEUILLE`;
DELIMITER $$
CREATE TRIGGER `TRG_BEFORE_DELETE_FEUILLE` BEFORE DELETE ON `t_feuille` FOR EACH ROW BEGIN

DELETE FROM t_feuille_ligne WHERE t_feuille_ligne.Code_Feuille=OLD.Code_Feuille;


END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `t_feuille_etrangere`
--

DROP TABLE IF EXISTS `t_feuille_etrangere`;
CREATE TABLE IF NOT EXISTS `t_feuille_etrangere` (
  `Nom_Table` varchar(255) NOT NULL,
  `Nom_Colonne` varchar(255) NOT NULL,
  `Valeur` varchar(255) NOT NULL,
  PRIMARY KEY (`Nom_Table`,`Nom_Colonne`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `t_feuille_ligne`
--

DROP TABLE IF EXISTS `t_feuille_ligne`;
CREATE TABLE IF NOT EXISTS `t_feuille_ligne` (
  `Code_Feuille_Ligne` bigint(20) NOT NULL AUTO_INCREMENT,
  `Code_Feuille` bigint(20) NOT NULL,
  `Nom_Ligne` text NOT NULL,
  `Libelle_Ligne` text NOT NULL,
  `Type_Ligne` varchar(255) NOT NULL,
  `Requis` enum('Oui','Non') DEFAULT NULL,
  `Afficher` enum('Oui','Non') DEFAULT NULL,
  `Nom_Collone` varchar(255) DEFAULT NULL,
  `Rang` int(11) NOT NULL DEFAULT '100',
  `Mobile` enum('Oui','Non') DEFAULT 'Oui',
  `Formulaire` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Code_Feuille_Ligne`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Déclencheurs `t_feuille_ligne`
--
DROP TRIGGER IF EXISTS `TRG_AFTER_INSERT_FEUILLE_LIGNE_`;
DELIMITER $$
CREATE TRIGGER `TRG_AFTER_INSERT_FEUILLE_LIGNE_` AFTER INSERT ON `t_feuille_ligne` FOR EACH ROW BEGIN

SELECT COUNT(Nom_Ligne) INTO @NB FROM t_feuille_ligne WHERE (t_feuille_ligne.Code_Feuille=NEW.Code_Feuille AND t_feuille_ligne.Nom_Ligne=NEW.Nom_Ligne);

IF @NB>1 THEN
DELETE FROM t_feuille_ligne WHERE t_feuille_ligne.Code_Feuille_Ligne=NEW.Code_Feuille_Ligne;
END IF;

END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `TRG_BEFORE_DELETE_FEUILLE_LIGNE`;
DELIMITER $$
CREATE TRIGGER `TRG_BEFORE_DELETE_FEUILLE_LIGNE` BEFORE DELETE ON `t_feuille_ligne` FOR EACH ROW BEGIN

SELECT Table_Feuille, Nom_Collone  INTO @Tab_Nom, @Col_Nom FROM t_feuille_ligne INNER JOIN t_feuille ON (t_feuille_ligne.Code_Feuille=t_feuille.Code_Feuille) WHERE (Code_Feuille_Ligne=OLD.Code_Feuille_Ligne);

DELETE FROM t_feuille_etrangere WHERE (t_feuille_etrangere.Nom_Table= @Tab_Nom AND t_feuille_etrangere.Nom_Colonne= @Col_Nom);

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `t_feuille_ligne_type`
--

DROP TABLE IF EXISTS `t_feuille_ligne_type`;
CREATE TABLE IF NOT EXISTS `t_feuille_ligne_type` (
  `Code_Feuille_Ligne_Type` int(11) NOT NULL AUTO_INCREMENT,
  `Valeur_Feuille_Ligne_Type` varchar(255) DEFAULT NULL,
  `Structure_Feuille_Ligne_Type` varchar(255) NOT NULL,
  PRIMARY KEY (`Code_Feuille_Ligne_Type`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `t_feuille_ligne_type`
--

INSERT INTO `t_feuille_ligne_type` (`Code_Feuille_Ligne_Type`, `Valeur_Feuille_Ligne_Type`, `Structure_Feuille_Ligne_Type`) VALUES
(1, 'TEXT', ''),
(2, 'INT', ''),
(3, 'DOUBLE', ''),
(4, 'DATE', ''),
(5, 'CHOIX', ''),
(6, 'COULEUR', ''),
(7, 'FICHIER', ''),
(8, 'FEUILLE', ''),
(9, 'RAPPORT', ''),
(10, 'SOMME', ''),
(11, 'DIFFERENCE', ''),
(12, 'PRODUIT', ''),
(13, 'MOYENNE', ''),
(14, 'COMPTER', '');

-- --------------------------------------------------------

--
-- Structure de la table `t_fonction`
--

DROP TABLE IF EXISTS `t_fonction`;
CREATE TABLE IF NOT EXISTS `t_fonction` (
  `id_fonction` int(25) NOT NULL AUTO_INCREMENT,
  `fonction` text,
  `description` text,
  `structure` int(11) DEFAULT NULL,
  `type_fonction` int(11) NOT NULL DEFAULT '2',
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_fonction`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_fonction`
--

INSERT INTO `t_fonction` (`id_fonction`, `fonction`, `description`, `structure`, `type_fonction`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `etat`) VALUES
(1, 'Administrateur', 'Administrateur du système', 8, 100, '2019-01-28 19:56:16', 0, '2019-03-07 17:35:30', 1, 0),
(2, 'Point focal OIM', 'Point focal PBF OIM', 2, 1, '2019-01-28 19:56:16', 1, '2019-02-13 15:14:01', 1, 0),
(6, 'Point focal PNUD', 'Point focal ST/PBF PNUD', 1, 1, '2019-01-28 19:56:16', 0, '2019-02-13 15:14:10', 1, 0),
(8, 'Point focal UNESCO', 'Point focal ST/PBF UNESCO', 3, 1, '2019-02-13 15:10:43', 1, '2019-02-13 15:14:19', 1, 0),
(9, 'Point focal UNICEF', 'Point focal ST/PBF UNICEF', 4, 1, '2019-02-13 15:11:18', 1, '2019-02-13 15:14:31', 1, 0),
(10, 'Point focal ONU-FEMMES', 'Point focal ST/PBF ONU-FEMMES', 5, 1, '2019-02-13 15:11:46', 1, '2019-02-13 15:14:44', 1, 0),
(11, 'Point focal CARE', 'Point focal ST/PBF CARE', 6, 1, '2019-02-13 15:12:07', 1, '2019-02-13 15:14:54', 1, 0),
(12, 'Point focal UNFPA', 'Point focal ST/PBF UNFPA', 7, 1, '2019-02-13 15:12:39', 1, '2019-02-13 15:15:06', 1, 0),
(13, 'Point focal FAO', 'Point focal ST/PBF FAO', 10, 1, '2019-02-13 15:36:48', 1, NULL, 0, 0),
(14, 'Point focal ICTJ', 'Point focal ST/PBF ICTJ', 9, 1, '2019-02-13 15:37:27', 1, '2019-02-13 15:40:34', 1, 0),
(15, 'ASSISTANT', 'ASSISTANT POINT FOCAL', 4, 2, '2019-03-11 14:27:03', 8, NULL, 0, 0),
(16, 'Autres', 'Autre utilisateur', 6, 2, '2019-03-11 15:53:44', 5, '2019-05-14 10:58:47', 5, 0),
(17, 'Point focal PNUD', 'Point focal PNUD', 1, 2, '2019-03-14 10:24:48', 1, '2019-03-14 10:30:36', 1, 0),
(18, 'Secrétaire  ST/PBF', 'Secrétaire  ST/PBF', 8, 2, '2019-03-14 10:33:00', 1, NULL, 0, 0),
(19, 'Assistant OIM', 'Assistant Point Focal BPF OIM', 2, 2, '2019-03-14 10:49:02', 3, '2019-03-14 10:49:41', 3, 0),
(20, 'Consultant', 'Diagnostic', 2, 2, '2019-03-14 15:49:10', 3, NULL, 0, 0),
(21, 'Analyste suivi-évaluation & RBM', 'Analyste Suivi-évaluation et Gestion Axée sur les Résultats', 8, 2, '2019-03-19 16:20:53', 1, NULL, 0, 0),
(22, 'Coordonnatrice ST PBF/PACoP', 'Coordonnatrice du Secrétariat Technique PBF/PACoP/ Co-Présidente du Comité Technique des Experts', 8, 2, '2019-03-19 16:23:20', 1, '2019-03-19 16:29:33', 1, 0),
(23, 'Co-Président du CTE', 'Directeur de Cabinet Adjoint du Ministre du Plan et du Développement / Co-Président du Comité Technique des Experts du PBF/PACoP ', 8, 2, '2019-03-19 16:24:27', 1, '2019-03-19 16:28:26', 1, 0),
(24, 'Assistante DCA/ MPD', 'Chargée d\'Etude, Assistante du Directeur de Cabinet Adjoint du Ministre du Plan', 8, 2, '2019-03-19 16:26:50', 1, NULL, 0, 0),
(25, 'Assistante Administrative et Financière', 'Assistante Administrative et Financière \r\nBureau du Coordonnateur Résident\r\nProgramme des Nations Unies pour le Développement\r\n', 8, 2, '2019-03-19 16:39:37', 1, NULL, 0, 0),
(26, 'NPO', 'Chargé de programmes', 9, 2, '2019-05-03 14:53:49', 11, NULL, 0, 0),
(27, 'RR', 'Représentante Résidente', 5, 2, '2019-05-06 12:38:04', 25, NULL, 0, 0),
(28, 'M&E', 'Monitoring and Evaluation Officer', 5, 2, '2019-05-06 12:38:43', 25, NULL, 0, 0),
(29, 'CP', 'Chargé de Programme', 5, 2, '2019-05-06 12:40:01', 25, NULL, 0, 0),
(30, 'AP', 'Assistant Programme', 5, 2, '2019-05-06 12:41:03', 25, NULL, 0, 0),
(31, 'FO', 'Finance Officer', 5, 2, '2019-05-06 12:41:44', 25, NULL, 0, 0),
(32, 'M/E', 'Responsable de suivi et évaluation et apprentissage', 6, 2, '2019-05-14 10:56:48', 5, NULL, 0, 0),
(33, 'CD', 'Directeur pays CARE CIV', 6, 2, '2019-05-14 10:57:54', 5, NULL, 0, 0),
(34, 'Chargée de programme Unité Genre', 'Chef d\'Unité', 7, 2, '2019-05-15 15:01:37', 7, NULL, 0, 0),
(35, 'UT PUBLIC', 'Autre  Utilisateur', 6, 2, '2019-05-15 15:02:52', 5, NULL, 0, 0),
(36, 'Expert National', 'Expert national en charge des questions de cohésion sociale', 1, 2, '2019-05-15 15:03:04', 6, NULL, 0, 0),
(37, 'Suivi-Evaluation', 'En charge du suivi du projet', 1, 2, '2019-05-15 15:03:05', 6, NULL, 0, 0),
(38, 'Assistante au programme', 'Chargé des questions administratives et financières', 1, 2, '2019-05-15 15:04:24', 6, '2019-05-15 15:04:45', 6, 0),
(39, 'CHARGE DE SUIVI ET EVALUATION UNICEF', 'POINT FOCAL SUIVI EVALUATION', 4, 2, '2019-05-15 15:05:19', 8, '2019-05-15 15:06:11', 8, 0),
(40, 'Informaticien/logisticien', 'Chargé des questions logistiques et informatiques', 1, 2, '2019-05-15 15:05:59', 6, NULL, 0, 0),
(41, 'Cross border community officer', 'Chargé du suivi des activités sur le terrain', 1, 2, '2019-05-15 15:07:01', 6, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_page`
--

DROP TABLE IF EXISTS `t_page`;
CREATE TABLE IF NOT EXISTS `t_page` (
  `page` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_page`
--

INSERT INTO `t_page` (`page`) VALUES
('categorie_indicateur'),
('classeur_details'),
('connexion'),
('connexion_traitement'),
('fiches_dynamiques'),
('fonction'),
('groupe_travail'),
('localite'),
('menu'),
('niveau'),
('partenaire'),
('partenaire2'),
('periode'),
('programme'),
('programme2'),
('projet'),
('projet_details'),
('type_partenaire'),
('type_zone'),
('utilisateur'),
('zone_collecte');

-- --------------------------------------------------------

--
-- Structure de la table `t_partenaires`
--

DROP TABLE IF EXISTS `t_partenaires`;
CREATE TABLE IF NOT EXISTS `t_partenaires` (
  `id_partenaire` int(11) NOT NULL AUTO_INCREMENT,
  `nom_partenaire` varchar(100) DEFAULT NULL,
  `code_partenaire` varchar(30) DEFAULT NULL,
  `sigle_partenaire` varchar(30) DEFAULT NULL,
  `type_partenaire` varchar(50) DEFAULT NULL,
  `adresse_partenaire` mediumtext,
  `contact_partenaire` mediumtext,
  `titre_representant` text,
  `site_web` varchar(60) DEFAULT NULL,
  `email_partenaire` varchar(60) DEFAULT NULL,
  `map_partenaire` mediumtext,
  `description` mediumtext,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_partenaire`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_partenaires`
--

INSERT INTO `t_partenaires` (`id_partenaire`, `nom_partenaire`, `code_partenaire`, `sigle_partenaire`, `type_partenaire`, `adresse_partenaire`, `contact_partenaire`, `titre_representant`, `site_web`, `email_partenaire`, `map_partenaire`, `description`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `etat`) VALUES
(1, 'Programme des Nations Unies pour le Développement', '01', 'PNUD', '1', '01 BP 1747 Abidjan 01 Rue Gourgas, Abidjan', '20317400', NULL, 'http://www.ci.undp.org', 'registry.ci@undp.org', 'https://goo.gl/maps/Voi2j7ZLxSAgvAeU7', '', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 6, 0),
(2, 'Organisation Internationale pour les Migrations', '02', 'OIM', '1', ' OIM  Abidjan 27 BP 739 Abidjan, 27, II Plateaux Vallon, rue J 107 LOT 1616', 'Cel :+22521273945, Tel : 2205208200', NULL, 'https://www.iom.int/', 'iomabidjan@iom.int', 'https://goo.gl/maps/3cFYoA9efJd1Afsz7', '', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 19, 0),
(3, 'UNESCO', '03', 'UNESCO', '1', 'Angré', '+22522414616', NULL, '', '01@g', '', '', '2019-02-13 14:50:20', 1, NULL, 0, 0),
(4, 'Organisation des Nations Unis pour l\'enfance', '04', 'UNICEF', '1', 'Rivera', '+22556433494', NULL, 'https://www.unicef.org/', 'ndaries@unicef.org', 'https://www.google.com/maps/place/UNICEF+C%C3%B4te+d\'Ivoire/@5.336763,-3.9808696,17z/data=!4m12!1m6!3m5!1s0xfc1ed16ec78a89f:0xea23b3d4872e02cd!2sUNICEF+C%C3%B4te+d\'Ivoire!8m2!3d5.3368057!4d-3.9785951!3m4!1s0xfc1ed16ec78a89f:0xea23b3d4872e02cd!8m2!3d5.3368057!4d-3.9785951', '', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 8, 0),
(5, 'Organisation des Nations Unies pour les Femmes', '05', 'ONU-FEMMES', '1', 'II plateaux', '+22522518771', NULL, '', '01@g', 'https://goo.gl/maps/9EyPtCiyvpcvThTK9', 'ONU Femmes est l’entité des Nations Unies consacrée à l’égalité des sexes et à l’autonomisation des femmes. Porte-drapeau mondial des femmes et des filles, ONU Femmes a été créée pour accélérer les progrès dans la réponse apportée à leurs besoins partout dans le monde', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 25, 0),
(6, 'CARE international - Côte d\'Ivoire', '06', 'CARE', '1,3', 'Cocody - Près de la Polyclinique des II Plateaux', '22409725', NULL, 'http://www.care.org', 'Losseni.Coulibaly@care.org', 'https://www.google.com/maps/place/Care+Cote+d\'ivoire/@5.3607985,-3.9996845,15.75z/data=!4m12!1m6!3m5!1s0x0:0x96a8f4df6996f8a5!2sCare+Cote+d\'ivoire!8m2!3d5.3627125!4d-4.0012155!3m4!1s0x0:0x96a8f4df6996f8a5!8m2!3d5.3627125!4d-4.0012155', '', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 5, 0),
(7, 'Fonds des Nations Unies pour la population', '07', 'UNFPA', '1', 'Immeuble CCIA, 6e étage, Avenue Jean-Paul II, Plateau', '08088047', NULL, 'https://www.unfpa.org/fr/data/transparency-portal/unfpa-cote', 'kouye@unfpa.org', '', 'L’UNFPA est l’agence directrice des Nations Unies en charge des questions de santé sexuelle et reproductive. Notre mission est de créer un monde dans lequel chaque grossesse est désirée et chaque accouchement sans danger. Un monde dans lequel chaque jeune réalise pleinement son potentiel.', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 7, 0),
(8, 'Secrétariat Technique du PBF', '00', 'ST/PBF', '1', 'II Plateaux', '00', NULL, '', '01@g', '', '', '2019-02-13 14:50:20', 1, NULL, 0, 0),
(9, 'INTERNATIONAL CENTER FOR TRANSITIONAL JUSTICE', '09', 'ICTJ', '1,3,4', 'En face de la Résidence EDOUARD, Cocody Les II PLATEAUX, Immeuble LES DUNES, 2eme étage, Avenue Emile BOGA Doudou, 28 BP 74 Abidjan 28, Cote d’Ivoire ', '22426331', NULL, 'https://www.ictj.org', 'Abidjan@ictj.org', '', 'Le Centre International pour la Justice Transitionnelle (International Center for Transitional Justice – ICTJ) est une organisation non-gouvernementale qui travaille à répondre aux conséquences des violations des droits de l’Homme. L’expertise d’ICTJ vise à aider les sociétés à découvrir la vérité sur les violations, à poursuivre les responsables et à procurer réparation aux victimes des violations des droits de l’Homme. Cet ensemble de mesures est au cœur de la justice transitionnelle.', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 26, 0),
(10, 'Organisation des Nations Unies pour l\'alimentation et l\'agriculture', '10', 'FAO', '1,4', 'Riviéra Golf, Zone 2, Lot n°107 B, Ilot 5\r\nCocody -Abidjan\r\nMailing Address: \r\n01BP 3894 Abidjan 01', '+225-22-40-59-20', NULL, '', '01@g', '', '', '2019-02-13 14:50:20', 1, '2019-05-15 00:00:00', 1, 0),
(12, 'Société de développement des forêts', '12', 'SODEFOR ', '2', 'Cocody; 01 BP 3770 Abidjan; RCI', '22 48 30 00', NULL, 'http://www.sodefor.ci', '01@vf', '', '', '2019-02-13 14:49:25', 1, '2019-02-13 00:00:00', 1, 0),
(13, 'Conseil National de la Jeunesse', '13', 'CNJ', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 14:50:20', 1, NULL, 0, 0),
(14, 'Association « Femmes et TIC »', '14', 'AFTIC', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 14:51:17', 1, NULL, 0, 0),
(15, 'ONG ASAPSU', '15', 'ONG ASAPSU', '3', 'A définir', 'A définir', NULL, '', 'd@j', '', '', '2019-02-13 14:52:12', 1, NULL, 0, 0),
(16, 'ONG DRAO', '16', 'ONG DRAO', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 14:52:44', 1, NULL, 0, 0),
(17, 'ONG IMPACTUM', '17', 'ONG IMPACTUM', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 14:53:13', 1, NULL, 0, 0),
(18, 'ONG IDEF', '18', 'ONG IDEF', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 14:53:52', 1, NULL, 0, 0),
(19, 'ONG APDVH ', '19', 'ONG APDVH', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 14:54:48', 1, NULL, 0, 0),
(20, 'GNTCI  ', '20', 'GNTCI  ', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 14:55:16', 1, NULL, 0, 0),
(21, 'PBF ', '21', 'PBF', '1,4', 'Abidjan', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 15:35:17', 1, '2019-03-07 00:00:00', 1, 0),
(22, 'Commission Electorale Indépendante', '22', 'CEI', '2', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:03:44', 1, NULL, 0, 0),
(23, 'Institut Gorée de Dakar ', '23', 'IGD', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:04:32', 1, NULL, 0, 0),
(24, 'National Democratic Institute', '24', 'NDI', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:05:09', 1, NULL, 0, 0),
(25, 'Le compendium des compétences féminines de Côte d’Ivoire  ', '25', 'COCOFCI', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:05:39', 1, NULL, 0, 0),
(26, 'L’Association des Femmes Juristes de Côte d’Ivoire', '26', 'AFJCI', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:06:11', 1, NULL, 0, 0),
(27, 'La Concertation Interpartis pour des Elections Démocratiques', '27', 'CIED', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:06:43', 1, NULL, 0, 0),
(28, 'Le réseau des femmes leaders Africaines ', '28', 'RFLA', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:07:15', 1, NULL, 0, 0),
(29, 'Le Forum des femmes des partis politiques', '29', 'FPP', '3', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:07:46', 1, NULL, 0, 0),
(30, 'Ministère de la Solidarité, de la Cohésion Sociale et de la Lutte Contre la Pauvreté (MSCSIV)', '30', 'MSCSLCP', '2', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:09:13', 1, '2019-03-29 00:00:00', 5, 0),
(31, 'Ministère de l’Intérieur et de la Sécurité ', '31', 'MIS', '2', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:09:37', 1, NULL, 0, 0),
(32, 'Ministre auprès du Président de la République chargé des affaires politiques', '32', 'MIPRAP', '2', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:10:23', 1, NULL, 0, 0),
(33, 'MINISTÈRE DE LA COMMUNICATION, DE L’ÉCONOMIE NUMÉRIQUE ET DE LA POSTE', '33', 'MCENP', '2', 'A définir', 'A définir', NULL, '', '01@g', '', '', '2019-02-13 16:34:16', 1, '2019-03-29 00:00:00', 5, 0),
(34, 'Ministère de la promotion de la jeunesse et de l\'emploi des jeunes', '34', 'MPJEJ', '2', '05 BP 2382 Abidjan 05', '07605520', NULL, '', 'armandakely@yahoo.fr', 'https://www.google.com/maps/place/Minist%C3%A8re+de+la+Promotion+de+la+Jeunesse+et+de+l%E2%80%99Emploi+des+Jeunes+-+C%C3%B4te+d\'Ivoire/@5.3167038,-4.0189766,17z/data=!4m12!1m6!3m5!1s0xfc1eb05546e321f:0x1bd1babab914463c!2sMinist%C3%A8re+de+la+Promotion+de+la+Jeunesse+et+de+l%E2%80%99Emploi+des+Jeunes+-+C%C3%B4te+d\'Ivoire!8m2!3d5.3166985!4d-4.0167879!3m4!1s0xfc1eb05546e321f:0x1bd1babab914463c!8m2!3d5.3166985!4d-4.0167879', 'Direction de la protection des jeunes: paquet d\'intervention en direction des jeunes et adolescents hors du systeme scoalire', '2019-02-13 16:35:09', 1, '2019-05-15 00:00:00', 8, 0),
(35, 'Observatoire de la solidarité et de la cohésion sociale (OSCS) ', '35', 'OSCS', '2', '04 BP 1861 ABIDJAN 04, Angré 7ème tranche non loin du pont soro', '22 42 67 34', NULL, 'http://oscs.solidarité.gouv.ci', 'info@oscs-solidarite.org', '', 'L’Observatoire de la Solidarité et de la Cohésion Sociale (OSCS), est un organe de veille et  d’alerte en matière de solidarité et de cohésion sociale placée sous la tutelle du Ministère de la Solidarité, de la Cohésion Sociale et de la Lutte contre la Pauvreté (MSCSLP).', '2019-02-14 08:43:46', 6, '2019-05-15 00:00:00', 7, 0),
(36, 'Ministère de la Femme, de la Famille et de l’Enfant ', '36', 'MFFE', '2', 'A définir', 'A Définir', NULL, '', 'fg@o', '', '', '2019-02-14 08:45:38', 6, '2019-05-06 00:00:00', 25, 0),
(37, 'LEADAFRICAINES', '37', 'LEADAFRICAINES', '3', 'A Définir', 'A Définir', NULL, '', 'fg@o', '', '', '2019-02-14 08:46:12', 6, NULL, 0, 0),
(38, 'Génération femmes du 3ième millénaire', '38', 'GF3', '3', 'A Définir', 'A Définir', NULL, '', 'fg@o', '', '', '2019-02-14 08:46:55', 6, NULL, 0, 0),
(39, 'Animation rurale de Korhogo', '39', 'ARK', '3', 'A Définir', 'A Définir', NULL, '', 'fg@o', '', '', '2019-02-14 08:47:27', 6, NULL, 0, 0),
(41, 'Etat de Côte d\'Ivoire', '40', 'ETAT', '4', 'Plateau -Immeuble SCIAM, 16 étage', '20200842', NULL, 'http://www.plan.gouv.ci', 'info@plan.gouv.ci', 'https://www.google.com/maps/search/ministère+du+plan+et+du+développement+de+côte+d\'ivoire/@5.3338069,-4.0232228,15z/data=!3m1!4b1', 'Ministère du Plan et du Développement', '2019-03-19 16:49:12', 1, NULL, 0, 0),
(42, 'Ministère du Plan et du Développement', '41', 'MPD', '2', 'Plateau -Immeuble SCIAM, 16 étage', '20200842', NULL, 'http://www.plan.gouv.ci', 'info@plan.gouv.ci', 'https://www.google.com/maps/search/ministère+du+plan+et+du+développement+de+côte+d\'ivoire/@5.3338069,-4.0232228,15z/data=!3m1!4b1', '', '2019-03-21 11:35:01', 6, NULL, 0, 0),
(43, 'Ministere d\'Etat, ministère de la défense', '42', 'MEMD', '2', '01 BP 12243 Abidjan 01, Côte d\'Ivoire.', '+225) 20 21 07 84 / 20 21 86 04  (+225) 20 21 38 28', NULL, 'http://www.defense.gouv.ci', 'info@defense.gouv.ci', 'https://www.google.com/maps/place/Minist%C3%A8re+de+la+d%C3%A9fense/@5.3378206,-4.026219,17z/data=!3m1!4b1!4m8!1m2!2m1!1sMINISTERE+DE+LA+DEFENSE!3m4!1s0xfc1ebaa18fdd86d:0xe46cfc9430f201f9!8m2!3d5.3378206!4d-4.0240303', '', '2019-03-21 11:45:21', 6, NULL, 0, 0),
(44, 'Dignité et Droit des Enfants en Côte d\'Ivoire', '43', 'DDECI', '3', 'Abidjan', 'A définir', NULL, '', 'adefinir@gmail.com', '', '', '2019-03-21 13:10:39', 8, NULL, 0, 0),
(45, 'Association pour le Développement Socio-sanitaire Rural	', '44', 'ONG ADSR', '3', 'Abidjan', 'A définir', NULL, '', 'az@gmail.com', '', '', '2019-03-21 13:15:03', 8, NULL, 0, 0),
(46, 'Programme National de Cohésion Sociale ', '45', 'PNCS', '2', ' BP V 165 ABIDJAN', ' 22 47 83 73', NULL, 'http://www.pncs.ci', 'infos@pncs.ci', 'https://www.google.com/maps/place/Programme+National+De+Cohesion+Sociale/@5.3402651,-3.9524093,17z/data=!4m12!1m6!3m5!1s0xfc1ecff71d538e1:0x9c4ba89fa2c34bc1!2sProgramme+National+De+Cohesion+Sociale!8m2!3d5.3402651!4d-3.9502206!3m4!1s0xfc1ecff71d538e1:0x9c4ba89fa2c34bc1!8m2!3d5.3402651!4d-3.9502206', '', '2019-03-21 17:44:08', 7, NULL, 0, 0),
(47, 'Direction Générale de l’Administration du Territoire ', '46', 'DGAT', '2', 'commune de Cocody, non loin du Lycée Technique d\'Abidjan à environ 500m', '22 48 24 02', NULL, 'http://dgat.interieur.gouv.ci/', 'mail@gmail.com', 'https://www.google.com/maps/place/DGAT/@5.3456661,-4.0141482,17z/data=!3m1!4b1!4m5!3m4!1s0xfc1eb0c4048f261:0x3f7336f831750f5!8m2!3d5.3456661!4d-4.0119595', '', '2019-03-21 17:50:49', 7, NULL, 0, 0),
(48, 'Ecole Nationale d’Administration ', '47', 'ENA', '2', 'Boulevard des Martyrs, Abidjan', '22 51 60 60 / 22 51 60 30', NULL, 'https://www.ena.ci/', 'infos@ena.ci', 'https://www.google.com/maps/place/%C3%89cole+Nationale+D\'Administration+-+ENA/@5.3611675,-3.9991208,17z/data=!4m12!1m6!3m5!1s0xfc1eb5d4096fd43:0xc2bbfe90e139f31e!2s%C3%89cole+Nationale+D\'Administration+-+ENA!8m2!3d5.3611675!4d-3.9969321!3m4!1s0xfc1eb5d4096fd43:0xc2bbfe90e139f31e!8m2!3d5.3611675!4d-3.9969321', '', '2019-03-21 17:53:23', 7, NULL, 0, 0),
(49, 'Autres bailleurs', '48', 'AUTRES', '4', 'A définir', 'A définir', NULL, '', 'autres@gmail.com', '', '', '2019-03-28 09:57:36', 6, NULL, 0, 0),
(50, 'Organisations de la Société Civile', '11', 'OSC', '3', 'A définir', 'A définir', NULL, '', 'OSC@gmail.com', '', 'Organisations de la Société Civile (OSC)', '2019-03-28 11:21:48', 11, NULL, 0, 0),
(51, 'Secrétariat-Comité National de Sécurité', '49', 'S-CNS', '2', 'Plateau - 01 BP 1354 Abidjan 01\r\nAbidjan - Côte d’Ivoire', '20 31 46 98 ', NULL, '', 'SCNS@gmail.com', '', 'Le Secrétariat du CNS est chargé du suivi de la mise en oeuvre de la réforme du secteur de la sécurité\r\n', '2019-03-29 01:39:48', 1, '2019-03-29 00:00:00', 1, 0),
(52, 'Organisations à Base Communautaire', '50', 'OBC', '3', 'A définir', 'A définir', NULL, '', 'OBC@gmail.com', '', '', '2019-03-29 01:43:29', 1, NULL, 0, 0),
(53, 'Ministère de la Justice et des Droits de l’Homme ', '51', 'MJDH', '2', 'Imm. Symphonie - Rue du commerce face galeries Peyrissac (ex- CNA) , Abidjan, plateau\r\ndrafts 01 bp 2020 Abidjan 01', '20 32 07 58', NULL, 'http://justice.ci/', 'ND@gmail.com', 'http://www.annuaire.gouv.ci/recherche?search=-%09Minist%C3%A8re+de+la+Justice+et+des+Droits+de+l%E2%80%99Homme+#', '', '2019-03-29 01:55:36', 1, NULL, 0, 0),
(54, 'Ministère de l’Agriculture et du Développement Rural ;', '52', 'MINAGRI', '2', '24ème et 25ème étage Immeuble CAISTAB\r\ndrafts 01 BP V82', ' 20 21 42 38 / 20 22 81 35 / 20 21 41 94', NULL, 'http://www.agriculture.gouv.ci', 'ND@gmail.com', 'http://www.annuaire.gouv.ci/accueil/liste_institution/ministres/2#', '', '2019-03-29 02:02:50', 1, '2019-04-02 00:00:00', 6, 0),
(55, 'Agence Foncière Rurale', '53', 'AFOR', '2', 'Deux Plateaux, Quartier Zinsou Rue L 183, Abidjan, Abidjan', ' 57 15 29 85', NULL, 'http://www.foncierural.ci/', 'ND@gmail.com', 'https://www.google.com/maps?q=AFOR&um=1&ie=UTF-8&sa=X&ved=0ahUKEwjqpfS5oabhAhVnRBUIHe8sARwQ_AUIECgD', '', '2019-03-29 02:08:47', 1, NULL, 0, 0),
(56, 'Commission Nationale des Droits de l’Homme de Côte d’Ivoire', '54', 'CNDHCI', '2', 'Abidjan-Cocody II Plateaux, Rue des Jardins, \r\nRoute Vallons, Rue J 77 \r\n01 B.P 1374 Abidjan 01 ', '22 52 00 90 ', NULL, 'http://www.cndh.ci/', 'c.centralecndhci@gmail.com', 'https://www.google.com/maps/place/Commission+Nationale+des+Droits+de+l\'Homme+de+C%C3%B4te+d\'Ivoire+(CNDHCI)/@5.3562556,-3.9962883,17z/data=!3m1!4b1!4m5!3m4!1s0xfc1eb5f3cc763c1:0x9b789446224c26e7!8m2!3d5.3562556!4d-3.9940996', 'Autorité Administrative Indépendante de protection, de promotion \r\net de défense des droits de l\'homme', '2019-03-29 02:11:11', 1, '2019-03-29 00:00:00', 1, 0),
(57, 'Cellule Spéciale d’Enquête et d’Investigation', '55', 'CSEI', '2', 'Non loin de café de Versailles - Angré 7è tranche\r\nCocody - 06 BP 107 Abidjan 06\r\nAbidjan - Côte d’Ivoire', '22 52 44 57', NULL, '', 'ND@gmail.com', '', '', '2019-03-29 02:14:06', 1, NULL, 0, 0),
(58, 'Office du Haut-Commissariat des Nations Unies aux Droits de l’Homme, Bureau régional de Dakar ', '56', 'OHCDH', '3', 'DAKAR', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-29 02:18:55', 1, NULL, 0, 0),
(59, 'UN Team of Experts on the Rule of law/ Sexual Violence in Conflict', '57', 'UNTERLSVC', '3', 'A définir', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-29 02:21:19', 1, NULL, 0, 0),
(60, 'Ligue Ivoirienne des droits de l’Homme', '58', 'LIDHO', '3', 'Abidjan-Cocody, Cité des arts, 323 logements, Rue Impasse des Poètes, Immeuble F1,Escalier B,1er étage,Appartement 14', '22 52 00 90', NULL, 'http://lidho-ci.org/', 'ND@gmail.com', '', '', '2019-03-29 02:23:22', 1, NULL, 0, 0),
(61, 'Mouvement Ivoirien des Droits de l’Homme', '59', 'MIDH', '3', 'Abidjan', '+225 22 45 89 98', NULL, 'http://www.midhci.org/', 'siege_midh@yahoo.fr', '', '', '2019-03-29 02:25:34', 1, NULL, 0, 0),
(62, 'Organisation de défense des droits de l’Homme N’gboadô ;', '60', 'ONG N’GBOADO ', '3', 'Abidjan', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-29 09:31:34', 1, NULL, 0, 0),
(63, 'Ordre des Avocats de Côte d’Ivoire.', '61', 'OACI', '3', 'Abidjan-Cocody, II Plateaux ENA, Rue J9 \r\n01 BP 8500 Abidjan 01', '+225 22 41 56 05 / 22 41 56 13', NULL, 'http://www.ordredesavocats.ci/FR/', 'info@ordredesavocats.ci', 'https://www.google.com/maps/place/KSK+Soci%C3%A9t%C3%A9+d\'Avocats/@5.329294,-4.0020275,17z/data=!3m1!4b1!4m5!3m4!1s0xfc1eb9aa4cfa8d9:0xc8218e88afdd995d!8m2!3d5.329294!4d-3.9998388', '', '2019-03-29 09:33:50', 1, NULL, 0, 0),
(64, 'Fédération Internationale des Droits de l’Homme', '62', 'FIDH', '3', 'Abidjan', 'A définir', NULL, '', 'ci@fidh.org', '', '', '2019-03-29 09:46:50', 1, NULL, 0, 0),
(65, 'Commission Nationale de lutte contre la circulation illicite des armes légères et de petits calibre', '63', 'ComNat-ALPC', '2', 'Abidjan', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-29 09:54:34', 1, NULL, 0, 0),
(66, 'Commission défense de l’Assemblée Nationale', '64', 'CDAN', '2', 'Assemblée nationale \r\n01 B.P. 1381 \r\nABIDJAN 01', '20 21 60 69  20 20 82 00 / 20 21 11 59 / 20 20 82 34', NULL, 'http://www.assnat.ci', 'courrier@assnat.ci', '', '', '2019-03-29 10:01:23', 1, NULL, 0, 0),
(67, ' Ministre auprès du Président de la République chargé des affaires politiques', '65', 'MAPRCAP', '2', 'Abidjan', 'A définir', NULL, 'http://www.presidence.ci', 'ND@gmail.com', 'https://www.google.com/maps/place/Palais+Pr%C3%A9sidentiel/@5.3209774,-4.0343018,15z/data=!4m13!1m7!3m6!1s0xfc1ebb4520be1d3:0xfebe0691dbac19bf!2sPresidence,+Abidjan!3b1!8m2!3d5.3220053!4d-4.0248483!3m4!1s0xfc1ebb60c8cd967:0xa1d998402edcdf45!8m2!3d5.3182963!4d-4.0215084', '', '2019-03-29 10:10:55', 1, NULL, 0, 0),
(68, 'Conseil pour l’Assistance Humanitaire et le Développement', '66', 'CAHD', '3', 'BP 109 Duekoué\r\n', '+225 33000333', NULL, '', 'cahd.ci2015@gmail.com', 'https://www.google.com/search?tbm=lcl&ei=3gzcXIW-O9PuxgPrn7TYBQ&q=duekoue+ville&oq=DUEKOUE&gs_l=psy-ab.1.8.0l10.9491.21952.0.29732.14.9.2.3.3.0.287.1787.0j1j7.8.0..2..0...1c.1.64.psy-ab..1.13.1799...0i67k1j0i131k1j0i10k1.0.hBgFd6WGhxg#rlfi=hd:;si:,6.748407517339126,-7.308908509479579;mv:!1m2!1d7.150551184952923!2d-6.457468079792079!2m2!1d6.370496772459648!2d-7.756601380573329!4m2!1d6.760681349962165!2d-7.107034730182704!5i10', '', '2019-03-29 10:25:38', 1, '2019-05-15 00:00:00', 5, 0),
(69, 'Réseau Ivoirien des Jeunes Leaders pour l’Intégrité', '67', 'RIJLI ', '3', '01 BP 10984 Abidjan 01', '07348311', NULL, '', 'secretariatdurijli@gmail.com', 'https://www.google.com/search?q=angr%C3%A9+chateau&npsic=0&rflfq=1&rlha=0&rllag=5413321,-3982025,141&tbm=lcl&ved=2ahUKEwiEkZeQy53iAhVKRRUIHfJWC00QtgN6BAgJEAQ&tbs=lrf:!2m1!1e2!2m1!1e3!3sIAE,lf:1,lf_ui:2&rldoc=1#rlfi=hd:;si:;mv:!1m2!1d5.450373754620329!2d-3.9108533185302576!2m2!1d5.362874156801537!2d-4.073244981127914!4m2!1d5.406625536576236!2d-3.9920491498290858!5i13', '', '2019-03-29 10:30:49', 1, '2019-05-15 00:00:00', 5, 0),
(70, 'Agence Emploi Jeune du Ministère de la Promotion de la Jeunesse et de l’Emploi des Jeunes', '68', 'AEJ', '2', 'PLATEAU, BD CLOZEL / IMMEUBLE PERIGNON', 'Tél. : 20 21 50 53/20 22 80 32', NULL, 'https://agenceemploijeunes.ci/site/', 'info@emploijeunes.ci', 'https://www.google.com/maps/place/Agence+Emploi+Jeunes/@5.3282418,-4.0231365,17z/data=!3m1!4b1!4m5!3m4!1s0xfc1ebb02b5e5dfd:0xf5a2af9f66156de6!8m2!3d5.3282418!4d-4.0209478', '', '2019-03-29 10:39:29', 5, NULL, 0, 0),
(71, 'Police Nationale', '69', 'Police', '2', 'en face de l\'univeriste de Cocody, Rue des Jardins, Abidjan', ' 20 22 42 27', NULL, 'http://enp-ci.net/', 'admin@enp-ci.net', '', '22 48 55 66/01 16 61 19', '2019-03-29 11:12:56', 5, '2019-03-29 00:00:00', 5, 0),
(72, 'Gendarmerie Nationale', '70', 'Gendarmerie ', '3', 'Abidjan Cocody', ' 20 21 85 77', NULL, '', 'ND@gmail.com', 'https://www.google.com/search?ei=z_ydXPH9LeOj1fAPiP2f0AM&q=gendarmerie%20nationale%20ivoirienne&oq=Gendarmerie+Nationale&gs_l=psy-ab.1.2.0i67l2j0l8.29632.29632..32630...0.0..0.190.190.0j1......0....2j1..gws-wiz.......0i71.I4ZtMbPQfLo&npsic=0&rflfq=1&rlha=0&rllag=5355343,-3993344,759&tbm=lcl&rldimm=10724775838407759250&ved=2ahUKEwiJ45WNnKfhAhWVTRUIHVHVDysQvS4wDnoECAoQHg&rldoc=1&tbs=lrf:!2m1!1e2!3sIAE,lf:1,lf_ui:2#rlfi=hd:;si:10724775838407759250;mv:!1m2!1d5.3640934!2d-3.9490325!2m2!1d5.3094771!2d-4.0151845;tbs:lrf:!2m1!1e2!3sIAE,lf:1,lf_ui:2', '', '2019-03-29 11:21:42', 5, NULL, 0, 0),
(73, 'Forces républicaines de Côte d\'Ivoire', '71', 'FRCI', '2', 'Abidjan', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-29 11:28:01', 5, NULL, 0, 0),
(74, 'MINISTÈRE DE L’ÉDUCATION NATIONALE ET DE L’ENSEIGNEMENT TECHNIQUE', '72', 'MENET', '2', 'BPV 120 Abidjan', '+225 20 21 02 75', NULL, 'http://www.education.gouv.ci/', 'infoline@menci.org', 'https://www.google.com/maps/place/Minist%C3%A8re+de+l\'Education+Nationale/@5.3323171,-4.0253896,17z/data=!3m1!4b1!4m5!3m4!1s0xfc1ebae98dbafad:0x801b4f2bb680782b!8m2!3d5.3323171!4d-4.0232009', '', '2019-03-29 19:30:29', 5, NULL, 0, 0),
(75, 'MINISTÈRE DE LA CULTURE ET DE LA FRANCOPHONIE', '74', 'MCF', '2', 'Cité Administrative,Tour E, 21ème étage. Porte 25\r\nBP V 39 ABIDJAN', ' 20 21 83 94', NULL, 'http://www.culture.gouv.ci/', 'miniculture.francophonie@gmail.com', '', '', '2019-03-29 19:36:08', 5, NULL, 0, 0),
(76, ' Centre d\'Information et de Communication Gouvernementale', '75', 'CICG', '2', 'Cité \"Résidence Colombe\", villa n° 27, 2 plateaux Vallon, en face du groupe scolaire \"les dauphins\" 01BP12243 ABIDJAN 01 CI', '22 51 14 38', NULL, 'http://www.cicg.gouv.ci/', 'ND@gmail.com', '', '', '2019-03-30 23:06:11', 5, NULL, 0, 0),
(77, 'ORGANISATION DES NATIONS ', '76', 'ONU', '3', '19, Rue de la Paix, Ancien Hotel SEBROKO\r\nPlateau - 08 BP 588 Abidjan 08\r\nAbidjan - Côte d’Ivoire', '20 23 54 00', NULL, 'https://onuci.unmissions.org/', 'ND@gmail.com', 'https://www.google.com/maps/search/onuci/@5.3444558,-4.0090056,13z/data=!3m1!4b1', '', '2019-03-30 23:13:32', 5, NULL, 0, 0),
(78, 'Réseau paix et sécurité des femmes de l\'espace Cedeao', '77', 'REPSFECO', '3', 'Bietry - Zone 4 C\r\nMarcory - 08 BP 1078 Abidjan 08\r\nAbidjan - Côte d’Ivoire', '21 35 09 03', NULL, 'http://repsfeco.over-blog.com/', 'ND@gmail.com', '', '', '2019-03-30 23:19:29', 5, NULL, 0, 0),
(79, 'A définir', '78', 'PLURIEL', '3', 'A définir', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-30 23:23:15', 5, NULL, 0, 0),
(80, 'Confédération internationale d\'organisations catholiques à but caritatif', '79', 'CARITAS', '3', 'A côté de l\'église St Ambroise Ma vigne - Angré 7è tranche\r\nCocody - 01 BP 2590 Abidjan 01\r\nAbidjan - Côte d’Ivoire', '22 42 95 96', NULL, 'http://www.caritas-ci.org/', 'caritascotedivoire@caritas-ci.org', '', '', '2019-03-30 23:25:57', 5, '2019-03-30 00:00:00', 5, 0),
(81, 'Union des Radios de Proximité de Côte d\'Ivoire', '80', 'URPCI', '3', 'Adjamé 80 Logements, Bâtiment C2, 4ème étage P.40\r\n21 BP 000 Abidjan 21', '20 38 20 16 / 07 98 93 54', NULL, 'http://urpci.net/', 'info@urpci.net', '', '', '2019-03-30 23:32:56', 5, NULL, 0, 0),
(82, 'ALLIANCE DES RELIGIEUX CONTRE LE VIH/SIDA ET LES AUTRES PANDEMIES', '81', 'ARSIP', '3', 'A définir', '03771496 / 24381162', NULL, '', 'alliancereligieux_sida@yahoo.fr', '', '', '2019-03-30 23:37:36', 5, NULL, 0, 0),
(84, 'A définir', '83', 'CSO', '3', 'A définir', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-30 23:47:37', 5, NULL, 0, 0),
(85, 'Femmes Pour la Debout Progrès en Côte d\'Ivoire ', '84', 'FDPCI', '3', 'A définir', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-03-30 23:52:24', 5, NULL, 0, 0),
(86, 'ONG Centre Solidarité Action Sociale', '85', 'ONG CSAS', '3', 'La cité des Hameaux\r\n01 BP 3812 Bouaké 01\r\nBouaké - Côte d’Ivoire', '31 64 19 44/ 05 60 78 65/ 05 06 66 65/ 49 39 98 87', NULL, 'http://centresas-ci.org/', 'info@centresas-ci.org', '', '', '2019-03-30 23:58:01', 5, NULL, 0, 0),
(87, 'ORGANISATION INTERNATIONALE POUR L\'ENFANT LA FEMME ET LA FAMILLE', '86', 'ONEF ', '3', 'carrefour de la station Oilybia, A gauche 1er Parking couvert, villa N°281, Imm. Addad, II Plateaux SICOGI - Deux-plateaux - SOCOCE\r\nCocody - 22 BP 1316 Abidjan 22\r\nAbidjan - Côte d’Ivoire', '22 41 54 83 / 22 44 36 14 / 07 73 34 56 ', NULL, '', 'ND@gmail.com', '', '', '2019-03-31 00:00:26', 5, NULL, 0, 0),
(88, 'Institution du Médiateur de la République', '87', 'MEDIATEUR', '3', 'Abidjan,\r\nCocody Boulevard de l\'Université près de l\'INSAAC\r\n≡  Côte d\'Ivoire  ≡\r\n', '22 44 21 68', NULL, 'http://www.mediateur-republique.ci/refonte2018/', 'secretariat@mediateur.ci', '', '', '2019-03-31 00:03:26', 5, NULL, 0, 0),
(89, 'Office National de la Population', '88', 'ONP', '2', '08 BP 2967 Abidjan 08\r\nCocody, II Plateaux, Rue J 11, lot n°347, ilot n° 39', '22 41 97 80/  22 41 97 82', NULL, 'http://www.onp.gouv.ci/', 'ND@gmail.com', '', '', '2019-04-01 08:14:35', 5, NULL, 0, 0),
(90, 'Institut National de la Statistique', '89', 'INS', '2', 'Cité Administrative . Tour C, 2ième Etage\r\nBP V 55\r\nABIDJAN - Plateau', '20.33.88.60 / 20.33.88.62 / 20.33.88.58', NULL, 'http://www.ins.ci/', 'ins.rci.diffusion@gmail.com', '', '', '2019-04-01 08:19:10', 5, NULL, 0, 0),
(91, 'Office Ivoirien du Patrimoine Culturel ', '90', 'OIPC', '2,3', 'Angré, 7e tranche\r\nCocody - 27 BP 643 Abidjan 27\r\nAbidjan - Côte d’Ivoire', '22 42 91 15 / 22 42 91 16 / 09 79 90 80 / 45 10 06 11', NULL, '', 'infos@oipc-ci.com', '', '', '2019-04-01 08:23:29', 5, '2019-04-01 00:00:00', 5, 0),
(92, 'DIRECTION DU PATRIMOINE CULTUREL', '91', 'DPC', '2,3', 'Bd Carde, Tour E, 19e Etage, Porte 50\r\nPlateau\r\nAbidjan - Côte d’Ivoire', '20 21 53 21', NULL, '', 'ND@gmail.com', '', '', '2019-04-01 08:28:26', 5, '2019-04-01 00:00:00', 5, 0),
(93, 'Commission Nationale Ivoirienne pour l\'UNESCO', '92', 'COMNAT UNESCO', '2,3', 'Institut Goethe, Avenue Mermoz Abidjan dernière rue après l, Avenue Mermoz, Abidjan', ' 22 44 05 49', NULL, '', 'ND@gmail.com', '', '', '2019-04-01 08:30:35', 5, '2019-04-01 00:00:00', 5, 0),
(94, 'Institut National Supérieur des Arts et de l\'Action Culturelle', '93', 'INSAAC', '2,3', 'Abidjan, Cocody\r\n08 BP 49 ABIDJAN 08\r\nCocody, boulevard de l\'Université', '22442673 ', NULL, 'http://www.insaac.edu.ci/', 'contact@insaac.edu.ci', '', '', '2019-04-01 08:32:28', 5, '2019-04-01 00:00:00', 5, 0),
(95, 'Fondation Félix Houphouët Boigny pour la Recherche de la Paix', '94', 'FFHBRP', '2,3', 'Rue De La Fondation, Yamoussoukro\r\n\r\nAnnexe\r\n\r\nB.P. 3941 Abidjan 01, Côte d\'Ivoire\r\n\r\n', ' 30 64 31 04/ 20 21 63 72', NULL, 'http://www.fondation-fhb.org', 'info@fondation-fhb.org', '', '', '2019-04-01 08:36:15', 5, '2019-04-01 00:00:00', 5, 0),
(96, 'Réseaux et associations de jeunes ', '95', 'RAJ', '3', 'A définir', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-04-01 08:38:51', 5, NULL, 0, 0),
(97, 'Chaire UNESCO pour la Culture de la Paix ', '96', 'Chaire UNESCO ', '3', 'Université Félix Houphouët Boigny, Abidjan - Cocody, Côte d\'Ivoire', ' 05 210 008 / 05 169 009 / 05 100 885', NULL, '', 'contact@chaire-unesco.org', '', '', '2019-04-01 08:43:02', 5, NULL, 0, 0),
(98, 'CulturAfrik', '97', 'CulturAfrik', '3', 'A définir', 'A définir', NULL, '', 'ND@gmail.com', '', '', '2019-04-01 08:45:33', 5, NULL, 0, 0),
(99, 'Fondation Amigo', '98', 'AMIGO', '3', 'Centre Amigo Doumé - Niangon Lokoa\r\nYopougon - 31 BP 113 Abidjan 31\r\nAbidjan - Côte d’Ivoire', '05 92 27 90 ', NULL, '', 'ND@gmail.com', '', '', '2019-04-01 08:48:17', 5, NULL, 0, 0),
(100, 'GRAINE DE PAIX', '99', 'GDP', '3', 'Cocody Deux Plateaux\r\n7e tranche, L155\r\n06 BP 6761 Abidjan 06\r\nCôte d\'Ivoire\r\n\r\nBâtiment gris carrelé, RdC', '22 52 21 06 / 07 99 1960 / 05 97 2275', NULL, '', 'ND@gmail.com', '', '', '2019-04-01 08:51:43', 5, NULL, 0, 0),
(101, 'Ministère des Affaires Intérieures du Libéria', '100', 'MAI-Libéria', '2', 'Libéria', 'A définir', NULL, '', 'GN@gmail.com', '', '', '2019-04-02 10:44:57', 6, NULL, 0, 0),
(102, 'Bureau de l’Immigration et de la Naturalisation', '101', 'BIN-Libéria', '2', 'Libéria', 'A définir', NULL, '', 'Gn@gmail.com', '', '', '2019-04-02 10:45:43', 6, NULL, 0, 0),
(103, 'Police Nationale Libérienne', '102', 'POLICE Libérienne', '2', 'Libéria', 'A définir', NULL, '', 'Gn@gmail.com', '', '', '2019-04-02 10:46:55', 6, NULL, 0, 0),
(104, 'Autorités de développement du comté', '103', 'ADC-Libéria', '2', 'Libéria', 'A définir', NULL, '', 'Gn@gmail.com', '', '', '2019-04-02 10:48:02', 6, NULL, 0, 0),
(105, 'Présidence de la République CSSR', '104', 'CSSR', '2', 'Avenue Hoven, Abidjan', '21 27 97 27', NULL, 'http://www.presidence.ci/', 'presidencecotedivoire@diplomats.com', '', '', '2019-04-03 10:41:01', 8, NULL, 0, 0),
(106, 'Présidence de la République (CNS)', '105', 'CNS', '2', ' Avenue Hoven, Abidjan', '21 27 97 27', NULL, 'http://www.presidence.ci/', 'presidencecotedivoire@diplomats.com', '', '', '2019-04-03 10:42:12', 8, NULL, 0, 0),
(107, 'Association Nationale des Chefs, Reines, Rois de Côte d’Ivoire ', '106', 'ANCRRCI', '3', 'A définir', 'A définir', NULL, '', 'GN@GMAIL.COM', '', '', '2019-04-03 11:29:43', 7, NULL, 0, 0),
(108, 'Université Félix Houphouët-Boigny', '107', 'UFHB', '2', '01 BPV 34 Abidjan 01', '55 59 59 37', NULL, 'http://univ-fhb.edu.ci', 'secretariat.presidence@univ-fhb.edu.ci', '', '', '2019-04-06 09:18:25', 6, NULL, 0, 0),
(109, 'Université Alassane Ouattara\r\n\r\n', '108', 'UAO', '2', 'Bp v 18 Bouaké 01 Région du Gbèkê Côte d\'Ivoire  ', '+225 31 00 00 39 ', NULL, 'http://www.univ-ao.edu.ci/', 'infoline@uao.edu.ci', '', '', '2019-04-06 09:26:36', 6, NULL, 0, 0),
(110, 'Université Pelelforo GON COULIBALY(UPGC)', '109', 'UPGC', '2', 'KORHOGO', 'A définir', NULL, 'http://www.univ-pgc.edu.ci/', 'GN@GMAIL.COM', '', '', '2019-04-06 09:33:22', 6, NULL, 0, 0),
(111, 'COMMUNAUTES', '110', 'COMMUNAUTES', '3', 'A définir', 'A définir', NULL, '', 'GN@GMAIL.COM', '', '', '2019-04-06 10:08:45', 6, NULL, 0, 0),
(112, 'CLINIQUES JURIDIQUES', '111', 'CLIN-JUR', '3', 'A définir', 'A définir', NULL, '', 'GN@GMAIL.COM', '', '', '2019-04-06 10:09:32', 6, NULL, 0, 0),
(113, 'Ministere de l\'Economie et des finances', '112', 'MEF', '2', 'Imm. SCIAM, 18 ème étage\r\nPlateau\r\nAbidjan - Côte d’Ivoire', ' (+225) 20 30 25 26 / (+225) 20 30 25 28', NULL, 'https://finances.gouv.ci//', 'finances@mef.net', '', '', '2019-04-06 10:25:22', 6, NULL, 0, 0),
(114, 'OCB', '113', 'OCB', '3', 'A définir', 'A définir', NULL, '', 'Gn@gmail.com', '', '', '2019-04-08 11:37:35', 6, NULL, 0, 0),
(115, 'A définir', '114', 'IMR', '3', 'A définir', 'A définir', NULL, '', 'gn@mail.com', '', '', '2019-04-09 11:25:27', 7, NULL, 0, 0),
(116, 'Centre de recherche et d\'action pour la paix', '115', 'CERAP', '3', ' 15, avenue Jean Mermoz, Cocody. 08 BP 2088 Abidjan 08 Côte d\'Ivoire', '+225 22 40 47 20', NULL, 'http://cerap-inades.org', 'servicecom@cerap-inades.org', 'https://www.google.com/maps/place/Centre+de+Recherche+et+d\'Action+pour+la+Paix/@5.3396719,-4.0006006,15z/data=!4m12!1m6!3m5!1s0x0:0x9ecf98221f1475c8!2sCentre+de+Recherche+et+d\'Action+pour+la+Paix!8m2!3d5.3396719!4d-4.0006006!3m4!1s0x0:0x9ecf98221f1475c8!8m2!3d5.3396719!4d-4.0006006', 'Le Centre de Recherche et d\'Action pour la Paix est l\'héritier, depuis 2002, de l\'Institut Africain de Développement Économique et Social créé en 1962. Le CERAP abrite: un institut universitaire jésuite ainsi qu\'un Pôle social.', '2019-04-09 11:28:28', 7, NULL, 0, 0),
(117, 'Initiative de Dialogue et Recherche Action pour la Paix en Côte d\'Ivoire (Indigo Côte d\'Ivoire)', '116', 'INDIGO', '3', '22 BP 288 Abidjan 22, Côte d\'Ivoire\r\n', '+225 20 00 05 64 / +225 06 54 39 92', NULL, 'http://www.indigo-ci.org/', 'info@indigo-ci.org', '', 'Dans la mesure où il permet à la société de se réinventer, le conflit en lui-même est normal. C\'est donc dans le but d\'aider les sociétés à travailler à leur réinvention, autrement que par la violence, qu\'un groupe de chercheurs a mis en ouvre l\'Initiative de Dialogue et Recherche Action pour la Paix en Côte d\'Ivoire (Indigo Côte d\'Ivoire).Dans la mesure où il permet à la société de se réinventer, le conflit en lui-même est normal. C’est donc dans le but d’aider les sociétés à travailler à leur réinvention, autrement que par la violence, qu’un groupe de chercheurs a mis en œuvre l’Initiative de Dialogue et Recherche Action pour la Paix en Côte d’Ivoire (Indigo Côte d’Ivoire)', '2019-04-09 11:37:56', 7, NULL, 0, 0),
(118, 'Observatoire National de l\'Equité et du Genre', '117', 'ONEG', '2', 'A définir', 'A définir', NULL, '', 'gn@jd.com', '', '', '2019-04-09 12:20:57', 7, NULL, 0, 0),
(120, 'Office du service civique national', '001', 'OSCN', '2', '01 Bp 10550 Abidjan 01', '22499304', NULL, '', 'mtoure_aziz@yahoo.fr', '', 'Promotion du  service civique, employabilite des jeunes les plus vulnerables', '2019-05-15 14:48:42', 6, '2019-05-15 00:00:00', 1, 0),
(121, 'Réseau Action Justice et Paix', '300', 'RAJP', '3', 'Abidjan-Cocody Angré Djibi 3 Résidences Arc-en-Ciel Rue 4 Verte. 10 BP 1183 Abidjan10', '08203676', NULL, '', 'rajp.civ@gmail.com', '', '', '2019-05-15 14:54:10', 26, '2019-05-15 00:00:00', 26, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_programmes`
--

DROP TABLE IF EXISTS `t_programmes`;
CREATE TABLE IF NOT EXISTS `t_programmes` (
  `id_programme` int(11) NOT NULL AUTO_INCREMENT,
  `code_programme` varchar(255) DEFAULT NULL,
  `sigle_programme` varchar(30) DEFAULT NULL,
  `nom_programme` mediumtext,
  `pays` varchar(255) DEFAULT NULL,
  `vision` mediumtext,
  `objectif` mediumtext,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `budget_estimatif` int(11) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT '0',
  `type_programme` int(1) NOT NULL DEFAULT '0',
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_programme`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_programmes`
--

INSERT INTO `t_programmes` (`id_programme`, `code_programme`, `sigle_programme`, `nom_programme`, `pays`, `vision`, `objectif`, `date_debut`, `date_fin`, `budget_estimatif`, `statut`, `type_programme`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `etat`) VALUES
(1, '01', 'PPII', 'Plan Prioritaire 2', 'Côte d\'Ivoire', 'consolidation de la paix, financé par le Fonds des Nations Unies pour la Consolidation de la Paix ', 'Financement des élection et consolidation de la paix', '2015-01-01', '2017-12-31', 12000000, 0, 0, '2019-01-29 10:59:47', 1, '2019-02-06 00:00:00', 1, 0),
(2, '00', 'ONUCI', 'Organisation des Nations Unis en CI', 'Côte d\'Ivoire', 'Organisation pacifique des élections en Côte d\'Ivoire', 'Maintient de la Paix', '2006-01-01', '2012-12-15', 0, 0, 1, '2019-01-29 11:54:17', 1, '2019-02-06 00:00:00', 1, 0),
(3, '02', 'PACoP', 'Programme d’Appui à la Consolidation de la Paix ', 'Côte d\'Ivoire', 'Poursuivre le renforcement des capacités des différents acteurs, à pérenniser et consolider les acquis de la Côte d’Ivoire en matière de consolidation de la paix, de réconciliation nationale et de cohésion sociale après le départ de l’ONUCI', 'Contribuer à la promotion de la paix et de la réconciliation, en mettant un accent particulier sur les parties ouest, Sud-ouest, Centre-nord et Nord-est du pays qui sont plus affectées par les conflits', '2017-01-01', '2019-12-31', 50000000, 0, 0, '2019-01-29 12:09:08', 1, '2019-02-14 00:00:00', 6, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_projets`
--

DROP TABLE IF EXISTS `t_projets`;
CREATE TABLE IF NOT EXISTS `t_projets` (
  `id_projet` int(11) NOT NULL AUTO_INCREMENT,
  `programme` int(11) NOT NULL,
  `code_projet` varchar(10) DEFAULT NULL,
  `sigle_projet` mediumtext,
  `nom_abrege` text,
  `intitule_projet` mediumtext,
  `date_signature` date DEFAULT NULL,
  `modalite_financement` enum('IRF','PRF','Autre') DEFAULT NULL,
  `type_fonds_fidicuiare` enum('Pays','Régional','Aucun') DEFAULT NULL,
  `nom_fonds_fidicuaire` varchar(255) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT '0',
  `agence_lead` int(11) DEFAULT NULL,
  `autres_agences_recipiendaires` mediumtext,
  `partenaires_signataires` mediumtext,
  `autres_partenaires_execution` mediumtext,
  `fenetre_pbf` mediumtext,
  `zone` mediumtext,
  `nature` mediumtext,
  `date_demarrage` date DEFAULT NULL,
  `duree` int(11) DEFAULT NULL,
  `bailleur` varchar(30) NOT NULL,
  `description_projet` mediumtext,
  `processus_consultation` mediumtext,
  `pourcentage_budget_genre` int(11) DEFAULT NULL,
  `description_marqueur_genre` varchar(255) DEFAULT NULL,
  `niveau_risque` int(11) NOT NULL,
  `domaine_intervention_prioritaire` varchar(255) DEFAULT NULL,
  `resultat_undaf` varchar(255) DEFAULT NULL,
  `objectif_odd` text,
  `couleur_shp` varchar(7) DEFAULT NULL,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_projet`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_projets`
--

INSERT INTO `t_projets` (`id_projet`, `programme`, `code_projet`, `sigle_projet`, `nom_abrege`, `intitule_projet`, `date_signature`, `modalite_financement`, `type_fonds_fidicuiare`, `nom_fonds_fidicuaire`, `statut`, `agence_lead`, `autres_agences_recipiendaires`, `partenaires_signataires`, `autres_partenaires_execution`, `fenetre_pbf`, `zone`, `nature`, `date_demarrage`, `duree`, `bailleur`, `description_projet`, `processus_consultation`, `pourcentage_budget_genre`, `description_marqueur_genre`, `niveau_risque`, `domaine_intervention_prioritaire`, `resultat_undaf`, `objectif_odd`, `couleur_shp`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `etat`) VALUES
(1, 3, '001', 'APDCP', NULL, 'Appui au processus démocratique et de consolidation de la paix en Côte d’Ivoire', '2018-09-10', 'PRF', NULL, '', 0, 1, '5', '1', '12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31', '3', 'Couverture nationale avec des interventions ciblées dans les zones encore sensibles et potentiellement confligènes sur la base des récentes échéances électorales notamment : Abidjan, Aboisso, Bonoua, Agboville, Bouaké, Bingerville, Séguéla, San-Pedro, Divo, Gagnoa, Odienné, Man, Biankouma, Guiglo, Dabou, Duékoué, Korhogo, Ferkessédougou, Daloa, Bonon, Katiola, Dabakala, Bondoukou et Bouna.', 'RAS', '2018-09-10', 18, '21', '<span style=\'margin: 0px; letter-spacing: -0.15pt; font-family: \"Times New Roman\",\"serif\"; font-size: 12pt;\'>Le présent projet met\r\nl’accent sur l’accompagnement du dialogue politique pour un climat apaisé avant,\r\npendant et après les élections en contribuant à l’émergence d’acteurs capables\r\nde faire des propositions pouvant faciliter la consolidation de la paix, le\r\nrenforcement de la démocratie et la prévention des conflits. Il s’agira\r\négalement de promouvoir la participation politique des femmes et des jeunes au\r\nniveau central et local à travers la canalisation et la prise en compte de\r\nleurs aspirations au processus global de consolidation de la paix et de\r\nrenforcement des dynamiques démocratiques. En adressant conjointement\r\nl’impérative question du dialogue politique et de la participation citoyenne à\r\ntravers la formation, la sensibilisation et la création de cadres de dialogues\r\net d’échanges, tant au niveau central que local, auprès des jeunes, des femmes,\r\ndes leaders politiques, des leaders communautaires et religieux dans les\r\nlocalités encore potentiellement confligènes, le projet suscitera très\r\nrapidement le dialogue inclusif jusqu’à présent très faible et renforcera\r\nl’implication systématique de jeunes et de femmes formés et sensibilisés dans\r\nla prévention et la résolution des conflits en lien avec les élections. Les\r\nrésultats rapides et l’impact positif tangible du projet sur le processus\r\nélectoral et l’environnement politique et social en général, mobilisera les\r\nautres partenaires techniques et financiers pour la pérennisation et la\r\nconsolidation des acquis du projet. Une telle approche attenue le risque en ce\r\nqu’il contribue efficacement à la tolérance politique et renforce la dynamique\r\nde cohésion sociale afin de prévenir les violences électorales qui constituent\r\nl’un des risques majeurs du processus. L’innovation dans le cadre du présent\r\nprojet est son approche intégrée caractérisée par une plus forte implication\r\ndes jeunes et des femmes dans le dialogue politique et leur responsabilisation\r\nen vue de renforcer la crédibilité du processus électoral et éviter le recours\r\nsystématique à la violence pour résoudre les différends dans ce cadre.</span>', '<span style=\'margin: 0px; font-family: \"Times New Roman\",\"serif\"; font-size: 12pt;\'>La formulation du\r\nprojet a fait l’objet d’une large consultation avec les institutions nationales\r\nen charge du processus électoral, notamment la Commission Electorale\r\nIndépendante (CEI), le Ministère de la Solidarité, de la Cohésion Sociale et de\r\nla Lutte Contre la Pauvreté (MSCSLCP), ainsi que les Organisations de la\r\nSociété Civile nationale et internationale qui accompagnent le processus\r\nélectoral en Côte d’Ivoire, à savoir : l’Institut Gorée de Dakar, le\r\nNational Democratic Institute (NDI), le Réseau des femmes leaders africaines,\r\nle Forum des femmes des partis politiques, le Groupe consultatif de la société\r\ncivile et la Plateforme des jeunes et des femmes pour des élections apaisées en\r\nCôte d’Ivoire. </span>', 40, 'Les trois résultats stratégiques du projet prennent en compte les besoins différenciés entre les hommes et les femmes afin d’apporter une contribution significative à l’égalité entre les sexes. Le résultat 3 du projet est spécifiquement dédié à l’égalité ', 9, '15', '', '', '#2ecc3e', '2019-01-30 09:32:50', 0, '2019-04-04 15:29:51', 6, 0),
(2, 3, '002', 'POC', NULL, 'Participation des jeunes à la gestion durable des ressources forestières pour le renforcement de la cohésion sociale dans la région Ouest de la Côte d’Ivoire ', '2018-12-01', 'IRF', NULL, '', 0, 1, '2', NULL, '12,13,14,15,16,17,18,19,20,30,33,34', '2', 'Dans l’Ouest de la Côte d’Ivoire (les localités de Drobo, de Séguéla et de Bloléquin abritant les forêts classées du Haute Dodo, de Séguéla et du SCIO)', '', '2018-12-01', 18, '21', '<span style=\"margin: 0px;\"><span style=\'margin: 0px; font-family: \"Calibri Light\",\"sans-serif\"; font-size: 10pt;\'> </span></span><span style=\'margin: 0px; font-family: \"Times New Roman\",\"serif\"; font-size: 12pt;\'><span style=\'margin: 0px; font-family: \"Times New Roman\",\"serif\"; font-size: 12pt;\'>Le présent projet est urgent. Le processus de\r\ndéguerpissement des occupations illégales de plus de 50% des forêts classées\r\npar des exploitants agricoles en Côte d’Ivoire démarré par le Gouvernement en\r\n2016 avec le Mont Péko va connaître un coup d’accélération cette année. Les\r\ndélocalisations des forêts classées de Haute Dodo, de Scio et de Séguéla sont\r\nprévues dans le second semestre de l’année 2018 par la SODEFOR. Or, lesdites\r\névacuations ont engendré auparavant des conflits entre les populations habitant\r\nles forêts et les autres communautés riveraines et ont eu comme conséquence\r\nentre autres la perte des moyens de productions, les traumatismes des déplacés\r\n(en particulier les enfants et les femmes), des cas de violences sexuelles, des\r\ndifficultés d’accès aux services sociaux de base. A ce jour, aucune disposition\r\nn’a été prise par le Gouvernement pour empêcher qu’une telle situation se\r\nreproduise. Les enjeux liés à la mise en œuvre de ce projet, permettent\r\nd’affirmer qu’il a un rôle catalyseur. Car, la forte implication des jeunes et\r\nl’impact prévisible d’un tel projet sur la stabilité et la cohésion sociale\r\nentre les communautés cibles mobilisera les autres partenaires techniques et\r\nfinanciers pour une consolidation des acquis du projet. Le projet est tolérant\r\nau risque vu qu’il promeut une approche plus inclusive dans la résolution des\r\nconflits liés aux déguerpissements des forêts classées et la responsabilisation\r\ndes jeunes des communautés. Enfin, le projet est marqué par son caractère\r\ninnovant en ce que dans la perspective de l’évacuation des forêts de Haute Dodo,\r\nSéguela et Scio, <span style=\"margin: 0px;\">l’utilisation d’une plateforme multi acteurs de dialogue inclusif des\r\njeunes, des réseaux sociaux et NTIC dans la diffusion de l’information et la\r\npleine participation des organisations de jeunes à l’observation indépendante\r\nsur les forêts, <a name=\"_Hlk523122994\"><font color=\"#000000\">constituent une nouvelle approche qui\r\npeut être répliquée dans d’autres pays confrontés à la même situation.</font></a></span></span><span style=\"margin: 0px;\"><span style=\'margin: 0px; font-family: \"Calibri Light\",\"sans-serif\"; font-size: 10pt;\'> </span></span></span>', '<span style=\'color: rgb(0, 0, 0); font-family: \"Open Sans\", \"Helvetica Neue\", Helvetica, Arial, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\'>Le Ministère de la Solidarité, de la Cohésion Sociale et de la Lutte contre la Pauvreté, le Ministère de l’Economie Numérique et de la Poste et la SODEFOR ont été impliqués dans le processus de formulation de la note conceptuelle et aussi du document de projet, à travers l’identification du problème, le ciblage des zones prioritaires d’intervention et des bénéficiaires, et le partage de données chiffrées. Les Organisations de la Société Civile fortement impliquées sur la problématique de la cohésion, de la gestion des ressources forestières et de la promotion des TIC, notamment « Femmes et TIC », ASAPSU, IMPACTUM, DRAO, APDVH, IDEF et GNTCI ont contribué à l’identification des approches de solutions aux problèmes de cohabitation pacifique et de gestion durable des ressources naturelles. Les OSC partenaires, ont été également impliquées afin de tirer avantage de leurs expériences de terrain dans l’Ouest du pays sur les questions de cohésion sociale et de gestion durable des ressources naturelles. Des séances de travail et échanges, à l’effet d’avoir une approche de participation inclusive des acteurs locaux concernés dans l’identification des défis, des solutions et de l’approche de mise en œuvre du projet ont eu lieu. </span>', 32, '', 9, '16', '<p>\r\n\r\n</p><p style=\"margin: 0px;\"><span style=\"margin: 0px; layout-grid-mode: both;\"><font face=\"Times New Roman\" size=\"3\">D’ici 2020, les institutions nationales mettent en\r\nœuvre des politiques publiques qui renforcent la gouvernance et la cohésion\r\nso', '<font size=\"3\"><font face=\"Times New Roman\"><span style=\"margin: 0px;\"><p><span style=\"margin: 0px;\">Le cas échéant, le résultat\r\nde l’</span><b style=\"mso-bidi-font-weight:normal\"><span style=\"margin: 0px;\">UNDAF </span></b><span style=\"margin: 0px;\">auquel le projet\r\ncontribue : </span><span style=\"margin: 0px; layout-grid-mode: both;\">D’ici\r\n2020, les institutions nationales mettent en œuvre des politiques publiques qui\r\nrenforcent la gouvernance et la cohésion sociale pour réduire les inégalités</span><br></p><p style=\"margin: 0px;\"><span style=\"margin: 0px;\">Le cas échéant, </span><b style=\"mso-bidi-font-weight:normal\"><span style=\"margin: 0px;\">Objectif de Développement Durable</span></b><span style=\"margin: 0px;\"> auquel le projet contribue : Objectif de Développement Durable\r\n(ODD) n° 16 sur la Justice et la Paix.</span></p><p>\r\n\r\n<br></p></span></font></font>', NULL, '2019-02-13 16:29:15', 6, '2019-04-03 00:43:53', 6, 0),
(4, 3, '00108189', 'RPJFCCPCI', 'Projet jeunes', 'Renforcement de la participation des jeunes, des femmes et des communautés à la consolidation de la paix en Côte d’Ivoire', '2018-01-01', 'IRF', NULL, '', 0, 4, '1,3,7', NULL, '26,30,31,34,36,42,44,45,53,74,75,91,92,93,94,95,96,97,98,99,100,105,106,120', '2', 'District d’Abidjan, Grands Ponts, Loh Djiboua, Goh, Haut Sassandra, Sud Comoe Gbeke, Agneby Tiassa, Hambol, Guemon-Cavally-Tonkpi, Poro-Tchologo, ', 'RAS', '2018-01-01', 36, '21', 'Le projet initial est une initiative conjointe de l’UNICEF, du PNUD et de l’UNESCO visant à renforcer la participation des jeunes à la consolidation de la paix.  La présente révision initiée par les même agences et l’UNFPA, tout en s’appuyant sur les leçons apprises de la première phase, propose de mettre un accent particulier sur le rôle complémentaire des jeunes, des femmes et des leaders communautaires en tant qu’acteurs clé mais souvent marginalisés dans la résolution des conflits. Cette nouvelle étape cherchera, à travers leur inclusion dans des activités citoyennes et d’éducation à la paix ainsi que des incitatives communautaires pilotes et du renforcement des capacités en matière de prévention et de résolution des conflits, à consolider la cohésion de manière durable. Le projet visera explicitement l’inclusion et la participation des jeunes filles.', 'Le processus de consultation s’est articulé autour de 2 temps forts :  i)l’élaboration de la note conceptuelle avec les partenaires institutionnels qui a permis une analyse de la situation et défini les axes du projet, les résultats à atteindre et ii) la planification conjointe annuelle nationale, impliquant toutes les parties prenantes, y compris les acteurs non gouvernementaux, qui opérationnalise le projet tout en assurant la coordination des actions sur le terrain.\r\n\r\nLa note conceptuelle a été présentée au Comité technique des experts le 13 juin 2018 pour sa revue.', 30, 'score 2', 9, '16', NULL, '<p><font color=\"#000000\"><span lang=\"FR\" style=\'font-family: \"Times New Roman\",serif; font-size: 12pt; mso-bidi-font-size: 11.0pt; mso-fareast-font-family: \"Times New Roman\"; mso-ansi-language: FR; mso-fareast-language: EN-US; mso-bidi-language: AR-SA; mso-bidi-font-weight: bold;\'>le résultat de l’</span><b style=\"mso-bidi-font-weight: normal;\"><span lang=\"FR\" style=\'font-family: \"Times New Roman\",serif; font-size: 12pt; mso-bidi-font-size: 11.0pt; mso-fareast-font-family: \"Times New Roman\"; mso-ansi-language: FR; mso-fareast-language: EN-US; mso-bidi-language: AR-SA;\'>UNDAF </span></b><span lang=\"FR\" style=\'font-family: \"Times New Roman\",serif; font-size: 12pt; mso-bidi-font-size: 11.0pt; mso-fareast-font-family: \"Times New Roman\"; mso-ansi-language: FR; mso-fareast-language: EN-US; mso-bidi-language: AR-SA; mso-bidi-font-weight: bold;\'>auquel le projet\r\ncontribue :</span><b style=\"mso-bidi-font-weight: normal;\"><span lang=\"FR\" style=\'font-family: \"Times New Roman\",serif; font-size: 12pt; mso-fareast-font-family: \"Times New Roman\"; mso-ansi-language: FR; mso-fareast-language: EN-US; mso-bidi-language: AR-SA;\'> </span></b><span lang=\"FR\" style=\'font-family: \"Times New Roman\",serif; font-size: 12pt; mso-fareast-font-family: \"Times New Roman\"; mso-ansi-language: FR; mso-fareast-language: EN-US; mso-bidi-language: AR-SA;\'>Effet 1 : D’ici 2020, les institutions\r\nnationales mettent en œuvre des politiques publiques qui renforcent la\r\ngouvernance et la cohésion sociale pour réduire les inégalités</span>.</font><br></p>', '#00aeff', '2019-02-14 00:49:45', 6, '2019-05-15 15:40:41', 8, 0),
(5, 3, '04', 'FJFAPCAPRI', 'FEMMES', 'Les femmes et les jeunes filles, actrices de la prévention des conflits à travers l’alerte précoce et les réseaux d’informations', '2016-09-09', 'IRF', 'Aucun', '', 0, 5, '4', NULL, '25,26,27,28,29', '1', ' Ouest et Nord de la Côte d’Ivoire, Abidjan ', '', '2017-02-01', 18, '21', '<p><span style=\'margin: 0px; line-height: 103%; font-family: \"Calibri\",\"sans-serif\"; font-size: 11pt;\'>Ce projet vise à prévenir les conflits, consolider la paix et la\r\ncohésion sociale dans le Nord et à l’Ouest du pays ainsi qu’à Abidjan, en\r\nmilieux communautaires, ruraux/urbains et scolaires à travers le renforcement\r\ndu rôle des femmes et des jeunes filles dans les mécanismes d\'alerte précoce et\r\nla consolidation de la paix. </span><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><br></p>', '<p><br></p>', 100, '3', 8, '16', NULL, '', '', '2019-02-14 09:51:28', 6, '2019-05-15 17:29:36', 25, 0),
(6, 3, '005', 'SWEEP', NULL, 'Projet d’appui à l’engagement soutenu des femmes dans la consolidation de la paix et la sécurité à l’Ouest de la Côte d’Ivoire ', '2017-01-01', 'IRF', NULL, 'Fonds fiduciaire pays', 0, 6, NULL, NULL, '26,30,31,36,43,68,71,72,73', '1', 'Côte d’Ivoire: Bloléquin, Toulepleu, Guiglo, Taï, and Tabou', '', '2017-01-01', 18, '21', '<p><span style=\"font-size:12.0pt;font-family:\"Times New Roman\",\"serif\";\r\nmso-fareast-font-family:\"MS Mincho\";mso-ansi-language:FR;mso-fareast-language:\r\nEN-US;mso-bidi-language:AR-SA\">Renforcer la participation des citoyens dans la\r\nconsolidation de la paix et la sécurité à travers un engagement soutenu des\r\nfemmes et des jeunes dans le suivi et rapportage des problèmes de sécurités et\r\nde coexistence pacifique qui affectent les activités économiques, la\r\nconsolidation de la paix et la confiance entre les citoyens et les autorités à\r\nl’Ouest de la Côte d’Ivoire.</span><br></p>', '', 0, 'projets ayant l’égalité entre les sexes comme principal objectif.', 0, '14', NULL, '', NULL, '2019-03-11 15:47:36', 5, '2019-04-04 00:25:15', 5, 0),
(8, 3, '006', 'CROSS BORDER', NULL, 'Coopération transfrontalière entre la Côte d\'Ivoire et le Libéria pour la paix durable et la cohésion sociale ', '2017-01-01', 'IRF', NULL, '', 0, 1, '2', NULL, '30,31,36,42,43,47,50,51,52,101,102,103,104', '4', 'Côte d’Ivoire: départements deTabou et Taï\r\nLiberia :comtés du Maryland et du River Gee \r\n', '', '2017-04-01', 18, '21', '<span style=\"font-family: \"Times New Roman\", serif; font-size: 13.3333px; text-align: justify;\">Le projet vise à accroître la coopération et restaurer la confiance entre les ivoiriens et les communautés Ivoiriennes et libériennes frontalières en renforçant la sécurité des frontières et des populations, ainsi qu’en atténuant le risque d’une escalade des conflits et   d’une déstabilisation régionale, grâce à l\'engagement des communautés et à des activités socio-culturelles transfrontalières de rapprochement communautaire.</span><br>\r\n\r\n', '', 0, '', 0, '', NULL, '', NULL, '2019-03-21 11:48:14', 6, '2019-04-02 10:50:04', 6, 0),
(9, 3, '007', 'APOPGC', 'Appui à la pérennisation des outils', 'Appui à la pérennisation des outils de prévention et de gestion des conflits en Côte d’Ivoire', '2017-12-01', 'IRF', NULL, '', 0, 7, '1', NULL, '26,31,35,36,42,46,47,48,86,87,88,107', '1', 'District d’Abidjan, Grands Ponts, Boukani, Loh Djiboua, Goh, Haut Sassandra, Gbeke (Bouaké/Sakassou/Bocanda), Poro (Korhogo), Kabadougou (Odienné), Sud Comoe-Marahoue, Tonkpi-Guemon-Cavally', '', '2017-12-01', 18, '21', '<p><span style=\"font-size: 11pt; font-family: \"Times New Roman\", serif;\">Ce programme vise à\r\ncontribuer à la prévention et à la gestion pacifique et durable des conflits en\r\nCôte d’Ivoire à travers le renforcement des mécanismes de veille, de gestion de\r\nl’information ainsi que des compétences des cadres nationaux notamment les\r\nadministrateurs territoriaux. Sa mise en œuvre permettra de disposer d’un\r\nsystème modélisé et durable de gestion informatisé sur les déterminants de la\r\nsurvenue des conflits, toute chose qui permettra d’anticiper et de prendre des\r\nmesures de prévention et de mitigation des conflits inter et intracommunautaires.\r\nLes actions du projet </span><span style=\"font-size:11.0pt;font-family:\"Times New Roman\",\"serif\";\r\nmso-fareast-font-family:\"Times New Roman\";color:red;mso-ansi-language:FR;\r\nmso-fareast-language:EN-US;mso-bidi-language:AR-SA\">contribueront</span><span style=\"font-size: 11pt; font-family: \"Times New Roman\", serif;\"> au renforcement des capacités des institutions\r\nétatiques et de la société civile et à leur pérennisation en matière de\r\nprévention et de gestion pacifique des conflits. </span><br></p>', '', 0, 'Le genre et l’équité seront pris en compte dans le processus de mise en œuvre du projet. Des plaidoyers seront engagés afin que les institutions étatiques (OSCS, DGAT, ENA), le PNCS et les organisations de la société civile intègrent le genre et l’équité ', 0, '16', NULL, '<div><div><b><span style=\"font-size:11.0pt;font-family:\"Times New Roman\",\"serif\";mso-fareast-font-family:\r\n\"Times New Roman\";mso-ansi-language:FR;mso-fareast-language:EN-US;mso-bidi-language:\r\nAR-SA\">Résultat 1: </span></b><span style=\"font-family: \"Times New Roman\", serif; font-size: 11pt;\">L’observatoire de la solidarité et de la\r\ncohésion sociale, la DGAT et les structures de paix produisent régulièrement\r\ndes informations sur le niveau de la solidarité et de la cohésion sociale et\r\ncontribuent à l’amélioration des actions de prévention des conflits</span></div><div><b><span style=\"font-size:11.0pt;font-family:\"Times New Roman\",\"serif\";mso-fareast-font-family:\r\n\"Times New Roman\";mso-ansi-language:FR;mso-fareast-language:EN-US;mso-bidi-language:\r\nAR-SA\">Résultat 2: </span></b><span style=\"font-size:11.0pt;font-family:\"Times New Roman\",\"serif\";\r\nmso-fareast-font-family:\"Times New Roman\";mso-ansi-language:FR;mso-fareast-language:\r\nEN-US;mso-bidi-language:AR-SA\">Les administrateurs préfectoraux et\r\nsous-préfectoraux, le PNCS, et les acteurs de paix contribuent à la gestion\r\npacifique et durable des conflits et à la cohésion sociale.</span><span style=\"font-family: \"Times New Roman\", serif; font-size: 11pt;\"><br></span><br></div></div>', '', '2019-03-21 18:03:12', 7, '2019-05-15 15:27:57', 7, 0),
(10, 3, ' 00114217', 'EDDH', 'Projet Etat de Droit', 'Promouvoir l’Etat de droit  et les droits humains pour consolider la paix en Côte d’Ivoire', '2018-10-17', 'PRF', NULL, '', 0, 1, '10', NULL, '9,26,30,31,43,53,54,55,56,57', '3', 'le projet aura une couverture nationale et avec des interventions ciblées et localisées dans les zones encore sensibles et potentiellement confligènes dans le district autonome d’Abidjan et des régions : Cavally (Guiglo), Guemon, Tonkpi (Man), Gbeke (Bouake) et Bagoue (Boundiali) et Poro (Korhogo).', '', '2018-10-31', 24, '21', '<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";letter-spacing:-.15pt\">Le projet est\r\nrapide dans la mesure où il sera basé sur le plan de réparation communautaire\r\napprouvé déjà par la partie nationale, le document de stratégie de la CNDHCI et\r\nles dispositifs existants d’aide légale pour prévenir et résoudre les conflits\r\nfonciers.  <o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";letter-spacing:-.15pt\">Dans son\r\napproche catalytique le projet aidera, à travers ses différents cadres\r\nd’échanges entre partenaires essentiels incluant le gouvernement à poser les\r\nproblématiques d’accès à la justice, réparation communautaire en faveur des\r\nvictimes des violences postélectorales et à stimuler les contributions\r\nadditionnelles y compris auprès du gouvernement particulièrement dans la mise\r\nen œuvre du plan de réparation communautaire. Il contribuera ainsi à combler\r\nles déficits de financement de l’axe II du Programme d’Appui à la Consolidation\r\nde la Paix(PACoP) développé par l’Equipe de Pays des Nations Unies dans le\r\ncadre du plan de transition de l’ONUCI. <o:p></o:p></span></p><p>\r\n\r\n\r\n\r\n<span style=\"font-size:11.0pt;line-height:107%;font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";letter-spacing:-.15pt;mso-ansi-language:\r\nFR;mso-fareast-language:EN-US;mso-bidi-language:AR-SA\">Enfin, le projet innove\r\ndans ses mécanismes de mitigation des risques. En effet, en plus du monitoring  du \r\nprocessus des réparations communautaires, il sera initié un dialogue\r\ninteractif avec les groupes cibles pour mitiger les risques encourus  durant la mise en œuvre</span><span style=\"font-size:11.0pt;line-height:107%;font-family:\"Calibri\",\"sans-serif\";\r\nmso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:\r\nminor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:Arial;\r\nmso-bidi-theme-font:minor-bidi;mso-ansi-language:FR;mso-fareast-language:EN-US;\r\nmso-bidi-language:AR-SA\"> </span><span style=\"font-size:11.0pt;line-height:\r\n107%;font-family:\"Arial\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";\r\nletter-spacing:-.15pt;mso-ansi-language:FR;mso-fareast-language:EN-US;\r\nmso-bidi-language:AR-SA\">notamment la politisation du processus, la gestion des\r\nattentes etc.  et permettra de prendre\r\nles mesures idoines à chaque étape. Ces mesures seront renforcées par le\r\nplaidoyer politique de UNOWAS et les visites du rapporteur spécial des NU sur la\r\npromotion de la vérité, de la justice, de la réparation et des garanties de\r\nnon-répétition.</span><br></p>', '<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";mso-bidi-font-weight:bold\">Le projet\r\nprend largement en compte les résultats de l’atelier sur la priorisation des\r\nbesoins communautaires en matière de réparation communautaire, organisé par le\r\nMinistère de Solidarité, de la Cohésion Sociale et de la Lutte contre la\r\nPauvreté et appuyé par le PNUD au mois de juin 2018. Cet atelier a validé le\r\nplan de réparation communautaire au niveau national. <o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";mso-bidi-font-weight:bold\">Il prend\r\négalement en compte les consultations initiées avec la Direction des Affaires\r\nCiviles et Pénale du Ministère de la Justice et des droits de l’Homme, la\r\nCellule d’Exécution des réformes du ministère de la Justice et des droits de\r\nl’Homme et la Commission Nationale des droits de l’Homme de Côte d’Ivoire\r\n(CNDHCI) sur les dispositifs d’aide légale et l’appui aux poursuites pénales des\r\nviolences post-électorales. <o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";mso-bidi-font-weight:bold\">Les\r\nOrganisations de la Société Civile nationales et internationales intervenant\r\ndans le domaine de la justice et des droits humains ont été également\r\nconsultées, notamment l’Association des Femmes Juristes de Côte d’Ivoire, la\r\nLigue Ivoirienne des Droits de l’Homme LIDHO, le Mouvement Ivoirien des Droits\r\nde l’Homme MIDH, la Fédération Internationale des Droits de l’Homme,\r\nInternational Center for Transitionnal Justice(ICTJ) ainsi que l’Ordre des\r\navocats de Côte d’Ivoire. <o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";mso-bidi-font-weight:bold\">Par\r\nailleurs, ce projet établit des synergies avec différentes initiatives\r\nexistantes, notamment le Projet du Fonds au profit des victimes de la Cour\r\nPénale Internationale et le programme du Centre International de Justice\r\nTransitionnelle (ICTJ). <o:p></o:p></span></p><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<span style=\"font-size:11.0pt;line-height:107%;font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";mso-ansi-language:FR;mso-fareast-language:\r\nEN-US;mso-bidi-language:AR-SA;mso-bidi-font-weight:bold\">Il intègre aussi les\r\nobservations et ajouts des comités techniques et de pilotage respectivement\r\nd’examen et d’approbation des projets PBF avec la participation de la partie\r\nnationale.</span><br></p>', 40, 'GEN 2', 10, '15', NULL, '<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal;mso-pagination:none\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";layout-grid-mode:line;mso-bidi-font-weight:\r\nbold\">Le cas échéant, le résultat de l’</span><b><span style=\"font-family:\"Arial\",\"sans-serif\";mso-fareast-font-family:\r\n\"Times New Roman\";layout-grid-mode:line\">UNDAF </span></b><span style=\"font-family:\"Arial\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";\r\nlayout-grid-mode:line;mso-bidi-font-weight:bold\">auquel le projet contribue :\r\nEffet I CPU/UNDAF 2017-2020 : « d’ici 2020, les institutions\r\nnationales mettent en œuvre des politiques publiques qui renforcent la\r\ngouvernance et la cohésion sociale pour réduire les inégalités ».<o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\nnormal;mso-pagination:none\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";layout-grid-mode:line;mso-bidi-font-weight:\r\nbold\"><o:p> </o:p></span></p><p>\r\n\r\n\r\n\r\n</p><p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;line-height:normal;mso-pagination:none\"><span style=\"font-family:\"Arial\",\"sans-serif\";\r\nmso-fareast-font-family:\"Times New Roman\";layout-grid-mode:line;mso-bidi-font-weight:\r\nbold\">Le cas échéant, </span><b><span style=\"font-family:\"Arial\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";\r\nlayout-grid-mode:line\">Objectif de Développement Durable</span></b><span style=\"font-family:\"Arial\",\"sans-serif\";mso-fareast-font-family:\"Times New Roman\";\r\nlayout-grid-mode:line;mso-bidi-font-weight:bold\"> auquel le projet contribue : <b>16.</b><o:p></o:p></span></p>', '', '2019-03-28 09:35:07', 6, '2019-05-15 15:40:58', 6, 0),
(11, 3, '00108201', 'Post DDR', 'Post DDR', 'Appui à la consolidation du désarmement communautaire, de la réintégration des ex-combattants et de la RSS en Côte d’Ivoire', '2017-11-01', 'IRF', NULL, '', 0, 1, NULL, NULL, '30,31,42,43,50,51,54,56,65,66', '3', 'Couverture nationale avec des interventions ciblées dans les zones encore sensibles du Centre (Bouaké), du Nord (Korhogo) l’Ouest (Man, Duékoué) et d’Abidjan et celles abritant des centres de secours d’Urgence : Dabou, Bassam, Soubré, Guiglo et Séguéla.', '', '2017-11-01', 36, '21,41,49', '<p><span style=\"font-size: 12pt; font-family: \"Times New Roman\", serif; letter-spacing: -0.15pt;\">La\r\nprésente initiative du PNUD s’inscrit dans le cadre global du Programme d’Appui\r\nà la Consolidation de la Paix (PACoP) de l’équipe Pays des Nations Unies dans\r\nsa composante relative à la consolidation des acquis de la sécurité et dans la\r\ndynamique du retrait définitif de l’ONUCI en Côte d’Ivoire. Le projet vise à\r\nprévenir la violence armée et à renforcer la confiance entre les populations et\r\nles forces de défense et de sécurité, à travers la réintégration\r\nsocioéconomique durable des ex-combattants, le dialogue socio sécuritaire et la\r\npromotion du contrôle démocratique. Sa mise en œuvre permettra le renforcement\r\ndu rôle des institutions nationales en charge du post-DDR, du désarmement\r\ncommunautaire et de la coordination des actions de gouvernance sécuritaire, et\r\nde la participation citoyenne. Cette initiative devra également contribuer de\r\nfaçon catalytique, à la mobilisation des ressources de la contrepartie\r\nnationale et bien d’autres partenaires (UE, BAD, Japon), engagés dans la\r\nproblématique de consolidation des acquis de la sécurité. </span><br></p>', '<p><span style=\"font-size: 12pt; font-family: \"Times New Roman\", serif;\">La\r\nformulation du projet a fait l’objet d’une large consultation avec les\r\ninstitutions nationales en charge des questions de DDR, de la RSS, des ALPC, des\r\nDroits de l’Homme et de la Cohésion sociale, notamment le Secrétariat du\r\nConseil National de Sécurité (S-CNS), la Commission Nationale de Lutte contre\r\nla prolifération et la circulation illicite des armes légères et de petit\r\ncalibre (ComNat-ALPC), la Commission Nationale des Droits de l’Homme (CNDH-CI),\r\nle Ministère de la Solidarité de la Cohésion Sociale et de la Lutte Contre la\r\nPauvreté (MSCSLCP) ainsi que les Organisations de la Société Civile nationale engagées\r\ndans le processus de consolidation de la paix. Toutes ces institutions ont\r\napporté leurs contributions à la définition des deux axes stratégiques, des\r\nrésultats attendus, ainsi que des activités à mener dans le cadre du projet, en\r\nlien avec l’évolution actuelle du contexte socio-sécuritaire de la Côte\r\nd’Ivoire. </span><br></p>', 40, 'La stratégie genre du projet consistera à évaluer l’impact sur les femmes et sur les hommes des activités du projet destinées à répondre à leurs besoins en matière de sécurité et de  Droits Humains. Elle cherchera également à promouvoir l’implication et l', 10, '11', NULL, '<p class=\"MsoHeader\">Le cas\r\néchéant, le résultat de l’<b>UNDAF </b>auquel le projet contribue :<o:p></o:p></p><p>\r\n\r\n<span style=\"font-size: 12pt; font-family: \"Times New Roman\", serif;\">Le\r\ncas échéant, </span><b><span style=\"font-size: 12pt; font-family: \"Times New Roman\", serif;\">Objectif de Développement\r\nDurable</span></b><span style=\"font-size: 12pt; font-family: \"Times New Roman\", serif;\"> auquel le projet contribue </span><br></p>', '', '2019-03-28 09:53:44', 6, '2019-05-15 16:08:59', 6, 0),
(12, 3, '00113453', 'Prévention', 'Prévention des atrocités', 'Soutenir la participation des jeunes dans la prévention de la répétition des atrocités de masse en Côte d\'Ivoire', '2018-12-10', 'IRF', NULL, '', 0, 9, NULL, NULL, '85,121', '2', 'Abidjan (Yopougon et Abobo); San Pedro, Duékoué, Man (Ouest); Bouaké (Centre); et Korhogo (Nord)', '', '2019-01-01', 18, '9,21', '<p><span lang=\"EN-US\" style=\"font-size:12.0pt;font-family:\r\n\"Times New Roman\",\"serif\";mso-fareast-font-family:\"Times New Roman\";mso-ansi-language:\r\nEN-US;mso-fareast-language:EN-US;mso-bidi-language:AR-SA;mso-bidi-font-style:\r\nitalic\">Alors que la Côte d\'Ivoire se prépare pour un autre cycle électoral en\r\n2020, les tensions économiques et sociales persistantes présentent un contexte\r\ndangereux qui, dans le passé, a donné lieu à de graves crise post-électorale.\r\nTout au long de ses travaux, ICTJ a souvent trouvé les jeunes à être des\r\nmoteurs essentiels du changement, avec le plus grand intérêt dans l\'avenir, et\r\navec un vaste potentiel, souvent inexploité pour mettre au défi et fin aux\r\ncycles de violence. Contribuer à la prévention de la violence électorale\r\nrécurrente, ce projet permettra d\'améliorer la participation des jeunes\r\nivoiriens à définir des stratégies pour surmonter l\'héritage des conflits et en\r\ndéveloppant leur capacité d\'entrer dans la conversation nationale sur la\r\ncohésion sociale. Le projet proposé se fonde sur une vaste expérience de l\'ICTJ,\r\nles réseaux et la confiance développée avec les parties prenantes du projet\r\ndepuis 2013.</span><br></p>', '<p class=\"MsoNormal\" style=\"text-align:justify;text-justify:inter-ideograph\"><span lang=\"EN-US\">Les\r\npartenaires d\'exécution de ce projet, RAJP et FDPCI, ont été consultés par ICTJ\r\net activement participé à l\'élaboration de cette proposition. Ces consultations\r\nont porté sur un aperçu des développements politiques et sociaux et\r\nl\'élaboration de propositions pour traiter de façon stratégique les tensions\r\npersistantes du pays. RAJP et FDPCI ont déjà été impliqués dans des activités\r\net des projets mis en œuvre par ICTJ.<o:p></o:p></span></p><p class=\"MsoNormal\" style=\"text-align:justify;text-justify:inter-ideograph\"><span lang=\"EN-US\"> </span></p><p class=\"MsoNormal\" style=\"text-align:justify;text-justify:inter-ideograph\"><span lang=\"EN-US\">ICTJ travaille avec FDPCI depuis plusieurs années sur les questions\r\nde genre et de justice transitionnelle, y compris l\'identification des groupes\r\nde femmes locaux à Bouaké au cours d\'un exercice de cartographie, la conduite\r\ndes programmes de radio et d\'aider ICTJ consultations carry out avec les\r\nreprésentants des groupes de victimes. ICTJ travaille avec RAJP depuis leur\r\ncréation en soutenant 2013. En 2017, RAJP et ICTJ a tenu des consultations avec\r\nles jeunes à Abidjan et dans d\'autres régions qui ont donné une bonne\r\ncompréhension des besoins et des demandes des jeunes. Les consultations a donné\r\nlieu à des rapports qui ont été partagés et discutés avec les institutions\r\npubliques compétentes selon ICTJ méthodologie établie pour développer les\r\ncapacités nationales des OSC et le pont entre les divers groupes et les\r\nautorités officielles. Le projet se basera sur ce travail.</span><span lang=\"EN-US\"><o:p></o:p></span></p><p class=\"MsoNormal\" style=\"text-align:justify;text-justify:inter-ideograph\"><span lang=\"EN-US\"> </span></p><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p><p class=\"MsoNormal\" style=\"text-align:justify;text-justify:inter-ideograph\"><span lang=\"EN-US\">Ainsi\r\nque d\'autres groupes de la société civile, ICTJ a participé en tant qu\'expert\r\ntechnique dans l\'élaboration de la stratégie nationale pour la cohésion sociale\r\navec le Ministère de la solidarité, la cohésion sociale et de lutte contre la\r\npauvreté. Pendant ce temps, nous avons discuté des idées du projet avec le\r\nministère et la société civile, en particulier la nécessité de transformer le\r\nrôle des jeunes dans la cohésion sociale et les initiatives de consolidation de\r\nla paix, ainsi que la nécessité d\'améliorer la perception qu\'ont les gens de la\r\njeunesse.<o:p></o:p></span></p>', 34, 'total du projet affecté aux activités à la poursuite directe de l\'égalité des sexes et l\'autonomisation des femmes: 130340 $ (34%)', 9, '16', NULL, '<p class=\"MsoHeader\"><b><span lang=\"EN-GB\">Objectif de\r\ndéveloppement durable</span></b><span lang=\"EN-GB\"> auquel le projet contribue: ODD 16:\r\nPromouvoir des sociétés justes, pacifiques et inclusives et ODD 5: égalité entre\r\nles sexes. </span><br></p>', '', '2019-03-28 11:27:03', 11, '2019-05-15 15:41:30', 26, 0),
(13, 3, '11', 'MOJEC', 'Projet Mobilisation  jeunes engagés et paix', 'Projet de Mobilisation des Jeunes Engagés pour la Consolidation de la paix en Côte d’Ivoire (MOJEC) ', '2018-09-21', 'IRF', NULL, '', 0, 6, NULL, NULL, '26,35,68,69', '2', 'Région de gbêkê(Bouaké), Région des lagune(Abidjan), région du haut SAssandra(DALOA), région du cavally(Ouest), région du Poro(Korhogo)', 'RAS', '2019-01-05', 18, '21', '<p>Dans un contexte où les prochaines élections sont considérées commeun réel test pour la consolidation de la paix et la stabilité en Côte d\'Ivoire, surtout avec une population grandissantes des jeunes à risque de participation dans les violences politiques, criminelles et terroristes, le projet va contribuer à augmenter la participation civique des jeunes dans le processus démocratique et de consolidation de la paix. Cela sera fait à travers des activités visant l\'augmentation de l\'engagement civique actif des jeunes dans la préparation d\'une transition politique inclusive pacifique à l\'horizon des élections de 2020. Le projet va s\'appuyer sur les acquis et les lecons apprises des initiatives soutenues par l\'UNPBF en Côte d\'Ivoire, notamment l\'initiative \"Appui au processus démocratique et de la consolidation de la paix\" pour établir des relations de collaboration avec les structures précédemment financées  par le UNPBF afin de créer  ou amplifier une dynamique catalytique d\'impulsion de la participation civique des jeunes dans les espaces politiques. Le projet MOJEC contribuera à la réalisation de la priorité 3 du Plan National de Développement(PND) 2016-2020 du gouvernement ivoirien: \"D\'ici 2020, les institutions nationales mettent en oeuvre des politiques publiques qui renforcent la gouvernance et la cohésion sociale pour réduire les inégalité\".</p>', '<p>Le projet MOJEC a été élaboré avec la participation des acteurs locaux avec une programmation sur la thématique, promotion de la paix et participation des jeunes dans les zones cibles.</p><p>Les acteurs locaux clés mobilisés pour la préparation de ce projet comprennent: le RIJLI(Réseau Ivoirien des Jeines Leaders pour l\'Intégrité), l\'AFJCI(Association des Femmes Juristes de Côte d\'Ivoire), l\'ONG CAHD(Conseil pour l\'Assistance Humanitaire et le développement), l\'OSCS(Observatoire de la Solidarité et de la Gestion Sociale).</p><p>Le projet est en ligne  avec l\'axe 2 du PACoP(Programme d\'Appui à la Consolidation de la Paix) des Nations Unies et aux projet \"Election et Jeunes\" mis en oeuvre par le PNUD. L\'élaboration du projet s\'est appuyée sur les discussions avec le Sécrétariat Technique du PBF au niveau local.</p>', 40, '40% du budget soit 439784 Dollars sera dédié à la promotion du GENRE( femme) dans la mise en oeuvre du projet', 9, '16', NULL, '<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; text-align: justify; line-height: normal;\"><span style=\"font-family: Arial, sans-serif;\">Le cas échéant, le résultat de l’</span><b><span style=\"font-family: Arial, sans-serif;\">UNDAF </span></b><span style=\"font-family: Arial, sans-serif;\">auquel le projet contribue : Sur les trois priorités retenues par le CPU en Côte d\'Ivoire, le projet est aligné sur la première qui vise le <<<b>Renforcement de la Gouvernace et de la Cohésion Sociale</b>>><o:p></o:p></span></p><p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: normal;\"><span style=\"font-family: Arial, sans-serif;\"><o:p> </o:p></span></p><p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; text-align: justify; line-height: normal;\"><span style=\"font-family: Arial, sans-serif;\">Le cas échéant, </span><b><span style=\"font-family: Arial, sans-serif;\">Objectif de Développement Durable</span></b><span style=\"font-family: Arial, sans-serif;\"> auquel le projet contribue : ODD n°5: Egalité entre les sexes(5.1, 5.5, 5.6.b), ODD n°10: Réduire les inégalités dans les pays d\'un pays à l\'autre(10.2) et ODD n°16: Paix, justice et institutions efficaces(16.7, 16.10)</span>    </p><p>\r\n\r\n</p><div><!--[if !supportFootnotes]--><br clear=\"all\">\r\n\r\n<br><div id=\"ftn1\">\r\n\r\n</div>\r\n\r\n</div>', '#e6b714', '2019-03-28 12:54:16', 5, '2019-05-15 15:41:29', 5, 0),
(14, 3, '00095624', 'APCSEPPCP', 'Coordination', 'Appui à la planification, la coordination, au suivi et à l’évaluation de la mise en oeuvre du Plan Prioritaire de consolidation de la Paix', '2018-11-29', 'PRF', NULL, '', 0, 8, NULL, NULL, '42', '3', 'Abidjan, Côte d’Ivoire', '', '2015-06-15', 54, '21,41', '<p><span style=\"font-size: 13px;\">Le projet initial est une initiative du Bureau du Coordonnateur Résident (BCR) et du Ministère du Plan visant à renforcer la planification, la coordination et le suivi-évaluation du Plan Prioritaire 2 et du Programme d’Appui à la Consolidation de la Paix (PACOP). La présente révision, initiée par les mêmes entités, tout en s’appuyant sur les leçons apprises de cette première phase, s’inscrit dans le nouveau cadre stratégique tracé par le Programme d’Appui à la Consolidation de la Paix (PACoP) et propose de mettre un accent particulier (i) sur l’informatisation du dispositif de programmation et suivi-évaluation et sur (ii) la mise en route d’un système de suivi basé sur les communautés bénéficiaires des interventions PACoP. La révision étend la durée du projet par une année supplémentaire (jusqu’au 31 décembre 2019).</span><br></p>', '<p><span style=\"font-size: 13px;\">Le processus de consultation s’est articulé autour d’échanges avec le Ministère du Plan afin d’apprécier les défis existants en matière de dispositif de planification et de suivi-évaluation du PACoP (amélioration des outils de programmation intégrée, qualité des données, implication accrue de la partie nationale dans le suivi-évaluation, dispositif de collecte routinière des données sur l’impact des projets financés).</span></p><p><span style=\"font-size: 13px;\">L’idée de révision a été présentée au Comité technique des experts le 13 juin 2018 pour sa revue.</span></p>', 15, '', 9, '21', NULL, '', '#ffe800', '2019-05-14 17:37:49', 1, '2019-05-14 17:53:00', 16, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_projet_budget`
--

DROP TABLE IF EXISTS `t_projet_budget`;
CREATE TABLE IF NOT EXISTS `t_projet_budget` (
  `id_projet_budget` int(11) NOT NULL AUTO_INCREMENT,
  `projet` int(11) DEFAULT NULL,
  `activite_cr` int(11) DEFAULT NULL,
  `agence_concernee` int(11) NOT NULL DEFAULT '0',
  `montant` double DEFAULT NULL,
  `observation` mediumtext,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_projet_budget`)
) ENGINE=InnoDB AUTO_INCREMENT=264 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_projet_budget`
--

INSERT INTO `t_projet_budget` (`id_projet_budget`, `projet`, `activite_cr`, `agence_concernee`, `montant`, `observation`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `etat`) VALUES
(29, 1, 100, 1, 0, NULL, '2019-04-16 10:21:36', 6, NULL, 0, 0),
(30, 1, 100, 5, 0, NULL, '2019-04-16 10:21:36', 6, NULL, 0, 0),
(33, 13, 330, 6, 0, NULL, '2019-04-18 18:00:40', 5, NULL, 0, 0),
(47, 13, 344, 6, 0, NULL, '2019-04-18 18:08:12', 5, NULL, 0, 0),
(48, 13, 345, 6, 0, NULL, '2019-04-18 18:11:13', 5, NULL, 0, 0),
(51, 13, 348, 6, 0, NULL, '2019-04-18 18:13:26', 5, NULL, 0, 0),
(52, 13, 349, 6, 0, NULL, '2019-04-18 18:13:58', 5, NULL, 0, 0),
(53, 13, 350, 6, 0, NULL, '2019-04-18 18:16:28', 5, NULL, 0, 0),
(54, 13, 351, 6, 0, NULL, '2019-04-18 18:16:56', 5, NULL, 0, 0),
(55, 13, 352, 6, 0, NULL, '2019-04-18 18:17:19', 5, NULL, 0, 0),
(56, 13, 353, 6, 0, NULL, '2019-04-18 18:17:46', 5, NULL, 0, 0),
(58, 13, 355, 6, 0, NULL, '2019-04-18 18:19:13', 5, NULL, 0, 0),
(60, 13, 357, 6, 0, NULL, '2019-04-18 18:20:27', 5, NULL, 0, 0),
(61, 13, 358, 6, 0, NULL, '2019-04-18 18:20:53', 5, NULL, 0, 0),
(64, 13, 361, 6, 0, NULL, '2019-04-18 18:22:43', 5, NULL, 0, 0),
(65, 13, 362, 6, 0, NULL, '2019-04-18 18:23:15', 5, NULL, 0, 0),
(66, 13, 331, 6, 22727, NULL, '2019-04-19 10:21:18', 5, NULL, 0, 0),
(67, 13, 332, 6, 18182, NULL, '2019-04-19 10:21:41', 5, NULL, 0, 0),
(68, 13, 333, 6, 54545, NULL, '2019-04-19 10:22:31', 5, NULL, 0, 0),
(69, 13, 334, 6, 41875, NULL, '2019-04-19 10:30:29', 5, NULL, 0, 0),
(70, 13, 335, 6, 45454.55, NULL, '2019-04-19 10:30:57', 5, NULL, 0, 0),
(72, 13, 337, 6, 68181.82, NULL, '2019-04-19 10:31:58', 5, NULL, 0, 0),
(73, 13, 338, 6, 9090.91, NULL, '2019-04-19 10:32:33', 5, NULL, 0, 0),
(74, 13, 339, 6, 4545.45, NULL, '2019-04-19 10:35:22', 5, NULL, 0, 0),
(75, 13, 340, 6, 6363.64, NULL, '2019-04-19 10:36:05', 5, NULL, 0, 0),
(76, 13, 341, 6, 9090.91, NULL, '2019-04-19 10:36:26', 5, NULL, 0, 0),
(77, 13, 342, 6, 6818.18, NULL, '2019-04-19 10:37:11', 5, NULL, 0, 0),
(78, 13, 343, 6, 9090.91, NULL, '2019-04-19 10:37:39', 5, NULL, 0, 0),
(79, 13, 346, 6, 8181.82, NULL, '2019-04-19 10:38:32', 5, NULL, 0, 0),
(80, 13, 347, 6, 9090.91, NULL, '2019-04-19 10:38:50', 5, NULL, 0, 0),
(81, 13, 354, 6, 3636.36, NULL, '2019-04-19 10:43:51', 5, NULL, 0, 0),
(82, 13, 356, 6, 8181.82, NULL, '2019-04-19 10:46:21', 5, NULL, 0, 0),
(83, 13, 359, 6, 27272.73, NULL, '2019-04-19 10:47:10', 5, NULL, 0, 0),
(84, 13, 360, 6, 27272.73, NULL, '2019-04-19 11:20:11', 5, NULL, 0, 0),
(85, 13, 336, 6, 27273, NULL, '2019-04-26 17:56:49', 5, NULL, 0, 0),
(86, 4, 363, 4, 0, NULL, '2019-04-29 11:20:03', 8, NULL, 0, 0),
(87, 4, 363, 1, 0, NULL, '2019-04-29 11:20:03', 8, NULL, 0, 0),
(88, 4, 363, 3, 0, NULL, '2019-04-29 11:20:03', 8, NULL, 0, 0),
(89, 4, 363, 7, 0, NULL, '2019-04-29 11:20:03', 8, NULL, 0, 0),
(90, 6, 26, 6, 0, NULL, '2019-04-29 16:17:01', 5, NULL, 0, 0),
(91, 6, 29, 6, 0, NULL, '2019-04-29 16:17:50', 5, NULL, 0, 0),
(92, 6, 27, 6, 0, NULL, '2019-04-29 16:18:40', 5, NULL, 0, 0),
(93, 6, 30, 6, 0, NULL, '2019-04-29 16:19:05', 5, NULL, 0, 0),
(94, 6, 31, 6, 0, NULL, '2019-04-29 16:19:32', 5, NULL, 0, 0),
(95, 6, 32, 6, 0, NULL, '2019-04-29 16:20:10', 5, NULL, 0, 0),
(108, 4, 67, 4, 0, NULL, '2019-05-03 09:43:24', 8, NULL, 0, 0),
(109, 4, 67, 1, 0, NULL, '2019-05-03 09:43:24', 8, NULL, 0, 0),
(110, 4, 67, 3, 0, NULL, '2019-05-03 09:43:24', 8, NULL, 0, 0),
(111, 4, 67, 7, 60000, NULL, '2019-05-03 09:43:24', 8, NULL, 0, 0),
(113, 1, 118, 1, 0, NULL, '2019-05-07 16:37:40', 25, NULL, 0, 0),
(114, 1, 118, 5, 10000, NULL, '2019-05-07 16:37:40', 25, NULL, 0, 0),
(119, 1, 121, 1, 0, NULL, '2019-05-07 16:39:08', 25, NULL, 0, 0),
(120, 1, 121, 5, 9000, NULL, '2019-05-07 16:39:08', 25, NULL, 0, 0),
(123, 1, 123, 1, 0, NULL, '2019-05-07 16:40:11', 25, NULL, 0, 0),
(124, 1, 123, 5, 9000, NULL, '2019-05-07 16:40:11', 25, NULL, 0, 0),
(125, 1, 120, 1, 0, NULL, '2019-05-07 16:44:38', 25, NULL, 0, 0),
(126, 1, 120, 5, 30000, NULL, '2019-05-07 16:44:38', 25, NULL, 0, 0),
(127, 1, 119, 1, 0, NULL, '2019-05-07 16:47:09', 25, NULL, 0, 0),
(128, 1, 119, 5, 0, NULL, '2019-05-07 16:47:09', 25, NULL, 0, 0),
(129, 1, 122, 1, 0, NULL, '2019-05-07 16:50:32', 25, NULL, 0, 0),
(130, 1, 122, 5, 9000, NULL, '2019-05-07 16:50:32', 25, NULL, 0, 0),
(131, 14, 368, 8, 50000, NULL, '2019-05-15 09:04:40', 16, NULL, 0, 0),
(133, 14, 369, 8, 305000, NULL, '2019-05-15 09:07:16', 16, NULL, 0, 0),
(134, 14, 370, 8, 47612.66, NULL, '2019-05-15 09:08:51', 16, NULL, 0, 0),
(135, 14, 371, 8, 60069, NULL, '2019-05-15 09:10:57', 16, NULL, 0, 0),
(136, 14, 372, 8, 50000, NULL, '2019-05-15 09:12:43', 16, NULL, 0, 0),
(137, 14, 373, 8, 6900, NULL, '2019-05-15 09:14:08', 16, NULL, 0, 0),
(138, 14, 374, 8, 6950, NULL, '2019-05-15 09:17:42', 16, NULL, 0, 0),
(139, 14, 375, 8, 4250, NULL, '2019-05-15 09:18:23', 16, NULL, 0, 0),
(140, 14, 376, 8, 30000, NULL, '2019-05-15 09:19:04', 16, NULL, 0, 0),
(153, 11, 218, 1, 20561, NULL, '2019-05-15 17:05:02', 6, NULL, 0, 0),
(154, 11, 219, 1, 26168.22, NULL, '2019-05-15 17:08:14', 6, NULL, 0, 0),
(157, 11, 220, 1, 18691.59, NULL, '2019-05-15 17:10:02', 6, NULL, 0, 0),
(162, 11, 221, 1, 14018.69, NULL, '2019-05-15 17:11:38', 6, NULL, 0, 0),
(163, 9, 250, 7, 30000, NULL, '2019-05-15 17:12:11', 7, NULL, 0, 0),
(164, 9, 250, 1, 0, NULL, '2019-05-15 17:12:11', 7, NULL, 0, 0),
(167, 11, 222, 1, 14018.69, NULL, '2019-05-15 17:13:13', 6, NULL, 0, 0),
(168, 2, 86, 1, 0, NULL, '2019-05-15 17:13:28', 19, NULL, 0, 0),
(169, 2, 86, 2, 9000, NULL, '2019-05-15 17:13:28', 19, NULL, 0, 0),
(170, 9, 251, 7, 40000, NULL, '2019-05-15 17:14:25', 7, NULL, 0, 0),
(171, 9, 251, 1, 0, NULL, '2019-05-15 17:14:25', 7, NULL, 0, 0),
(174, 11, 223, 1, 37383.18, NULL, '2019-05-15 17:14:55', 6, NULL, 0, 0),
(175, 9, 252, 7, 20000, NULL, '2019-05-15 17:15:44', 7, NULL, 0, 0),
(176, 9, 252, 1, 0, NULL, '2019-05-15 17:15:44', 7, NULL, 0, 0),
(177, 11, 224, 1, 100186.92, NULL, '2019-05-15 17:16:00', 6, NULL, 0, 0),
(178, 9, 253, 7, 50000, NULL, '2019-05-15 17:16:45', 7, NULL, 0, 0),
(179, 9, 253, 1, 0, NULL, '2019-05-15 17:16:45', 7, NULL, 0, 0),
(180, 11, 225, 1, 136121.5, NULL, '2019-05-15 17:16:53', 6, NULL, 0, 0),
(181, 11, 226, 1, 9345.79, NULL, '2019-05-15 17:17:46', 6, NULL, 0, 0),
(182, 2, 88, 1, 0, NULL, '2019-05-15 17:17:58', 19, NULL, 0, 0),
(183, 2, 88, 2, 19000, NULL, '2019-05-15 17:17:58', 19, NULL, 0, 0),
(184, 9, 254, 7, 60000, NULL, '2019-05-15 17:18:33', 7, NULL, 0, 0),
(185, 9, 254, 1, 0, NULL, '2019-05-15 17:18:33', 7, NULL, 0, 0),
(186, 11, 227, 1, 18691.59, NULL, '2019-05-15 17:19:05', 6, NULL, 0, 0),
(189, 2, 89, 1, 0, NULL, '2019-05-15 17:19:06', 19, NULL, 0, 0),
(190, 2, 89, 2, 4500, NULL, '2019-05-15 17:19:06', 19, NULL, 0, 0),
(191, 2, 90, 1, 0, NULL, '2019-05-15 17:19:49', 19, NULL, 0, 0),
(192, 2, 90, 2, 8300, NULL, '2019-05-15 17:19:49', 19, NULL, 0, 0),
(193, 9, 255, 7, 79000, NULL, '2019-05-15 17:20:33', 7, NULL, 0, 0),
(194, 9, 255, 1, 0, NULL, '2019-05-15 17:20:33', 7, NULL, 0, 0),
(195, 10, 145, 1, 30000, NULL, '2019-05-15 17:21:54', 6, NULL, 0, 0),
(196, 10, 145, 10, 0, NULL, '2019-05-15 17:21:54', 6, NULL, 0, 0),
(197, 11, 228, 1, 46728.97, NULL, '2019-05-15 17:22:14', 6, NULL, 0, 0),
(198, 10, 146, 1, 15000, NULL, '2019-05-15 17:22:24', 6, NULL, 0, 0),
(199, 10, 146, 10, 0, NULL, '2019-05-15 17:22:24', 6, NULL, 0, 0),
(200, 10, 147, 1, 640330, NULL, '2019-05-15 17:23:11', 6, NULL, 0, 0),
(201, 10, 147, 10, 0, NULL, '2019-05-15 17:23:11', 6, NULL, 0, 0),
(202, 9, 256, 7, 95000, NULL, '2019-05-15 17:23:14', 7, NULL, 0, 0),
(203, 9, 256, 1, 0, NULL, '2019-05-15 17:23:14', 7, NULL, 0, 0),
(204, 9, 257, 7, 45000, NULL, '2019-05-15 17:23:43', 7, NULL, 0, 0),
(205, 9, 257, 1, 0, NULL, '2019-05-15 17:23:43', 7, NULL, 0, 0),
(206, 2, 94, 1, 0, NULL, '2019-05-15 17:23:44', 19, NULL, 0, 0),
(207, 2, 94, 2, 37500, NULL, '2019-05-15 17:23:44', 19, NULL, 0, 0),
(208, 10, 148, 1, 40000, NULL, '2019-05-15 17:24:36', 6, NULL, 0, 0),
(209, 10, 148, 10, 0, NULL, '2019-05-15 17:24:36', 6, NULL, 0, 0),
(210, 2, 95, 1, 0, NULL, '2019-05-15 17:25:03', 19, NULL, 0, 0),
(211, 2, 95, 2, 272603, NULL, '2019-05-15 17:25:03', 19, NULL, 0, 0),
(212, 10, 149, 1, 40000, NULL, '2019-05-15 17:25:09', 6, NULL, 0, 0),
(213, 10, 149, 10, 0, NULL, '2019-05-15 17:25:09', 6, NULL, 0, 0),
(214, 11, 229, 1, 934579, NULL, '2019-05-15 17:25:48', 6, NULL, 0, 0),
(215, 10, 150, 1, 5000, NULL, '2019-05-15 17:26:02', 6, NULL, 0, 0),
(216, 10, 150, 10, 0, NULL, '2019-05-15 17:26:02', 6, NULL, 0, 0),
(217, 10, 151, 1, 20000, NULL, '2019-05-15 17:26:46', 6, NULL, 0, 0),
(218, 10, 151, 10, 0, NULL, '2019-05-15 17:26:46', 6, NULL, 0, 0),
(219, 9, 258, 7, 0, NULL, '2019-05-15 17:27:29', 7, NULL, 0, 0),
(220, 9, 258, 1, 34500, NULL, '2019-05-15 17:27:29', 7, NULL, 0, 0),
(221, 10, 152, 1, 30000, NULL, '2019-05-15 17:27:29', 6, NULL, 0, 0),
(222, 10, 152, 10, 0, NULL, '2019-05-15 17:27:29', 6, NULL, 0, 0),
(223, 11, 230, 1, 18691.59, NULL, '2019-05-15 17:27:33', 6, NULL, 0, 0),
(224, 10, 153, 1, 30000, NULL, '2019-05-15 17:28:09', 6, NULL, 0, 0),
(225, 10, 153, 10, 0, NULL, '2019-05-15 17:28:09', 6, NULL, 0, 0),
(226, 11, 231, 1, 28037.38, NULL, '2019-05-15 17:29:01', 6, NULL, 0, 0),
(227, 9, 259, 7, 0, NULL, '2019-05-15 17:29:53', 7, NULL, 0, 0),
(228, 9, 259, 1, 45000, NULL, '2019-05-15 17:29:53', 7, NULL, 0, 0),
(229, 2, 43, 1, 0, NULL, '2019-05-15 17:30:12', 19, NULL, 0, 0),
(230, 2, 43, 2, 193050, NULL, '2019-05-15 17:30:12', 19, NULL, 0, 0),
(233, 2, 44, 1, 0, NULL, '2019-05-15 17:30:31', 19, NULL, 0, 0),
(234, 2, 44, 2, 13500, NULL, '2019-05-15 17:30:31', 19, NULL, 0, 0),
(235, 12, 278, 9, 14000, NULL, '2019-05-15 17:30:41', 26, NULL, 0, 0),
(236, 2, 46, 1, 0, NULL, '2019-05-15 17:31:02', 19, NULL, 0, 0),
(237, 2, 46, 2, 38000, NULL, '2019-05-15 17:31:02', 19, NULL, 0, 0),
(238, 9, 260, 7, 50000, NULL, '2019-05-15 17:31:21', 7, NULL, 0, 0),
(239, 9, 260, 1, 0, NULL, '2019-05-15 17:31:21', 7, NULL, 0, 0),
(240, 2, 47, 1, 0, NULL, '2019-05-15 17:31:32', 19, NULL, 0, 0),
(241, 2, 47, 2, 86000, NULL, '2019-05-15 17:31:32', 19, NULL, 0, 0),
(242, 2, 45, 1, 0, NULL, '2019-05-15 17:31:51', 19, NULL, 0, 0),
(243, 2, 45, 2, 0, NULL, '2019-05-15 17:31:51', 19, NULL, 0, 0),
(244, 9, 261, 7, 30000, NULL, '2019-05-15 17:32:31', 7, NULL, 0, 0),
(245, 9, 261, 1, 0, NULL, '2019-05-15 17:32:31', 7, NULL, 0, 0),
(246, 9, 262, 7, 26000, NULL, '2019-05-15 17:33:13', 7, NULL, 0, 0),
(247, 9, 262, 1, 0, NULL, '2019-05-15 17:33:13', 7, NULL, 0, 0),
(248, 9, 263, 7, 45000, NULL, '2019-05-15 17:33:49', 7, NULL, 0, 0),
(249, 9, 263, 1, 0, NULL, '2019-05-15 17:33:49', 7, NULL, 0, 0),
(250, 9, 264, 7, 50000, NULL, '2019-05-15 17:34:26', 7, NULL, 0, 0),
(251, 9, 264, 1, 0, NULL, '2019-05-15 17:34:26', 7, NULL, 0, 0),
(252, 2, 84, 1, 0, NULL, '2019-05-15 17:35:19', 19, NULL, 0, 0),
(253, 2, 84, 2, 7000, NULL, '2019-05-15 17:35:19', 19, NULL, 0, 0),
(254, 2, 85, 1, 0, NULL, '2019-05-15 17:35:41', 19, NULL, 0, 0),
(255, 2, 85, 2, 18000, NULL, '2019-05-15 17:35:41', 19, NULL, 0, 0),
(256, 9, 265, 7, 20000, NULL, '2019-05-15 17:35:47', 7, NULL, 0, 0),
(257, 9, 265, 1, 0, NULL, '2019-05-15 17:35:47', 7, NULL, 0, 0),
(259, 9, 266, 7, 50000, NULL, '2019-05-15 17:36:32', 7, NULL, 0, 0),
(260, 9, 266, 1, 0, NULL, '2019-05-15 17:36:32', 7, NULL, 0, 0),
(261, 12, 279, 9, 11300, NULL, '2019-05-15 17:37:18', 26, NULL, 0, 0),
(262, 9, 267, 7, 65000, NULL, '2019-05-15 17:38:41', 7, NULL, 0, 0),
(263, 9, 267, 1, 0, NULL, '2019-05-15 17:38:41', 7, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_projet_budget_01`
--

DROP TABLE IF EXISTS `t_projet_budget_01`;
CREATE TABLE IF NOT EXISTS `t_projet_budget_01` (
  `id_projet_budget` int(11) DEFAULT NULL,
  `projet` int(11) DEFAULT NULL,
  `bailleur` int(11) DEFAULT NULL,
  `montant` double DEFAULT NULL,
  `observation` mediumtext,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `t_projet_users`
--

DROP TABLE IF EXISTS `t_projet_users`;
CREATE TABLE IF NOT EXISTS `t_projet_users` (
  `id_projet_user` int(11) NOT NULL AUTO_INCREMENT,
  `structure_up` int(11) NOT NULL,
  `projet_up` int(11) NOT NULL,
  `personnel_up` text NOT NULL,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_projet_user`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_projet_users`
--

INSERT INTO `t_projet_users` (`id_projet_user`, `structure_up`, `projet_up`, `personnel_up`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `etat`) VALUES
(6, 1, 2, '6', '2019-02-13 17:51:01', 6, NULL, 0, 0),
(7, 8, 1, '1,2', '2019-03-07 17:38:23', 1, NULL, 0, 0),
(17, 2, 7, '3,17', '2019-03-14 11:37:41', 3, NULL, 0, 0),
(19, 1, 1, '6', '2019-03-14 11:58:05', 6, NULL, 0, 0),
(24, 2, 2, '3,17,19', '2019-03-14 16:09:19', 3, NULL, 0, 0),
(26, 7, 4, '7', '2019-03-20 19:20:37', 7, NULL, 0, 0),
(28, 1, 8, '6', '2019-03-21 11:48:46', 6, NULL, 0, 0),
(29, 7, 9, '7', '2019-03-21 18:06:43', 7, NULL, 0, 0),
(30, 1, 4, '6', '2019-03-22 06:31:14', 6, NULL, 0, 0),
(31, 4, 5, '8', '2019-03-28 09:16:14', 8, NULL, 0, 0),
(32, 1, 10, '6', '2019-03-28 09:37:27', 6, NULL, 0, 0),
(33, 1, 9, '6', '2019-03-28 09:37:37', 6, NULL, 0, 0),
(36, 6, 13, '5', '2019-03-28 12:54:26', 5, NULL, 0, 0),
(37, 2, 8, '3', '2019-04-30 10:40:42', 3, NULL, 0, 0),
(45, 3, 4, '9', '2019-05-06 16:52:42', 9, NULL, 0, 0),
(46, 9, 12, '11,26', '2019-05-14 14:13:18', 11, NULL, 0, 0),
(53, 8, 14, '1,2,16,20,21,22,23', '2019-05-14 17:41:44', 16, NULL, 0, 0),
(57, 4, 4, '8,12,14,15,24', '2019-05-15 15:41:21', 8, NULL, 0, 0),
(58, 5, 1, '4,25,27,33,36', '2019-05-15 15:44:47', 36, NULL, 0, 0),
(60, 5, 5, '4,25,27,33,36', '2019-05-15 15:45:40', 36, NULL, 0, 0),
(62, 6, 6, '5,13,29,32', '2019-05-15 16:13:00', 5, NULL, 0, 0),
(63, 1, 11, '6', '2019-05-15 16:13:18', 6, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_rapport`
--

DROP TABLE IF EXISTS `t_rapport`;
CREATE TABLE IF NOT EXISTS `t_rapport` (
  `Code_Rapport` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Rapport` varchar(2500) DEFAULT NULL,
  `Code_Feuille` bigint(20) DEFAULT NULL,
  `Group_By` varchar(255) DEFAULT NULL,
  `Colonne_X` varchar(255) DEFAULT NULL,
  `Colonne_Y` varchar(255) DEFAULT NULL,
  `Valeur` varchar(255) DEFAULT NULL,
  `Feuille_Jointure` int(11) DEFAULT NULL,
  `Attribut_Jointure_FP` varchar(255) DEFAULT NULL,
  `Attribut_Jointure_FS` varchar(255) DEFAULT NULL,
  `Operation` varchar(255) DEFAULT NULL,
  `Nom_View` varchar(2500) DEFAULT NULL,
  `Type_Rapport` enum('SIMPLE','CROISE') DEFAULT NULL,
  `Structure_View` text,
  `Id_Projet` int(11) DEFAULT NULL,
  `Date_Insertion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Code_Rapport`),
  KEY `id_feuille` (`Code_Feuille`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déclencheurs `t_rapport`
--
DROP TRIGGER IF EXISTS `TRG_BEFORE_DELETE_RAPPORT`;
DELIMITER $$
CREATE TRIGGER `TRG_BEFORE_DELETE_RAPPORT` BEFORE DELETE ON `t_rapport` FOR EACH ROW BEGIN

DELETE FROM t_rapport_critere WHERE (t_rapport_critere.Code_Rapport =  OLD.Code_Rapport);

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `t_rapport_article`
--

DROP TABLE IF EXISTS `t_rapport_article`;
CREATE TABLE IF NOT EXISTS `t_rapport_article` (
  `Code_Article` int(11) NOT NULL AUTO_INCREMENT,
  `Code_Rapport` int(11) NOT NULL,
  `Titre_Article` varchar(2500) DEFAULT NULL,
  `Description_Article` text,
  `Photo` varchar(2500) DEFAULT NULL,
  `Statut` enum('Actif','Inactif') DEFAULT 'Actif',
  `Validation` enum('Oui','Non') DEFAULT 'Non',
  `Login` varchar(255) NOT NULL,
  `Vue` int(11) NOT NULL DEFAULT '0',
  `Date_Insertion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Code_Article`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déclencheurs `t_rapport_article`
--
DROP TRIGGER IF EXISTS `TRG_BEFORE_DELETE_ARTICLE`;
DELIMITER $$
CREATE TRIGGER `TRG_BEFORE_DELETE_ARTICLE` BEFORE DELETE ON `t_rapport_article` FOR EACH ROW BEGIN

DELETE FROM t_rapport_commentaire WHERE t_rapport_commentaire.Code_Article=OLD.Code_Article;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `t_rapport_commentaire`
--

DROP TABLE IF EXISTS `t_rapport_commentaire`;
CREATE TABLE IF NOT EXISTS `t_rapport_commentaire` (
  `Code_Commentaire` bigint(20) NOT NULL AUTO_INCREMENT,
  `Code_Article` int(11) DEFAULT NULL,
  `Commentaire` varchar(2500) DEFAULT NULL,
  `Photo` varchar(2500) DEFAULT NULL,
  `Date_Insertion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Code_Commentaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `t_rapport_critere`
--

DROP TABLE IF EXISTS `t_rapport_critere`;
CREATE TABLE IF NOT EXISTS `t_rapport_critere` (
  `Code_Rapport_Critere` bigint(20) NOT NULL AUTO_INCREMENT,
  `Code_Rapport` int(11) NOT NULL,
  `Critere_Colonne` varchar(255) DEFAULT NULL,
  `Critere_Condition` varchar(255) DEFAULT NULL,
  `Critere_Valeur` varchar(255) DEFAULT NULL,
  `Critere_ET_OU` enum('ET','OU') DEFAULT NULL,
  PRIMARY KEY (`Code_Rapport_Critere`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `t_rapport_indicateur`
--

DROP TABLE IF EXISTS `t_rapport_indicateur`;
CREATE TABLE IF NOT EXISTS `t_rapport_indicateur` (
  `Code_Rapport` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Rapport` varchar(2500) DEFAULT NULL,
  `Code_Feuille` bigint(20) DEFAULT NULL,
  `Group_By` varchar(255) DEFAULT NULL,
  `Valeur` varchar(255) DEFAULT NULL,
  `Feuille_Jointure` int(11) DEFAULT NULL,
  `Attribut_Jointure_FP` varchar(255) DEFAULT NULL,
  `Attribut_Jointure_FS` varchar(255) DEFAULT NULL,
  `Operation` varchar(255) DEFAULT NULL,
  `Nom_View` varchar(2500) DEFAULT NULL,
  `Structure_View` text,
  `Date_Insertion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Id_Projet` int(11) NOT NULL,
  `Affichage` enum('Membre du projet','UN','Tous') DEFAULT NULL,
  `Indicateur` int(11) DEFAULT NULL,
  PRIMARY KEY (`Code_Rapport`),
  KEY `id_feuille` (`Code_Feuille`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déclencheurs `t_rapport_indicateur`
--
DROP TRIGGER IF EXISTS `TRG_BEFORE_DELETE_INDICATEUR`;
DELIMITER $$
CREATE TRIGGER `TRG_BEFORE_DELETE_INDICATEUR` BEFORE DELETE ON `t_rapport_indicateur` FOR EACH ROW BEGIN

DELETE FROM t_rapport_article WHERE t_rapport_article.Code_Rapport=OLD.Code_Rapport;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `t_type_partenaire`
--

DROP TABLE IF EXISTS `t_type_partenaire`;
CREATE TABLE IF NOT EXISTS `t_type_partenaire` (
  `id_type_partenaire` int(25) NOT NULL AUTO_INCREMENT,
  `nom_type_partenaire` text NOT NULL,
  `description` text,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `etat` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_type_partenaire`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_type_partenaire`
--

INSERT INTO `t_type_partenaire` (`id_type_partenaire`, `nom_type_partenaire`, `description`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `etat`) VALUES
(1, 'Agences récipiendaires', 'Agences récipiendaires des fonds du PBF (Structures)', '2019-03-07 08:13:10', 1, NULL, 0, 0),
(2, 'Partenaires Étatiques', 'Partenaires gouvernementaux (Structures de l\'Etat)', '2019-03-07 08:13:10', 1, NULL, 1, 0),
(3, 'ONG/ Société Civile', 'Société civile (ONG , OSC,...)', '2019-03-07 08:13:10', 1, NULL, 1, 0),
(4, 'Bailleurs', 'Partenaires financiers (Bailleurs)', '2019-03-07 08:13:10', 1, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_users`
--

DROP TABLE IF EXISTS `t_users`;
CREATE TABLE IF NOT EXISTS `t_users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `titre` varchar(30) DEFAULT NULL,
  `pass` text NOT NULL,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fonction` int(11) NOT NULL,
  `niveau` int(11) NOT NULL DEFAULT '5',
  `projet_active` int(11) NOT NULL,
  `partenaire_concerne` int(11) NOT NULL DEFAULT '1',
  `structure_concerne` int(11) NOT NULL,
  `programme_active` int(11) DEFAULT NULL,
  `description_fonction` text,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `statut` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_users`
--

INSERT INTO `t_users` (`id_user`, `login`, `titre`, `pass`, `nom`, `prenom`, `contact`, `email`, `fonction`, `niveau`, `projet_active`, `partenaire_concerne`, `structure_concerne`, `programme_active`, `description_fonction`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `statut`) VALUES
(1, 'admin', 'M', '21232f297a57a5a743894a0e4a801fc3', 'KONAN', 'Fabrice ', '0', 'kone.lacine@gmail.com', 1, 0, 1, 0, 8, 3, NULL, '2019-02-12 14:14:42', 1, '2019-03-14 09:50:04', 1, 0),
(2, 'diesel', 'M', 'b26cf79c8201d1bf99f4bbedfd8579f9', 'Sangaré', 'Fousseyni', '66791871', 'fousseyni.sangare@gmail.com', 1, 1, 0, 5, 0, 3, NULL, '2019-02-12 14:14:42', 1, NULL, 0, 0),
(3, 'bertelle', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'BERTELLE', 'Marianna ', 'A définir', 'mbertelle@oim.int', 2, 1, 2, 0, 2, 3, NULL, '2019-02-13 14:52:02', 1, '2019-03-14 15:48:59', 1, 0),
(4, 'madeleine', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Kouakou  ', 'Adjoua Madeleine', 'A définir', 'u07@gmail.com', 10, 1, 5, 0, 5, 3, NULL, '2019-02-13 15:17:41', 1, '2019-03-11 10:49:59', 1, 0),
(5, 'losseni', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Coulibaly', 'Losseni', 'A définir', 'Losseni.coulibaly@care.org', 11, 1, 13, 0, 6, 3, NULL, '2019-02-13 15:25:05', 1, '2019-04-16 09:53:52', 1, 0),
(6, 'arsene ', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Assande', 'Arsène ', 'A définir', 'arsene.assande@undp.org', 6, 1, 11, 0, 1, 3, NULL, '2019-02-13 15:26:13', 1, NULL, NULL, 0),
(7, 'marietou', 'Mlle', '81dc9bdb52d04dc20036dbd8313ed055', 'Coulibaly', 'Marietou ', '08823412', 'macoulibaly@unfpa.org', 12, 1, 9, 0, 7, 3, NULL, '2019-02-13 15:27:10', 1, '2019-05-15 15:10:53', 1, 0),
(8, 'nathalie', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'Daries', 'Nathalie', '56433494', 'ndaries@unicef.org', 9, 1, 4, 0, 4, 3, NULL, '2019-02-13 15:27:55', 1, NULL, NULL, 0),
(9, 'kamara', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'KAMARA', 'K', 'A définir', 'u07@gmail.com', 8, 1, 4, 0, 3, 3, NULL, '2019-02-13 15:29:04', 1, '2019-03-11 10:50:15', 1, 0),
(10, 'lydia', 'Mlle', '81dc9bdb52d04dc20036dbd8313ed055', 'Ntumba', 'Kassa Lydia', 'A définir', '07@gmail.com', 13, 1, 0, 0, 10, 3, NULL, '2019-02-13 15:39:02', 1, '2019-03-11 10:50:32', 1, 0),
(11, 'gbery', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Gbery', 'G', 'A définir', 'u07@gmail.com', 14, 1, 12, 0, 9, 3, NULL, '2019-02-13 15:40:47', 1, '2019-05-14 14:12:32', 1, 0),
(12, 'nathalie-assist', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Assistant', 'nathalie', 'A définir', 'desirebrou07@gmail.com', 15, 3, 4, 1, 4, 3, NULL, '2019-03-11 14:26:15', 8, '2019-03-11 14:29:16', 8, 0),
(13, 'losseni-assist', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Assistant', 'Losseni', 'A définir', 'desirebrou07@gmail.com', 16, 3, 6, 1, 6, 3, NULL, '2019-03-11 15:52:50', 5, '2019-03-11 15:54:01', 5, 0),
(14, 'bomisso', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Bomisso', 'Germain', '04945121', 'gbomisso@unicef.org', 39, 3, 0, 1, 4, NULL, NULL, '2019-03-12 14:29:14', 8, '2019-05-15 15:06:54', 8, 0),
(15, 'Rodolphe', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Tian Bi', 'Rodolphe', '56528589', 'rtianbi@unicef.org', 15, 3, 0, 1, 4, NULL, NULL, '2019-03-12 16:17:23', 8, NULL, 0, 0),
(16, 'fabrice', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'KONAN', 'Fabrice', '68309050', 'fabrice.konan@one.un.org', 21, 1, 14, 1, 8, 3, NULL, '2019-03-14 10:37:09', 1, '2019-03-19 16:21:19', 1, 0),
(17, 'assist-bertelle', 'Pr', 'bee18aac38b34a45b54533a517a8b93e', 'vouo', 'Emmanuel', '57015305', 'manuvouho001@gmail.com', 2, 4, 0, 1, 2, 3, NULL, '2019-03-14 10:52:27', 3, '2019-05-15 15:02:21', 19, 0),
(19, 'paulette', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'Hadassa', 'Paulette', '656816', 'paulettehadassa@gmail.com', 19, 1, 2, 1, 2, 3, NULL, '2019-03-14 15:44:30', 3, '2019-04-30 11:12:27', 3, 0),
(20, 'tano', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'TANO', 'N\'GROUMA', '20200804', 'ngrouma@yahoo.fr', 23, 1, 0, 1, 8, NULL, NULL, '2019-03-19 16:32:31', 1, NULL, 0, 0),
(21, 'raluca', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'EDDON', 'Raluca', '79415155', 'raluca.eddon@one.un.org', 22, 1, 0, 1, 8, NULL, NULL, '2019-03-19 16:35:06', 1, NULL, 0, 0),
(22, 'mp', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'DJEDJE', 'Marie-Pascale', '05098153', 'pascalore2y@yahoo.fr', 24, 1, 0, 1, 8, NULL, NULL, '2019-03-19 16:37:24', 1, '2019-03-19 16:38:08', 1, 0),
(23, 'sanaba', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'DIAKITE COULIBALY', 'Sanaba', '20 31 74 31/ 07 62 81 07 ', 'sanaba.coulibaly-diakite@one.un.org', 25, 1, 0, 1, 8, NULL, NULL, '2019-03-19 16:41:31', 1, NULL, 0, 0),
(24, 'Delphine', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'Brou', 'Delphine', '76990050', 'dbrou@unicef.org', 15, 3, 0, 1, 4, NULL, NULL, '2019-05-03 10:16:36', 8, NULL, 0, 0),
(25, 'sylvie', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'GOUGOUA', 'Sylvie ', '09851459', 'sylvie.gougoua@unwomen.org', 10, 1, 1, 1, 5, 3, NULL, '2019-05-03 12:53:13', 1, NULL, 0, 0),
(26, 'bamba', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Bamba ', 'Brahima', '07449871', 'bbamba@ictj.org', 14, 1, 12, 1, 9, 3, NULL, '2019-05-03 14:48:58', 11, NULL, 0, 0),
(27, 'ngbaramou', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'NGBARAMOU', 'Jean-Jacques', '+225 09851459', 'j.ngbaramou@unwomen.org', 10, 1, 1, 1, 5, NULL, NULL, '2019-05-06 11:40:01', 25, NULL, 0, 0),
(29, 'leonardtaki', 'M', 'c4de8ced6214345614d33fb0b16a8acd', 'TAKI', 'Kan Leonard', '+22559710362', 'leonard.taki@care.org', 32, 3, 0, 1, 6, NULL, NULL, '2019-05-14 10:49:45', 5, '2019-05-14 10:59:22', 5, 0),
(30, 'peyogori', 'M', '87cb9079bea370fc3f72e816bc1760ae', 'Ouattara', 'Peyogori', '08003432', 'peyogori.ouattara@undp.org', 36, 3, 0, 1, 1, 3, NULL, '2019-05-15 14:55:56', 6, '2019-05-15 15:08:34', 6, 0),
(31, 'adrien', 'M', '7ea07aa68ebecf139c795c8e66183236', 'Kouassi', 'Adrien', '+22569324635', 'adrien.kouassi@undp.org', 6, 3, 0, 1, 1, NULL, NULL, '2019-05-15 14:56:32', 6, NULL, 0, 0),
(32, 'guillaume', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'AGUETTANT', 'Guillaume', '+225 78 73 13 81', 'Guillaume.Aguettant@care.org', 33, 4, 0, 1, 6, NULL, NULL, '2019-05-15 14:59:08', 5, NULL, 0, 0),
(33, 'daouda', 'M', '4a7d1ed414474e4033ac29ccb8653d9b', 'kone', 'daouda', '08453282', 'ziedaouda.kone@yahoo.fr', 30, 3, 1, 1, 5, 3, NULL, '2019-05-15 14:59:36', 25, '2019-05-15 17:19:37', 25, 0),
(34, 'paulinekouye', 'Mme', 'e10adc3949ba59abbe56e057f20f883e', 'Kouye', 'Pauline Moegbeu', '08088047', 'kouye@unfpa.org', 34, 3, 0, 1, 7, NULL, NULL, '2019-05-15 15:04:10', 7, NULL, 0, 0),
(35, 'mariepascale', 'Mme', '3a9271dd5829bcd200bdaba12b0eb172', 'DJEDJE ', 'Marie pascale', '05098153', 'pascalore2y@yahoo.fr', 18, 3, 0, 1, 8, NULL, NULL, '2019-05-15 15:08:57', 16, NULL, 0, 0),
(36, 'Kassoum', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'OUATTARA', 'Kassoum', '08342497', 'sylvie.gougoua@unwomen.org', 30, 1, 1, 1, 5, 3, NULL, '2019-05-15 15:33:55', 25, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_users_access`
--

DROP TABLE IF EXISTS `t_users_access`;
CREATE TABLE IF NOT EXISTS `t_users_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `page_edit` text NOT NULL,
  `page_verif` text NOT NULL,
  `page_valid` text NOT NULL,
  `page_interd` text NOT NULL,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_users_access`
--

INSERT INTO `t_users_access` (`id`, `id_user`, `page_edit`, `page_verif`, `page_valid`, `page_interd`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`) VALUES
(3, 6, '', '', '', '', '2019-03-11 10:48:08', 1, NULL, 0),
(4, 12, '', '', '', 'localites.php|users.php|partenaires.php|partenaires_details.php|projets.php|categorie_depense.php|plan_analytique_projet.php|autres_parametres.php|', '2019-03-11 14:27:54', 8, '2019-03-11 00:00:00', 8),
(6, 20, 'localites.php|users.php|programmes.php|partenaires.php|partenaires_details.php|projets.php|projet_details.php|categorie_depense.php|autres_parametres.php|niveau_cs.php|indicateur_cs.php|niveau_cr.php|indicateur_cr.php|liste_convention.php|plan_ptba.php|type_activites.php|fiches_dynamiques.php|classeur_details.php|disposition_mobile_formulaire.php|rapports_dynamiques.php|rapports_dynamiques_simple_creation.php|rapports_dynamiques_simple_modification.php|rapport_details_simple.php|rapports_dynamiques_croise_creation.php|rapports_dynamiques_croise_modification.php|rapport_details_croise.php|', '', '', '', '2019-03-19 16:32:56', 1, NULL, 0),
(7, 23, 'localites.php|users.php|programmes.php|partenaires.php|partenaires_details.php|projets.php|projet_details.php|autres_parametres.php|indicateur_cs.php|niveau_cr.php|indicateur_cr.php|liste_convention.php|type_activites.php|fiches_dynamiques.php|classeur_details.php|disposition_mobile_formulaire.php|rapports_dynamiques.php|rapports_dynamiques_simple_creation.php|rapports_dynamiques_simple_modification.php|rapport_details_simple.php|rapports_dynamiques_croise_creation.php|rapports_dynamiques_croise_modification.php|rapport_details_croise.php|', '', '', '', '2019-03-19 16:41:43', 1, '2019-03-19 00:00:00', 1),
(8, 13, 'localites.php|users.php|programmes.php|partenaires.php|partenaires_details.php|projets.php|projet_details.php|categorie_depense.php|autres_parametres.php|niveau_cs.php|indicateur_cs.php|niveau_cr.php|indicateur_cr.php|liste_convention.php|plan_ptba.php|type_activites.php|fiches_dynamiques.php|classeur_details.php|disposition_mobile_formulaire.php|suivi_indicateur_cr.php|suivi_referentiel.php|suivi_plan_ptba.php|', '', '', '', '2019-03-28 12:59:34', 5, NULL, 0),
(9, 34, '', '', '', '', '2019-05-15 15:04:23', 7, NULL, 0),
(10, 35, '', '', '', '', '2019-05-15 15:09:47', 16, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_users_convention`
--

DROP TABLE IF EXISTS `t_users_convention`;
CREATE TABLE IF NOT EXISTS `t_users_convention` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `titre` varchar(30) DEFAULT NULL,
  `pass` text NOT NULL,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `convention` int(11) NOT NULL,
  `niveau` int(11) NOT NULL DEFAULT '5',
  `projet_active` int(11) NOT NULL,
  `date_enregistrement` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enregistrer_par` int(11) NOT NULL DEFAULT '0',
  `date_modification` datetime DEFAULT NULL,
  `modifier_par` int(11) DEFAULT '0',
  `statut` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `t_users_convention`
--

INSERT INTO `t_users_convention` (`id_user`, `login`, `titre`, `pass`, `nom`, `prenom`, `contact`, `email`, `convention`, `niveau`, `projet_active`, `date_enregistrement`, `enregistrer_par`, `date_modification`, `modifier_par`, `statut`) VALUES
(5, 'losseni', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'Coulibaly', 'Losseni', 'A définir', 'ou07@gmail.com', 11, 1, 6, '2019-02-13 15:25:05', 1, '2019-03-11 10:50:41', 1, 0),
(7, 'marietou', 'Mlle', '81dc9bdb52d04dc20036dbd8313ed055', 'Coulibaly', 'Marietou ', 'A définir', 'rou07@gmail.com', 12, 1, 0, '2019-02-13 15:27:10', 1, '2019-03-11 10:51:11', 1, 0),
(9, 'kamara', 'Mme', '81dc9bdb52d04dc20036dbd8313ed055', 'KAMARA', 'K', 'A définir', 'u07@gmail.com', 8, 1, 0, '2019-02-13 15:29:04', 1, '2019-03-11 10:50:15', 1, 0),
(20, 'lasso', 'M', 'ec6a6536ca304edf844d1d248a4f08dc', 'kone', 'lasso', 'A définir', '7@gmail.com', 4, 10, 0, '2019-03-18 19:43:52', 6, '2019-03-20 00:00:00', 6, 0),
(21, 'desire', 'M', 'ec6a6536ca304edf844d1d248a4f08dc', 'BROU', 'Jean Desire', '08204558', 'desirebrou07@gmail.com', 4, 20, 0, '2019-03-20 15:33:38', 6, '2019-05-12 00:00:00', 6, 0),
(24, 'desir', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'brou', 'desire', '08204558', 'desirebrou07@gmail.com', 5, 20, 0, '2019-05-03 10:55:44', 8, NULL, 0, 0),
(25, 'fouss', 'M', '81dc9bdb52d04dc20036dbd8313ed055', 'SDFGH', 'GFHJK', '0852', 'FG@H.JKK', 6, 20, 0, '2019-05-15 14:16:44', 6, NULL, 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
///////////////////////////////////////////////
/*                 SSE                       */
/*	Conception & Développement: BAMASOFT */
///////////////////////////////////////////////

include_once 'api/configuration.php';
$config = new Config;

require_once 'api/Fonctions.php';
require_once 'theme_components/theme_style.php';
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title><?php print $config->sitename; ?></title>
    <link rel="shortcut icon" type="image/ico" href="<?php print $config->icon_folder; ?>/favicon.png" />
    <meta name="keywords" content="<?php print $config->MetaKeys; ?>" />
    <meta name="description" content="<?php print $config->MetaDesc; ?>" />
    <meta name="author" content="<?php print $config->MetaAuthor; ?>" />

    <!-- Vendor styles -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css" />
    <link rel="stylesheet" href="vendor/metisMenu/dist/metisMenu.css" />
    <link rel="stylesheet" href="vendor/animate.css/animate.css" />
    <link rel="stylesheet" href="vendor/bootstrap/dist/css/bootstrap.css" />

    <!-- App styles -->
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/helper.css" />
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/style_fst.css">

    <!-- Vendor scripts -->
    <script src="vendor/jquery/dist/jquery.min.js"></script>
    <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
    <script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
    <script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.resize.js"></script>
    <script src="vendor/jquery-flot/jquery.flot.pie.js"></script>
    <script src="vendor/flot.curvedlines/curvedLines.js"></script>
    <script src="vendor/jquery.flot.spline/index.js"></script>
    <script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
    <script src="vendor/iCheck/icheck.min.js"></script>
    <script src="vendor/peity/jquery.peity.min.js"></script>
    <script src="vendor/sparkline/index.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="vendor/bootstrap-datepicker-master/dist/locales/bootstrap-datepicker.fr.min.js"></script>

    <!-- DataTables -->
    <script src="vendor/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <!-- DataTables buttons scripts -->
    <script src="vendor/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendor/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendor/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>

    <!-- App scripts -->
    <script src="scripts/homer.js"></script>

</head>

<body class="fixed-navbar fixed fixed-footer sidebar-scroll">
    <?php require_once "./theme_components/header.php"; ?>
    <?php //require_once "./theme_components/main-menu.php"; ?>
    <!-- Main Wrapper -->
    <div id="">
        <div class="content animate-panel">
            <div class="row">


                <div class="content">

                    <?php
                    $ii = 0;
                    $ui = 0;
                    foreach (FC_Rechercher_Code("SELECT * FROM t_rapport  ORDER BY Code_Rapport DESC") as $row3) {
                        if ($ii % 3 == 0) {
                            echo '<div class="row projects">';
                        }
                        $ui++;
                        $Nom_Feuille = "";
                        $Nom_Classeur = "";
                        foreach (FC_Rechercher_Code('SELECT * FROM t_feuille INNER JOIN t_classeur ON (t_feuille.Code_Classeur=t_classeur.Code_Classeur) WHERE (t_feuille.Code_Feuille=' . $row3["Code_Feuille"] . ')') as $row4) {
                            $Nom_Feuille = $row4["Nom_Feuille"];
                            $Nom_Classeur = $row4["Libelle_Classeur"];
                        }
                        echo ' <div class="col-lg-4">
                <div class="hpanel " style="border-top: 2px solid ' . $Panel_Item_Style . '">

                    <div class="panel-body">
                    ';


                        if ($row3['Type_Rapport'] == "SIMPLE") {
                            echo '<a href="mobile_rapport_details_simple.php?r=' . base64_encode($row3['Code_Rapport']) . '" style="font-size:16px">' . $row3['Nom_Rapport'] . '</a>';
                        } else {
                            echo '<a href="mobile_rapport_details_croise.php?r=' . base64_encode($row3['Code_Rapport']) . '" style="font-size:16px">' . $row3['Nom_Rapport'] . '</a>';
                        }

                        if (strstr($row3['Date_Insertion'], date('Y-m-d'))) {
                            echo '<span class="label ' . $Label_Style . ' pull-right">NEW</span>';
                        }
                        echo '<div class="row" style="text-align: left">
                            <div class="col-sm-10">
                                <hr class="color-line">

                                <p>Classeur : ' . $Nom_Classeur . '</p>

                                <div class="row">

                                    <div class="col-sm-10">
                                        <div class="project-label"><small>Feuilles : ' . $Nom_Feuille . '</small>';

                        echo '</div>

                                    </div>
                                    <div class="col-sm-2">
                                        <div class="project-label"><div class="" style="background-color:; border-radius: 50%; width: 20px; height: 20px">';

                        if ($row3['Type_Rapport'] == "SIMPLE") {
                            echo '<span class="glyphicon glyphicon-stats text-info"></span>';
                        } else {
                            echo '<span class="glyphicon glyphicon-equalizer text-info"></span>';
                        }
                        echo '</div></div>

                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-2 project-info">
                                <div class="project-action m-t-md"> 
                             
                                    <div class="btn-group" style="font-size: 18px">
                                       
                                    </div>

                                    
                                    


                                </div>




                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">';



                        if ($row3['Type_Rapport'] == "SIMPLE") {
                            echo '<a href="mobile_rapport_details_simple.php?r=' . base64_encode($row3['Code_Rapport']) . '" >Ouvrir le rapport</a>';
                        } else {
                            echo '<a href="mobile_rapport_details_croise.php?r=' . base64_encode($row3['Code_Rapport']) . '" >Ouvrir le rapport</a>';
                        }
                        echo '</div>
                </div>
            </div>';

                        if ($ui % 3 == 0) {
                            echo ' </div>';
                            $ui = 0;
                        }
                        $ii++;
                    }

                    ?>

                </div>

            </div>
        </div>
        <?php //require_once "./theme_components/footer.php"; ?>
    </div>

</body>

</html>
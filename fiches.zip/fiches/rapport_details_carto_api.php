<?php
// api/report.php
// header('Content-Type: application/json; charset=utf-8');
// header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Methods: GET');

include_once 'api/configuration.php';
$config = new Config;

require_once 'api/Fonctions.php';

try {
    // Vérifier paramètre 'r'
    if (!isset($_GET['r']) || empty($_GET['r'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Paramètre r manquant.']);
        exit;
    }

    $r_raw = $_GET['r'];
    $Code_Rapport = $r_raw;
    if ($Code_Rapport === false) {
        http_response_code(400);
        echo json_encode(['error' => 'Impossible de décoder le paramètre r.']);
        exit;
    }

    // **Sécurité** : ici j'exige que Code_Rapport soit numérique (adapte si ce n'est pas le cas)
    if (!ctype_digit((string) $Code_Rapport)) {
        http_response_code(400);
        echo json_encode(['error' => 'Code_Rapport invalide.']);
        exit;
    }

    // Récupérer le rapport
    $sql = "SELECT * FROM t_rapport WHERE Code_Rapport = '" . $Code_Rapport . "'";
    $res = FC_Rechercher_Code($sql);

    if ($res) {
        foreach ($res as $report) {



            // Construire les en-têtes à partir des métadonnées (Group_By, LG, LT, Valeur)
            $headers = [];
            // groupBy
            $groupBy = explode('.', $report["Group_By"]);
            if (count($groupBy) >= 2) {
                $table_feuille = str_replace('v', 't', $groupBy[0]);
                $col = $groupBy[1];
                $q = "SELECT t_feuille_ligne.Libelle_Ligne
              FROM t_feuille_ligne
              INNER JOIN t_feuille ON t_feuille_ligne.Code_Feuille = t_feuille.Code_Feuille
              WHERE t_feuille.Table_Feuille = '" . addslashes($table_feuille) . "'
                AND t_feuille_ligne.Nom_Collone = '" . addslashes($col) . "'";
                foreach (FC_Rechercher_Code($q) as $h) {
                    $headers[] = $h['Libelle_Ligne'];
                }
            }

            // LG, LT ajoutés si présents
            $headers[] = 'LG';
            $headers[] = 'LT';

            // valeurs
            $valeurs = explode('.', $report["Valeur"]);
            if (count($valeurs) >= 2) {
                $table_val = str_replace('v', 't', $valeurs[0]);
                $col_val = $valeurs[1];
                $q2 = "SELECT t_feuille_ligne.Libelle_Ligne
               FROM t_feuille_ligne
               INNER JOIN t_feuille ON t_feuille_ligne.Code_Feuille = t_feuille.Code_Feuille
               WHERE t_feuille.Table_Feuille = '" . addslashes($table_val) . "'
                 AND t_feuille_ligne.Nom_Collone = '" . addslashes($col_val) . "'";
                foreach (FC_Rechercher_Code($q2) as $h2) {
                    $headers[] = $h2['Libelle_Ligne'];
                }
            }

            // Récupérer les données depuis la view associée (Nom_View)
            $rows = [];
            try {
                // attention : Nom_View doit être sûr (vérifie si tu peux)
                $view = $report['Nom_View'];
                if (empty($view)) {
                    throw new Exception('Nom_View non défini pour ce rapport.');
                }
                $dataRes = FC_Rechercher_Code("SELECT * FROM " . $view);
                if ($dataRes) {
                    foreach ($dataRes as $r) {
                        $uniqueRow = [];
                        $i = 0;
                        foreach ($r as $key => $val) {
                            if (!is_int($key)) { // ignorer les index numériques
                                // utiliser directement le header si dispo, sinon le nom brut
                                $headerName = isset($headers[$i]) ? $headers[$i] : $key;
                                $uniqueRow[$headerName] = $val;
                                $i++;
                            }
                        }
                        $rows[] = $uniqueRow;
                        $count++;
                    }
                }
            } catch (Exception $e) {
                // erreur de récupération des données — renvoyer quand même metadata
                http_response_code(500);
                echo json_encode(['error' => 'Erreur récupération données : ' . $e->getMessage()]);
                exit;
            }

            // Construire la réponse JSON
            $response = [
                'title' => $report['Nom_Rapport'],
                'code' => $report['Code_Rapport'],
                'headers' => $headers,
                'rows' => $rows,
                /*  'meta' => [
                     'Group_By' => $report['Group_By'],
                     'Valeur' => $report['Valeur'],
                     'Nom_View' => $report['Nom_View']
                 ] */
            ];

            echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }
    }

} catch (Throwable $t) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur.', 'details' => $t->getMessage()]);
    exit;
}

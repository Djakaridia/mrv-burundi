<?php
///////////////////////////////////////////////
/*                 SSE                       */
/*	Conception & DÃ©veloppement: SEYA SERVICES */
///////////////////////////////////////////////
session_start();
include_once 'system/configuration.php';
$config = new Config;
/*
if (!isset ($_SESSION["clp_id"]) )) {
  //header(sprintf("Location: %s", "./"));
  exit;
}*/
include_once $config->sys_folder . "/database/db_connexion.php";
/**/
header("Content-Type: application/vnd.ms-excel");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("content-disposition: attachment;filename=export_fiche.xls");

if(isset($_GET['anpta'])) {$departemn=$_GET['anpta'];} else {$departemn=$annee=0;}
/*if(isset($_GET['id'])) {$id=$_GET['id'];}
if(isset($_GET['cmp'])) {$ugl=$cmp = $_GET['cmp'];} else $cmp=$_SESSION["clp_structure"]; */
if(isset($_GET['feuille'])) {$feuille=$_GET['feuille'];}
$cp=$feuille/*="t_1642578894"*/;

$entete_array = $libelle = array();
$idperso= $_SESSION["clp_id"];



if($_SESSION["clp_id"] == "admin"){
$query_act = "SELECT * FROM $feuille";
}
     else 
	$query_act = "SELECT * FROM $feuille WHERE (( Login  in (select id_personnel from personnel where structure = '".$_SESSION["clp_structure"]."') )) ";
 //else {$Filtre_Admin=" WHERE (( Login  in (select id_personnel from personnel where structure = '".$_SESSION["clp_structure"]."') ))  ";}
  
 try{
    $act = $pdar_connexion->prepare($query_act);
    $act->execute();
    $row_act = $act ->fetchAll();
    $totalRows_act = $act->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }

//echo $totalRows_act; exit;

//mysql_select_db($database_pdar_connexion, $pdar_connexion);
$query_entete = "SELECT t_feuille_ligne.* FROM t_feuille_ligne,t_feuille_ligne  where t_feuille_ligne.code_feuille=t_feuille.code_feuille and t_feuille.`Table_Feuille` = $feuille";
    try{
    $entete = $pdar_connexion->prepare($query_entete);
    $entete->execute();
    $row_entete = $entete ->fetchAll();
    $totalRows_entete = $entete->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }

if($totalRows_entete>0){ $choix_array = array(); $libelle_array = array();
foreach($row_entete as $row_entete1){ 
 $nomT=$row_entete1["Libelle_Ligne"]; $note="Tapade"; 
 $entete_array[$row_entete1["Nom_Collone"]]=$row_entete1["Nom_Collone"]; 
 $libelle[]=$row_entete1["Libelle_Ligne"];
$intitule[]=$row_entete1["Libelle_Feuille"]; 
$colonne[]=$row_entete1["Nom_Collone"]; 
$libelle_array[$row_entete1["Nom_Collone"]]=$row_entete1["Libelle_Ligne"];
$lignetotal=20000; $colnum=20;
}
}
/*
if(!empty($libelle)){ foreach($libelle as $elem){ if(!empty($elem)){  $a=explode(";",$elem); $choix_array[$a[0]]=""; for($i=1;$i<count($a);$i++){ $choix_array[$a[0]].=(!empty($a[$i]))?$a[$i].";":""; } }   }  } }

$count = count($libelle)-2;
$count = explode("=",$libelle[$count]);
$lib_nom_fich = "";
if(isset($count[1]))
$lib_nom_fich = $count[1];
elseif(isset($count[0]))
$lib_nom_fich = $count[0];

if(empty($lib_nom_fich))*/ $lib_nom_fich = $cp;

$query_entete = "DESCRIBE $feuille";
    try{
    $entete = $pdar_connexion->prepare($query_entete);
    $entete->execute();
    $row_entete = $entete ->fetchAll();
    $totalRows_entete = $entete->rowCount();
}catch(Exception $e){ die(mysql_error_show_message($e)); }

$num=0;
if($totalRows_entete>0){ foreach($row_entete as $row_entete1){  /*if(in_array($row_entete["Field"],$entete_array))*/ $num++; }  }
/*
$rows = mysql_num_rows($entete);
if($rows > 0) {
mysql_data_seek($entete, 0);
$row_entete = mysql_fetch_assoc($entete);
}*/


//foreach($libelle as $a) { $b = $a;  $libelle_array[$b]=$a; }
/**/

//print_r($entete_array);exit;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
<!-- Site contenu ici -->
<style>#mtable tr td, .table thead tr th {vertical-align: middle; }  .table {
  border-spacing: 0px !important; border-collapse: collapse; width: 100%!important;
} .table tbody tr td {vertical-align: middle; }
thead tr {
  background-color: #DCDCDC;
}
</style>

<?php if($num>0){ ?>
<table class="table table-striped table-bordered table-hover table-responsive datatable dataTable " id="mtable<?php echo $feuille; ?>" aria-describedby="DataTables_Table_0_info" border="1">


<thead>
<tr role="row" bgcolor="#BED694">
<th class="" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" aria-label="Trier" ><div class="firstcapitalize" align="center">Identifiant</div></th>
<th class="" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" aria-label="Trier" ><div class="firstcapitalize" align="center">Login</div></th>
<?php
if($colnum==1){ ?>
<th class="" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" aria-label="Trier" ><div class="firstcapitalize" align="center">N&deg;</div></th>
<?php }
if($totalRows_entete>0){ $i=0; foreach($row_entete as $row_entete1){

/*if(isset($libelle[$i])){
$lib=explode("=",$libelle[$i]);
$libelle_array[$lib[0]]=(isset($lib[1]))?$lib[1]:"ND";   } */

if($row_entete1["Field"]!="LKEY" && in_array($row_entete1["Field"],$entete_array)){ ?>
<th class="" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" aria-label="Trier" ><div class="firstcapitalize" align="center"><?php echo (isset($libelle_array[$row_entete1["Field"]]))?$libelle_array[$row_entete1["Field"]]:str_replace("_"," ",$row_entete1["Field"]); ?></div></th>
<?php $i++; }  } 

/*$rows = mysql_num_rows($entete);
if($rows > 0) {
mysql_data_seek($entete, 0);
$row_entete = mysql_fetch_assoc($entete);
} */ ?>
</tr></thead>
<?php } ?>

<?php
// si ligne total on crée les variables
if($lignetotal==1){ $Ltotal = array();
if($totalRows_entete>0){ foreach($row_entete as $row_entete1){  if($row_entete1["Field"]!="LKEY" && in_array($row_entete1["Field"],$entete_array) && $i>0){
 ?>
<?php $Ltotal[$row_entete1["Field"]]=0;  ?>
<?php  }  }
/*$rows = mysql_num_rows($entete);
  if($rows > 0) {
  mysql_data_seek($entete, 0);
  $row_entete = mysql_fetch_assoc($entete);
  }*/
    }
}  $i = isset($k)?$k:$i;
?>
<tbody role="alert" aria-live="polite" aria-relevant="all" class="">
<?php if($totalRows_act>0) { $i=0;  foreach($row_act as $row_act){ $id_data = $row_act['Id'];
foreach($choix_array as $Col=>$Val)
{
  $somme[$Col]=$produit[$Col]=$moyenne[$Col]=$rapport[$Col]=$difference[$Col]=0;
  $tem[$Col]=0;
}
?>
<tr class="<?php echo ($i%2==0)?"odd":"even"; ?>">
<td><div align="center"><?php echo  $row_act["Id"];  ?></div></td>
<td><div align="center"><?php echo  $row_act["Login"];  ?></div></td>
<?php if($totalRows_entete>0){
if($colnum==1){ ?>
<td><div align="center"><?php echo $i+1; ?></div></td>
<?php }  foreach($row_entete as $row_entete1){ if($row_entete1["Field"]!="LKEY" && in_array($row_entete1["Field"],$entete_array)){

 ?>
<td class=" "><?php echo  $row_act[$row_entete1["Field"]];  ?></td>
<?php } }/*while($row_entete  = mysql_fetch_assoc($entete));
$rows = mysql_num_rows($entete);
if($rows > 0) {
mysql_data_seek($entete, 0);
$row_entete = mysql_fetch_assoc($entete);
}*/
} ?>
</tr>
<?php $i++; } 
//total
  ?>

<?php 
 } else { $colspan = ($colnum==1)?$i+1:$i; echo "<td colspan='".($colspan+1)."' class='' align='center'><h3 align='center'>Aucune donn&eacute;es &agrave; afficher dans cette feuille !</h3></td>"; } ?>
</tbody></table>
<?php }else echo "<h3 align='center'>Aucune colonne &agrave; afficher dans la fiche ".$lib_nom_fich."!</h3>"; ?>

</body>
</html>